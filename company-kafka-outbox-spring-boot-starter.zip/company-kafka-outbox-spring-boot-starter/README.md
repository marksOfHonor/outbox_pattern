# Company Outbox Spring Boot Starter

A production-ready Spring Boot Starter implementing the **Transactional Outbox Pattern**. Provides transaction-safe event persistence with a three-phase polling relay, transport-agnostic publisher contract, distributed locking, observability, and extensibility hooks.

## Features

- **Transaction-safe event persistence** — Events are written atomically within the caller's business transaction (`@Transactional(MANDATORY)`)
- **Transport-agnostic** — No Kafka/RabbitMQ/SQS dependency; bring your own publisher via `OutboxEventPublisher`
- **Multi-table support** — Configure multiple outbox tables per aggregate type with dynamic resolution
- **Three-phase relay** — Claim (short TX) -> Publish (outside TX, no DB locks held) -> Finalize (short TX)
- **`SELECT ... FOR UPDATE SKIP LOCKED`** — Concurrent safety across instances with auto-detection for H2 fallback
- **Distinct retry status** — `RETRY` status distinguishes never-sent events (`PENDING`) from failed-and-waiting-for-retry, with `processed_at` tracking last attempt time
- **Exponential backoff** — Configurable retry with `baseMs * 2^(retryCount-1)` capped at `maxMs`
- **Batch publishing** — Optional `OutboxBatchPublisher` for high-throughput with automatic fallback to individual publishing
- **Batch DB updates** — Optional single JDBC batch update per poll cycle instead of per-event DB writes
- **Distributed locking** — Optional JDBC-based advisory lock for single-leader relay/cleanup across instances
- **Event filtering** — `OutboxEventFilter` to skip events before publishing (filtered events marked PUBLISHED)
- **Payload compression** — Optional Gzip + Base64 compression for large payloads
- **Schema versioning** — `schema_version` column for payload evolution
- **Lifecycle hooks** — `OutboxHooks` (persistence) and `RelayHooks` (relay) for tracing, auditing, or custom logic
- **Health indicator** — Per-table health reporting (pending, retry, failed counts, oldest unprocessed age) via Spring Boot Actuator
- **Scheduled cleanup** — Cron-based deletion of published events older than a configurable retention period
- **Micrometer metrics** — Counters and timers for stored, published, retried, failed, and cleaned-up events
- **Full auto-configuration** — All beans registered via `@ConditionalOnMissingBean` for complete overridability

## Requirements

- Java 21+
- Spring Boot 3.5+
- Spring JDBC (no JPA/Hibernate required)
- A relational database (Oracle, PostgreSQL, MySQL, H2, etc.)

## Getting Started

### 1. Add the dependency

```xml
<dependency>
    <groupId>com.company</groupId>
    <artifactId>company-kafka-outbox-spring-boot-starter</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</dependency>
```

### 2. Create the outbox table(s)

```sql
CREATE TABLE trade_outbox (
    id              VARCHAR(36)  PRIMARY KEY,
    aggregate_type  VARCHAR(255) NOT NULL,
    aggregate_id    VARCHAR(255) NOT NULL,
    event_type      VARCHAR(255) NOT NULL,
    payload         CLOB         NOT NULL,
    headers         CLOB,
    created_at      TIMESTAMP    NOT NULL,
    status          VARCHAR(20)  NOT NULL DEFAULT 'PENDING',
    processed_at    TIMESTAMP,
    retry_count     INT          NOT NULL DEFAULT 0,
    next_retry_at   TIMESTAMP,
    schema_version  INT          NOT NULL DEFAULT 1,
    compressed      BOOLEAN      NOT NULL DEFAULT FALSE
);

-- Optional: for distributed locking
CREATE TABLE outbox_lock (
    lock_name   VARCHAR(100) PRIMARY KEY,
    locked_by   VARCHAR(255) NOT NULL,
    lock_until  TIMESTAMP    NOT NULL
);
```

### 3. Configure the application

```yaml
outbox:
  enabled: true                        # Default: true
  tables:
    trade:
      table-name: trade_outbox         # Required
      aggregate-type: Trade            # Required
      topic: trade-events              # Required when relay is enabled
    payment:
      table-name: payment_outbox
      aggregate-type: Payment
      topic: payment-events
```

**Validation rules (fail-fast at startup):**
- At least one table entry is required
- `table-name` and `aggregate-type` are mandatory for each entry
- Table names must match `^[a-zA-Z_][a-zA-Z0-9_]*$` (SQL injection protection)
- Each `aggregate-type` must be unique across all entries
- `topic` must not be blank when the relay is enabled

### 4. Store events in your service

```java
@Service
public class TradeService {

    private final OutboxService outboxService;

    public TradeService(OutboxService outboxService) {
        this.outboxService = outboxService;
    }

    @Transactional  // The caller MUST provide a transaction
    public void executeTrade(Trade trade) {
        // ... business logic ...

        outboxService.storeEvent(
            "Trade",                                    // aggregate type
            trade.getId(),                              // aggregate ID
            "TRADE_EXECUTED",                           // event type
            Map.of("amount", trade.getAmount(),         // payload (serialized to JSON)
                   "currency", trade.getCurrency()),
            Map.of("correlationId", correlationId)      // optional headers
        );
    }
}
```

The table is resolved automatically: `"Trade"` -> `trade_outbox`. No need to pass a table name.

### 5. Implement a publisher (required only for the relay)

```java
@Component
public class KafkaOutboxPublisher implements OutboxEventPublisher {

    private final KafkaTemplate<String, String> kafkaTemplate;

    public KafkaOutboxPublisher(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    @Override
    public void publish(OutboxEvent event, String destination) throws Exception {
        ProducerRecord<String, String> record = new ProducerRecord<>(
            destination,
            event.getAggregateId(),
            event.getPayload()
        );
        event.getHeaders().forEach((k, v) ->
            record.headers().add(k, v.getBytes(StandardCharsets.UTF_8)));

        kafkaTemplate.send(record).get(); // Synchronous send
    }
}
```

You can use **any transport** — Kafka, RabbitMQ, SQS, HTTP, gRPC, etc.

## Configuration Reference

### Core

| Property | Type | Default | Description |
|----------|------|---------|-------------|
| `outbox.enabled` | boolean | `true` | Enable/disable the entire starter |
| `outbox.tables.<key>.table-name` | string | — | **Required.** SQL table name |
| `outbox.tables.<key>.aggregate-type` | string | — | **Required.** Aggregate type for table resolution |
| `outbox.tables.<key>.topic` | string | — | **Required when relay enabled.** Destination for the publisher |

### Relay (Polling Publisher)

| Property | Type | Default | Description |
|----------|------|---------|-------------|
| `outbox.relay.enabled` | boolean | `false` | Enable the polling relay |
| `outbox.relay.poll-interval-ms` | long | `1000` | Polling interval in milliseconds |
| `outbox.relay.batch-size` | int | `50` | Max events per poll per table |
| `outbox.relay.max-retries` | int | `3` | Max retries before marking FAILED |
| `outbox.relay.backoff-base-ms` | long | `1000` | Base delay for exponential backoff |
| `outbox.relay.backoff-max-ms` | long | `60000` | Maximum backoff delay cap |
| `outbox.relay.batch-db-updates` | boolean | `false` | Batch all DB status updates into a single JDBC batch per poll cycle instead of per-event updates |

### Cleanup

| Property | Type | Default | Description |
|----------|------|---------|-------------|
| `outbox.cleanup.enabled` | boolean | `false` | Enable scheduled cleanup |
| `outbox.cleanup.cron` | string | `0 0 2 * * *` | Cron expression (default: daily at 2 AM) |
| `outbox.cleanup.retention-hours` | long | `72` | Retention period for published events |

### Health Indicator

| Property | Type | Default | Description |
|----------|------|---------|-------------|
| `outbox.health.pending-warn-threshold` | int | `100` | Unprocessed count (pending + retry) threshold for health degradation |
| `outbox.health.max-pending-age-minutes` | int | `30` | Max age of oldest unprocessed event before warning |

### Compression

| Property | Type | Default | Description |
|----------|------|---------|-------------|
| `outbox.compression.enabled` | boolean | `false` | Enable Gzip payload compression |

### Distributed Lock

| Property | Type | Default | Description |
|----------|------|---------|-------------|
| `outbox.distributed-lock.enabled` | boolean | `false` | Enable JDBC-based distributed locking |
| `outbox.distributed-lock.lock-at-most-ms` | long | `30000` | Maximum lock hold duration in milliseconds |

## Architecture

### Event Lifecycle

```
PENDING ──── relay claims ────> PROCESSING ──── publish succeeds ────> PUBLISHED
                                    │                                      │
                                    │ (publish fails, retry < max)         │ (after retention)
                                    └───────> RETRY (with backoff) ────────│
                                    │           │                          │
                                    │           └── backoff expires ──> re-claimed as PROCESSING
                                    │                                      │
                                    │ (publish fails, retry >= max)        └──── DELETED (cleanup)
                                    └───────> FAILED
```

**Status descriptions:**

| Status | Meaning |
|--------|---------|
| `PENDING` | Newly created, never attempted |
| `PROCESSING` | Claimed by a relay instance, publish in progress |
| `RETRY` | Publish failed, waiting for backoff to expire before next attempt |
| `PUBLISHED` | Successfully published to the transport |
| `FAILED` | Permanently failed after exhausting all retries |

**Key columns on retry:**
- `retry_count` — incremented on each failure
- `processed_at` — last attempt timestamp (set on both RETRY and FAILED, success time on PUBLISHED)
- `next_retry_at` — when the backoff expires and the event becomes eligible for retry

### Three-Phase Processing Model

The relay uses a three-phase approach to avoid holding DB locks during broker round-trips:

```
Phase 1 — CLAIM (short transaction)
  SELECT ... FOR UPDATE SKIP LOCKED
  UPDATE status = 'PROCESSING', next_retry_at = claim_expiry

Phase 2 — PUBLISH (no transaction, no DB locks held)
  publisher.publish(event, destination)

Phase 3 — FINALIZE (short transaction per event, or single JDBC batch)
  UPDATE status = 'PUBLISHED' | 'RETRY' | 'FAILED'
```

**Crash recovery:** If a relay instance crashes after Phase 1 but before Phase 3, the claimed events remain in `PROCESSING` status. Once the claim expiry passes (default: 5 minutes), another instance automatically reclaims them.

### Finalization Strategies

| `batch-db-updates` | Behavior |
|---------------------|----------|
| `false` (default) | Each event is finalized in its own short transaction immediately after publish |
| `true` | All publish outcomes are collected, then written in a single JDBC batch update per table |

The batched strategy reduces DB round-trips and is recommended for high-throughput scenarios, especially on Oracle where JDBC batch operations are significantly faster.

The batch publisher path (`OutboxBatchPublisher`) always uses JDBC batch updates for finalization regardless of this setting.

### Component Overview

```
┌─────────────────────────────────────────────────────────────────┐
│  Your Application                                               │
│                                                                 │
│  @Service                                                       │
│  TradeService ──@Transactional──> OutboxService ──> JdbcRepo    │
│                                        │                        │
│                                   OutboxHooks                   │
│                                   OutboxMetrics                 │
│                                   PayloadSerializer             │
│                                   TableResolver                 │
└─────────────────────────────────────────────────────────────────┘
                    ▼ (same DB transaction)
┌─────────────────────────────────────────────────────────────────┐
│  Outbox Table (trade_outbox)                                    │
│  ┌──────────┬───────────┬────────┬─────────┬────────────────┐   │
│  │ id       │ status    │ payload│ retry   │ next_retry_at  │   │
│  │ UUID     │ PENDING   │ {...}  │ 0       │ NULL           │   │
│  └──────────┴───────────┴────────┴─────────┴────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                    ▼ (polling relay, three-phase processing)
┌─────────────────────────────────────────────────────────────────┐
│  OutboxRelay (scheduled)                                        │
│                                                                 │
│  Phase 1: Claim (short TX)                                      │
│    DistributedLock ─> SELECT FOR UPDATE SKIP LOCKED             │
│         (opt)         UPDATE status = PROCESSING                │
│                                                                 │
│  Phase 2: Publish (no TX)                                       │
│    EventFilter ─> RelayHooks ─> OutboxEventPublisher            │
│       (opt)                     (your implementation)           │
│                                          ▼                      │
│                                  Kafka / RabbitMQ /             │
│                                  SQS / HTTP / etc.              │
│                                                                 │
│  Phase 3: Finalize (short TX or JDBC batch)                     │
│    UPDATE status = PUBLISHED | RETRY | FAILED                   │
│    OutboxMetrics.recordRelayPublished/Retried/Failed            │
└─────────────────────────────────────────────────────────────────┘
```

### Transaction Safety

`OutboxService.storeEvent()` uses `@Transactional(propagation = Propagation.MANDATORY)` — it **requires** an existing transaction. If called without one, it throws immediately. This guarantees the outbox insert is always atomic with your business logic.

### SELECT ... FOR UPDATE SKIP LOCKED

The relay uses `SELECT ... FOR UPDATE SKIP LOCKED` for concurrent safety across multiple instances. Each event is processed by exactly one instance. H2 is auto-detected and falls back to `SELECT ... FOR UPDATE` without SKIP LOCKED.

### Exponential Backoff

When a publish fails, the event transitions to `RETRY` with an incremented `retry_count`, a `processed_at` timestamp (last attempt), and a `next_retry_at` backoff:

```
next_retry_at = now + min(backoffBaseMs * 2^(retryCount - 1), backoffMaxMs)
```

| Retry | Delay (default config) |
|-------|----------------------|
| 1     | 1s                   |
| 2     | 2s                   |
| 3     | 4s                   |
| 4     | 8s                   |
| 5     | 16s                  |
| ...   | capped at 60s        |

Events in `RETRY` status with `next_retry_at` in the future are skipped by the relay until the backoff expires.

## Extensibility

All beans are registered with `@ConditionalOnMissingBean`. Define your own bean of the same type to replace any default.

### Custom Publisher

Implement `OutboxEventPublisher` for individual event publishing:

```java
@Component
public class SqsOutboxPublisher implements OutboxEventPublisher {
    @Override
    public void publish(OutboxEvent event, String destination) throws Exception {
        sqsClient.sendMessage(SendMessageRequest.builder()
            .queueUrl(destination)
            .messageBody(event.getPayload())
            .build());
    }
}
```

### Batch Publisher (Optional)

Implement `OutboxBatchPublisher` for high-throughput. The relay automatically prefers batch publishing and falls back to individual on failure:

```java
@Component
public class KafkaBatchPublisher implements OutboxBatchPublisher {
    @Override
    public void publishBatch(List<OutboxEvent> events, String destination) throws Exception {
        List<ProducerRecord<String, String>> records = events.stream()
            .map(e -> new ProducerRecord<>(destination, e.getAggregateId(), e.getPayload()))
            .toList();
        kafkaTemplate.executeInTransaction(ops -> {
            records.forEach(ops::send);
            return null;
        });
    }
}
```

### Persistence Hooks

```java
@Component
public class AuditOutboxHooks implements OutboxHooks {
    @Override
    public void beforePersist(OutboxEvent event) {
        // Enrich event, validate, add tracing headers
    }

    @Override
    public void afterPersist(OutboxEvent event) {
        // Audit log, metrics
    }

    @Override
    public void onError(OutboxEvent event, Exception exception) {
        // Alert, compensate
    }
}
```

### Relay Hooks

```java
@Component
public class TracingRelayHooks implements RelayHooks {
    @Override
    public void beforePublish(OutboxEvent event, String destination) {
        // Restore trace context from event headers
    }

    @Override
    public void afterPublish(OutboxEvent event, String destination) {
        // Record span
    }

    @Override
    public void onPublishFailure(OutboxEvent event, String destination, Exception exception) {
        // Record error span
    }
}
```

### Event Filtering

Skip certain events from being published (e.g., internal events):

```java
@Bean
public OutboxEventFilter outboxEventFilter() {
    return event -> !"INTERNAL".equals(event.getEventType());
}
```

Filtered events are marked `PUBLISHED` to prevent reprocessing.

### Custom Lock Provider

Replace the default JDBC lock with your own (e.g., Redis, ZooKeeper):

```java
@Bean
public OutboxLockProvider outboxLockProvider() {
    return new RedisOutboxLockProvider(redisTemplate);
}
```

### Custom Payload Serializer

```java
@Bean
public PayloadSerializer payloadSerializer() {
    return payload -> myCustomSerialization(payload);
}
```

### Custom Payload Compressor

```java
@Bean
public PayloadCompressor payloadCompressor() {
    return new LZ4PayloadCompressor();
}
```

## Observability

### Metrics (Micrometer)

| Metric | Type | Tags | Description |
|--------|------|------|-------------|
| `outbox.events.stored` | Counter | `table`, `eventType` | Events persisted |
| `outbox.events.failed` | Counter | `table`, `eventType` | Persistence failures |
| `outbox.persist.latency` | Timer | `table`, `eventType` | Persistence latency |
| `outbox.relay.published` | Counter | `table`, `eventType` | Events published by relay |
| `outbox.relay.retried` | Counter | `table`, `eventType` | Events that failed and will be retried |
| `outbox.relay.failed` | Counter | `table`, `eventType` | Events permanently failed (max retries exhausted) |
| `outbox.cleanup.deleted` | Counter | `table` | Events deleted by cleanup |

### Health Indicator

Available at `/actuator/health` when Spring Boot Actuator is on the classpath:

```json
{
  "status": "UP",
  "components": {
    "outbox": {
      "status": "UP",
      "details": {
        "trade_outbox": {
          "pendingCount": 3,
          "retryCount": 1,
          "failedCount": 0,
          "oldestPendingAgeSeconds": 5
        }
      }
    }
  }
}
```

Health degrades to `DOWN` when:
- Unprocessed count (`pendingCount + retryCount`) exceeds `outbox.health.pending-warn-threshold`
- Oldest unprocessed event age exceeds `outbox.health.max-pending-age-minutes`

Additional details reported:
- `attention: "N events awaiting retry"` when `retryCount > 0`
- `attention: "N failed events require investigation"` when `failedCount > 0`

## Distributed Lock

When running multiple instances of your application, enable the distributed lock to ensure only one instance runs the relay and cleanup at a time:

```yaml
outbox:
  distributed-lock:
    enabled: true
    lock-at-most-ms: 30000   # Lock held for at most 30 seconds
```

**Required table:**

```sql
CREATE TABLE outbox_lock (
    lock_name   VARCHAR(100) PRIMARY KEY,
    locked_by   VARCHAR(255) NOT NULL,
    lock_until  TIMESTAMP    NOT NULL
);
```

**How it works:**
- Lock acquisition: `UPDATE outbox_lock SET locked_by=?, lock_until=? WHERE lock_name=? AND lock_until < NOW()`
- If no row is updated, the lock is held by another instance — the relay/cleanup cycle is skipped
- Lock rows are auto-created on first access
- If the lock holder crashes, the lock automatically expires after `lock-at-most-ms`
- Lock is released immediately after each relay/cleanup cycle completes (even on error)
- No external dependencies — pure JDBC

**When to use:**
- The distributed lock adds **instance-level coordination** so that only one instance polls at a time
- Even without the lock, the relay uses `SELECT ... FOR UPDATE SKIP LOCKED` for **row-level safety**
- Enable the lock when you want to reduce duplicate work and DB contention across instances

## Full Configuration Example

```yaml
outbox:
  enabled: true

  tables:
    trade:
      table-name: trade_outbox
      aggregate-type: Trade
      topic: trade-events
    payment:
      table-name: payment_outbox
      aggregate-type: Payment
      topic: payment-events

  relay:
    enabled: true
    poll-interval-ms: 1000
    batch-size: 50
    max-retries: 5
    backoff-base-ms: 1000
    backoff-max-ms: 60000
    batch-db-updates: false        # true for single JDBC batch per poll cycle

  cleanup:
    enabled: true
    cron: "0 0 2 * * *"
    retention-hours: 72

  health:
    pending-warn-threshold: 100
    max-pending-age-minutes: 30

  compression:
    enabled: false

  distributed-lock:
    enabled: true
    lock-at-most-ms: 30000
```

## Project Structure

```
src/main/java/com/company/outbox/
├── cleanup/
│   └── OutboxCleanupService.java       # Scheduled cleanup of published events
├── compression/
│   ├── PayloadCompressor.java          # Compression contract
│   └── GzipPayloadCompressor.java      # Gzip + Base64 implementation
├── config/
│   ├── OutboxAutoConfiguration.java    # Spring Boot auto-configuration
│   ├── OutboxProperties.java           # Configuration properties
│   ├── OutboxTableProperties.java      # Per-table configuration
│   └── TableResolver.java             # Aggregate type -> table name resolver
├── domain/
│   ├── OutboxEvent.java                # Immutable domain object (builder pattern)
│   └── OutboxEventStatus.java          # PENDING, PROCESSING, RETRY, PUBLISHED, FAILED
├── exception/
│   └── OutboxException.java            # Runtime exception
├── health/
│   └── OutboxHealthIndicator.java      # Spring Boot Actuator health
├── hooks/
│   ├── OutboxHooks.java                # Persistence lifecycle hooks
│   ├── DefaultOutboxHooks.java         # No-op default
│   ├── RelayHooks.java                 # Relay lifecycle hooks
│   └── DefaultRelayHooks.java          # No-op default
├── lock/
│   ├── OutboxLockProvider.java         # Distributed lock contract
│   └── JdbcOutboxLockProvider.java     # JDBC-based implementation
├── metrics/
│   └── OutboxMetrics.java              # Micrometer metrics
├── publisher/
│   ├── OutboxEventPublisher.java       # Transport-agnostic publisher contract
│   └── OutboxBatchPublisher.java       # Optional batch publisher contract
├── relay/
│   ├── OutboxRelay.java                # Three-phase polling relay with retry/backoff
│   └── OutboxEventFilter.java          # Event filter contract
├── repository/
│   ├── OutboxJdbcRepository.java       # JDBC repository (no JPA)
│   └── StatusUpdate.java              # Deferred status update record for batch finalization
├── serialization/
│   ├── PayloadSerializer.java          # Serialization contract
│   └── JacksonPayloadSerializer.java   # Default Jackson implementation
└── service/
    └── OutboxService.java              # Core service (@Transactional MANDATORY)
```

## Testing

The starter ships with **175 tests** covering:

- Unit tests for all components (relay, service, repository, health, metrics, hooks, compression, serialization)
- Integration tests with H2 in-memory database (relay, cleanup, full lifecycle)
- Three-phase relay processing (claim, publish, finalize)
- RETRY status lifecycle and backoff expiry
- Immediate vs. batched DB update strategies
- Batch publisher with fallback to individual
- Distributed lock provider (acquire, release, expiry, contention)
- Auto-configuration conditionality and bean overridability
- Edge cases (backoff cap, retry exhaustion, event filtering, lock crash recovery, H2 detection)

```bash
mvn clean test
```

## License

Proprietary - Company Internal Use
