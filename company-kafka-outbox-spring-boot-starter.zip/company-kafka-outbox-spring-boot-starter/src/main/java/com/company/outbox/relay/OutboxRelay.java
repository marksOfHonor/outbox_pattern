package com.company.outbox.relay;

import com.company.outbox.config.OutboxProperties;
import com.company.outbox.config.OutboxTableProperties;
import com.company.outbox.domain.OutboxEvent;
import com.company.outbox.domain.OutboxEventStatus;
import com.company.outbox.hooks.RelayHooks;
import com.company.outbox.lock.OutboxLockProvider;
import com.company.outbox.metrics.OutboxMetrics;
import com.company.outbox.publisher.OutboxBatchPublisher;
import com.company.outbox.publisher.OutboxEventPublisher;
import com.company.outbox.repository.OutboxJdbcRepository;
import com.company.outbox.repository.StatusUpdate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

import javax.sql.DataSource;
import java.time.Duration;
import java.time.Instant;
import java.util.*;

/**
 * Polling publisher that reads PENDING/RETRY outbox events and delegates publishing
 * to an {@link OutboxEventPublisher} or {@link OutboxBatchPublisher} implementation.
 *
 * <p>Uses a three-phase processing model:
 * <ol>
 *   <li><b>Claim</b> (short TX): SELECT FOR UPDATE SKIP LOCKED, mark events PROCESSING</li>
 *   <li><b>Publish</b> (outside TX): send events via the publisher — no DB locks held</li>
 *   <li><b>Finalize</b>: mark PUBLISHED, RETRY (with backoff), or FAILED.
 *       Finalization can be immediate (per-event TX) or batched (single JDBC batch TX).</li>
 * </ol>
 *
 * <p>Stuck PROCESSING events (e.g., from a crashed instance) are automatically recovered
 * after the claim expiry passes.
 */
public class OutboxRelay {

    private static final Logger log = LoggerFactory.getLogger(OutboxRelay.class);
    private static final String RELAY_LOCK_NAME = "outbox-relay";
    private static final Duration CLAIM_TIMEOUT = Duration.ofMinutes(5);

    private final OutboxJdbcRepository repository;
    private final OutboxEventPublisher publisher;
    private final OutboxBatchPublisher batchPublisher;
    private final OutboxProperties properties;
    private final OutboxMetrics metrics;
    private final RelayHooks relayHooks;
    private final OutboxEventFilter eventFilter;
    private final OutboxLockProvider lockProvider;
    private final TransactionTemplate transactionTemplate;
    private final boolean supportsSkipLocked;
    private final boolean batchDbUpdates;
    private final Map<String, String> tableToDestination;
    private final Duration lockDuration;

    public OutboxRelay(OutboxJdbcRepository repository,
                       OutboxEventPublisher publisher,
                       OutboxBatchPublisher batchPublisher,
                       OutboxProperties properties,
                       OutboxMetrics metrics,
                       RelayHooks relayHooks,
                       OutboxEventFilter eventFilter,
                       PlatformTransactionManager transactionManager,
                       DataSource dataSource) {
        this(repository, publisher, batchPublisher, properties, metrics, relayHooks,
                eventFilter, null, transactionManager, dataSource);
    }

    public OutboxRelay(OutboxJdbcRepository repository,
                       OutboxEventPublisher publisher,
                       OutboxBatchPublisher batchPublisher,
                       OutboxProperties properties,
                       OutboxMetrics metrics,
                       RelayHooks relayHooks,
                       OutboxEventFilter eventFilter,
                       OutboxLockProvider lockProvider,
                       PlatformTransactionManager transactionManager,
                       DataSource dataSource) {
        this.repository = repository;
        this.publisher = publisher;
        this.batchPublisher = batchPublisher;
        this.properties = properties;
        this.metrics = metrics;
        this.relayHooks = relayHooks;
        this.eventFilter = eventFilter;
        this.lockProvider = lockProvider;

        this.transactionTemplate = new TransactionTemplate(transactionManager);
        this.transactionTemplate.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);

        this.supportsSkipLocked = detectSkipLockedSupport(dataSource);
        this.batchDbUpdates = properties.getRelay().isBatchDbUpdates();
        this.tableToDestination = buildTableToDestinationMap(properties);
        this.lockDuration = Duration.ofMillis(properties.getDistributedLock().getLockAtMostMs());

        validateDestinationConfiguration(properties);
    }

    /**
     * Polls all configured outbox tables for PENDING/RETRY events and publishes them.
     */
    @Scheduled(fixedDelayString = "${outbox.relay.poll-interval-ms:1000}")
    public void pollAndPublish() {
        if (lockProvider != null) {
            if (!lockProvider.tryAcquire(RELAY_LOCK_NAME, lockDuration)) {
                log.debug("Could not acquire relay lock, skipping poll cycle");
                return;
            }
            try {
                doPollAndPublish();
            } finally {
                lockProvider.release(RELAY_LOCK_NAME);
            }
        } else {
            doPollAndPublish();
        }
    }

    private void doPollAndPublish() {
        for (var entry : properties.getTables().entrySet()) {
            String tableName = entry.getValue().getTableName();
            try {
                processTable(tableName);
            } catch (Exception e) {
                log.error("Error processing outbox table {}: {}", tableName, e.getMessage(), e);
            }
        }
    }

    /**
     * Three-phase processing: claim -> publish -> finalize.
     */
    private void processTable(String tableName) {
        // Phase 1: Claim events in a short transaction
        List<OutboxEvent> events = transactionTemplate.execute(status -> {
            List<OutboxEvent> pending = repository.findPendingEvents(
                    tableName, properties.getRelay().getBatchSize(), supportsSkipLocked);
            if (!pending.isEmpty()) {
                Instant claimExpiry = Instant.now().plus(CLAIM_TIMEOUT);
                repository.markAsProcessing(tableName, pending, claimExpiry);
            }
            return pending;
        });

        if (events == null || events.isEmpty()) {
            return;
        }

        String destination = Objects.requireNonNull(
                tableToDestination.get(tableName),
                "No destination configured for table: " + tableName);

        log.debug("Processing {} events from {} -> {}", events.size(), tableName, destination);

        // Phase 2 & 3: Publish outside TX, then finalize
        if (batchPublisher != null) {
            processBatch(tableName, destination, events);
        } else {
            processIndividual(tableName, destination, events);
        }
    }

    // ---- Individual publishing path ----

    private void processIndividual(String tableName, String destination, List<OutboxEvent> events) {
        if (batchDbUpdates) {
            // Collect all outcomes, then batch finalize in one TX
            List<StatusUpdate> updates = new ArrayList<>();
            for (OutboxEvent event : events) {
                updates.add(attemptPublish(tableName, destination, event));
            }
            batchFinalizeStatuses(tableName, updates);
        } else {
            // Immediate finalize per event (existing behavior)
            for (OutboxEvent event : events) {
                StatusUpdate outcome = attemptPublish(tableName, destination, event);
                finalizeStatus(tableName, outcome);
            }
        }
    }

    // ---- Batch publishing path ----

    private void processBatch(String tableName, String destination, List<OutboxEvent> events) {
        List<StatusUpdate> allUpdates = new ArrayList<>();
        List<OutboxEvent> toPublish = new ArrayList<>();

        // Separate filtered from publishable
        for (OutboxEvent event : events) {
            if (!eventFilter.shouldPublish(event)) {
                allUpdates.add(new StatusUpdate(event.getId(),
                        OutboxEventStatus.PUBLISHED, Instant.now(), event.getRetryCount(), null));
                log.debug("Filtered out event {} from {}", event.getId(), tableName);
            } else {
                toPublish.add(event);
            }
        }

        if (!toPublish.isEmpty()) {
            try {
                for (OutboxEvent event : toPublish) {
                    relayHooks.beforePublish(event, destination);
                }

                // Publish outside any transaction — no DB locks held
                batchPublisher.publishBatch(toPublish, destination);

                // All published successfully
                for (OutboxEvent event : toPublish) {
                    allUpdates.add(new StatusUpdate(event.getId(),
                            OutboxEventStatus.PUBLISHED, Instant.now(), event.getRetryCount(), null));
                    metrics.recordRelayPublished(tableName, event.getEventType());
                    relayHooks.afterPublish(event, destination);
                }

                log.debug("Batch published {} events from {} to {}", toPublish.size(), tableName, destination);
            } catch (Exception e) {
                log.warn("Batch publish failed for {} events from {}, falling back to individual: {}",
                        toPublish.size(), tableName, e.getMessage());
                // Fall back to individual publishing
                for (OutboxEvent event : toPublish) {
                    allUpdates.add(attemptPublish(tableName, destination, event));
                }
            }
        }

        // Batch finalize all updates in one transaction
        if (!allUpdates.isEmpty()) {
            batchFinalizeStatuses(tableName, allUpdates);
        }
    }

    // ---- Core publish logic ----

    /**
     * Attempts to publish a single event and returns the outcome as a {@link StatusUpdate}.
     * Handles filtering, hooks, and metrics. Does NOT write to the database.
     */
    StatusUpdate attemptPublish(String tableName, String destination, OutboxEvent event) {
        if (!eventFilter.shouldPublish(event)) {
            log.debug("Filtered out event {} from {}", event.getId(), tableName);
            return new StatusUpdate(event.getId(),
                    OutboxEventStatus.PUBLISHED, Instant.now(), event.getRetryCount(), null);
        }

        try {
            relayHooks.beforePublish(event, destination);

            // Publish outside any transaction — no DB locks held
            publisher.publish(event, destination);

            metrics.recordRelayPublished(tableName, event.getEventType());
            relayHooks.afterPublish(event, destination);

            log.debug("Published event {} from {} to {}", event.getId(), tableName, destination);
            return new StatusUpdate(event.getId(),
                    OutboxEventStatus.PUBLISHED, Instant.now(), event.getRetryCount(), null);
        } catch (Exception e) {
            relayHooks.onPublishFailure(event, destination, e);
            return computeFailureOutcome(tableName, event, e);
        }
    }

    private StatusUpdate computeFailureOutcome(String tableName, OutboxEvent event, Exception e) {
        int newRetryCount = event.getRetryCount() + 1;
        int maxRetries = properties.getRelay().getMaxRetries();

        if (newRetryCount >= maxRetries) {
            metrics.recordRelayFailed(tableName, event.getEventType());
            log.error("Event {} in {} permanently failed after {} retries: {}",
                    event.getId(), tableName, newRetryCount, e.getMessage(), e);
            return new StatusUpdate(event.getId(),
                    OutboxEventStatus.FAILED, Instant.now(), newRetryCount, null);
        } else {
            Instant nextRetryAt = computeNextRetryAt(newRetryCount);
            metrics.recordRelayRetried(tableName, event.getEventType());
            log.warn("Event {} in {} failed, retry {}/{}, next retry at {}: {}",
                    event.getId(), tableName, newRetryCount, maxRetries, nextRetryAt, e.getMessage());
            return new StatusUpdate(event.getId(),
                    OutboxEventStatus.RETRY, Instant.now(), newRetryCount, nextRetryAt);
        }
    }

    // ---- Finalization ----

    /**
     * Writes a single event's final status in a short, independent transaction.
     */
    private void finalizeStatus(String tableName, StatusUpdate update) {
        transactionTemplate.executeWithoutResult(s ->
                repository.updateStatus(tableName, update.eventId(), update.status(),
                        update.processedAt(), update.retryCount(), update.nextRetryAt()));
    }

    /**
     * Batch-writes all event outcomes in a single transaction using JDBC batch.
     */
    private void batchFinalizeStatuses(String tableName, List<StatusUpdate> updates) {
        transactionTemplate.executeWithoutResult(s ->
                repository.batchUpdateStatuses(tableName, updates));
    }

    // ---- Backoff ----

    /**
     * Computes the next retry time using exponential backoff with a cap.
     * Formula: now + min(baseMs * 2^(retryCount-1), maxMs)
     */
    Instant computeNextRetryAt(int retryCount) {
        long baseMs = properties.getRelay().getBackoffBaseMs();
        long maxMs = properties.getRelay().getBackoffMaxMs();
        long delayMs = Math.min(baseMs * (1L << (retryCount - 1)), maxMs);
        return Instant.now().plusMillis(delayMs);
    }

    // ---- Initialization helpers ----

    private boolean detectSkipLockedSupport(DataSource dataSource) {
        try (var conn = dataSource.getConnection()) {
            String productName = conn.getMetaData().getDatabaseProductName();
            boolean supported = !productName.toLowerCase().contains("h2");
            log.info("Database: {}. SKIP LOCKED support: {}", productName, supported);
            return supported;
        } catch (Exception e) {
            log.warn("Could not detect database product, assuming SKIP LOCKED is supported", e);
            return true;
        }
    }

    private Map<String, String> buildTableToDestinationMap(OutboxProperties properties) {
        Map<String, String> map = new HashMap<>();
        for (var entry : properties.getTables().entrySet()) {
            OutboxTableProperties tableProps = entry.getValue();
            if (tableProps.getTopic() != null && !tableProps.getTopic().isBlank()) {
                map.put(tableProps.getTableName(), tableProps.getTopic());
            }
        }
        return map;
    }

    private void validateDestinationConfiguration(OutboxProperties properties) {
        for (var entry : properties.getTables().entrySet()) {
            OutboxTableProperties tableProps = entry.getValue();
            if (tableProps.getTopic() == null || tableProps.getTopic().isBlank()) {
                throw new IllegalStateException(
                        "outbox.tables." + entry.getKey() + ".topic must not be blank when relay is enabled. " +
                        "Each table must specify a destination for the relay to publish to.");
            }
        }
    }
}
