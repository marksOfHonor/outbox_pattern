package com.company.outbox.publisher;

import com.company.outbox.domain.OutboxEvent;

import java.util.List;

/**
 * Contract for batch-publishing outbox events to an external messaging system.
 * <p>
 * When provided, the relay will send all events from a single table poll cycle
 * as a batch instead of one-by-one. This can significantly improve throughput
 * for transports that support batch sends (Kafka producer batching, SQS batch send, etc.).
 * <p>
 * If both {@link OutboxEventPublisher} and {@link OutboxBatchPublisher} are available,
 * the relay prefers the batch publisher.
 */
public interface OutboxBatchPublisher {

    /**
     * Publishes a batch of outbox events to the configured destination.
     * <p>
     * The implementation should be atomic — either all events succeed or
     * the entire batch fails. On partial failure, throw an exception and
     * the relay will fall back to individual event processing.
     *
     * @param events      the batch of outbox events to publish
     * @param destination the target destination (e.g., Kafka topic, queue name)
     * @throws Exception if publishing the batch fails
     */
    void publishBatch(List<OutboxEvent> events, String destination) throws Exception;
}
