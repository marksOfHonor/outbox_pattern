package com.company.outbox.relay;

import com.company.outbox.domain.OutboxEvent;

/**
 * Filter applied by the relay before publishing an event.
 * Implementations can decide whether a given event should be published
 * based on its type, headers, payload, or any other criteria.
 * <p>
 * Events rejected by the filter are marked as PUBLISHED (skipped) to prevent
 * them from being reprocessed.
 */
@FunctionalInterface
public interface OutboxEventFilter {

    /**
     * Determines whether the given event should be published.
     *
     * @param event the outbox event to evaluate
     * @return {@code true} if the event should be published, {@code false} to skip it
     */
    boolean shouldPublish(OutboxEvent event);
}
