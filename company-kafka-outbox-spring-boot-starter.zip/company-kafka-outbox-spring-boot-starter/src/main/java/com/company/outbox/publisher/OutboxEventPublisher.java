package com.company.outbox.publisher;

import com.company.outbox.domain.OutboxEvent;

/**
 * Contract for publishing outbox events to an external messaging system.
 * <p>
 * Implementations are provided by the consuming application, keeping the
 * outbox starter transport-agnostic (Kafka, RabbitMQ, SQS, etc.).
 * <p>
 * The relay calls {@link #publish} synchronously within a database transaction.
 * If the method returns normally, the event is marked as PUBLISHED.
 * If it throws, the relay applies retry logic.
 */
public interface OutboxEventPublisher {

    /**
     * Publishes the given outbox event to the configured destination.
     *
     * @param event       the outbox event to publish
     * @param destination the target destination (e.g., Kafka topic, RabbitMQ exchange, SQS queue)
     * @throws Exception if publishing fails — the relay will retry or mark as FAILED
     */
    void publish(OutboxEvent event, String destination) throws Exception;
}
