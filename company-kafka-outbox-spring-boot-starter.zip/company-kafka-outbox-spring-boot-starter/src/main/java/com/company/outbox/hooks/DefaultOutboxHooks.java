package com.company.outbox.hooks;

import com.company.outbox.domain.OutboxEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Default no-op implementation of {@link OutboxHooks}.
 * Logs lifecycle events at trace/warn level. Microservices can override
 * by providing their own {@link OutboxHooks} bean.
 */
public class DefaultOutboxHooks implements OutboxHooks {

    private static final Logger log = LoggerFactory.getLogger(DefaultOutboxHooks.class);

    @Override
    public void beforePersist(OutboxEvent event) {
        log.trace("Before persisting outbox event: {}", event.getId());
    }

    @Override
    public void afterPersist(OutboxEvent event) {
        log.trace("After persisting outbox event: {}", event.getId());
    }

    @Override
    public void onError(OutboxEvent event, Exception exception) {
        log.warn("Error persisting outbox event {}: {}", event.getId(), exception.getMessage());
    }
}
