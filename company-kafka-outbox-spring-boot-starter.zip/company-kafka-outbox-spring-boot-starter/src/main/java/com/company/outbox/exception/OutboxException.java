package com.company.outbox.exception;

/**
 * Exception thrown when an outbox operation fails.
 */
public class OutboxException extends RuntimeException {

    public OutboxException(String message) {
        super(message);
    }

    public OutboxException(String message, Throwable cause) {
        super(message, cause);
    }
}
