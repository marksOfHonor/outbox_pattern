package com.company.outbox.serialization;

import com.company.outbox.exception.OutboxException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Default {@link PayloadSerializer} implementation using Jackson.
 */
public class JacksonPayloadSerializer implements PayloadSerializer {

    private final ObjectMapper objectMapper;

    public JacksonPayloadSerializer(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    public String serialize(Object payload) {
        if (payload == null) {
            throw new OutboxException("Payload must not be null");
        }
        if (payload instanceof String s) {
            return s;
        }
        try {
            return objectMapper.writeValueAsString(payload);
        } catch (JsonProcessingException e) {
            throw new OutboxException("Failed to serialize payload: " + e.getMessage(), e);
        }
    }
}
