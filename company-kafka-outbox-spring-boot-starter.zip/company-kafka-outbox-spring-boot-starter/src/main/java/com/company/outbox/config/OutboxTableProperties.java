package com.company.outbox.config;

/**
 * Configuration for a single outbox table mapping.
 * Binds from {@code outbox.tables.<key>}.
 */
public class OutboxTableProperties {

    /**
     * The database table name (e.g., "trade_outbox").
     */
    private String tableName;

    /**
     * The aggregate type that maps to this table (e.g., "Trade").
     */
    private String aggregateType;

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getAggregateType() {
        return aggregateType;
    }

    public void setAggregateType(String aggregateType) {
        this.aggregateType = aggregateType;
    }

    /**
     * The Kafka topic to publish events to (required when relay is enabled).
     */
    private String topic;

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }
}
