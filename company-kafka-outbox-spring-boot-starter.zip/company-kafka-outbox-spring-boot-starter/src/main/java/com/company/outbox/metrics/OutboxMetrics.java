package com.company.outbox.metrics;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;

/**
 * Outbox observability metrics using Micrometer.
 * All methods are no-ops when {@code meterRegistry} is {@code null},
 * which happens when Spring Boot Actuator is not on the classpath.
 */
public class OutboxMetrics {

    private final MeterRegistry meterRegistry;

    public OutboxMetrics(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
    }

    /**
     * Records a successfully stored outbox event.
     */
    public void recordStored(String table, String eventType) {
        if (meterRegistry == null) return;
        Counter.builder("outbox.events.stored")
                .tag("table", table)
                .tag("eventType", eventType)
                .register(meterRegistry)
                .increment();
    }

    /**
     * Records a failed outbox event persistence.
     */
    public void recordFailed(String table, String eventType) {
        if (meterRegistry == null) return;
        Counter.builder("outbox.events.failed")
                .tag("table", table)
                .tag("eventType", eventType)
                .register(meterRegistry)
                .increment();
    }

    /**
     * Starts a latency timer sample.
     */
    public Timer.Sample startTimer() {
        if (meterRegistry == null) return null;
        return Timer.start(meterRegistry);
    }

    /**
     * Stops the latency timer and records the duration.
     */
    public void stopTimer(Timer.Sample sample, String table, String eventType) {
        if (meterRegistry == null || sample == null) return;
        sample.stop(Timer.builder("outbox.persist.latency")
                .tag("table", table)
                .tag("eventType", eventType)
                .register(meterRegistry));
    }

    /**
     * Records a successfully relayed (published to Kafka) event.
     */
    public void recordRelayPublished(String table, String eventType) {
        if (meterRegistry == null) return;
        Counter.builder("outbox.relay.published")
                .tag("table", table)
                .tag("eventType", eventType)
                .register(meterRegistry)
                .increment();
    }

    /**
     * Records a permanently failed relay event (max retries exceeded).
     */
    public void recordRelayFailed(String table, String eventType) {
        if (meterRegistry == null) return;
        Counter.builder("outbox.relay.failed")
                .tag("table", table)
                .tag("eventType", eventType)
                .register(meterRegistry)
                .increment();
    }

    /**
     * Records a relay event that failed and will be retried.
     */
    public void recordRelayRetried(String table, String eventType) {
        if (meterRegistry == null) return;
        Counter.builder("outbox.relay.retried")
                .tag("table", table)
                .tag("eventType", eventType)
                .register(meterRegistry)
                .increment();
    }

    /**
     * Records the number of published events cleaned up.
     */
    public void recordCleanupDeleted(String table, int count) {
        if (meterRegistry == null) return;
        Counter.builder("outbox.cleanup.deleted")
                .tag("table", table)
                .register(meterRegistry)
                .increment(count);
    }
}
