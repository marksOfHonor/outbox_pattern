package com.company.outbox.hooks;

import com.company.outbox.domain.OutboxEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Default no-op implementation of {@link RelayHooks}.
 * Logs relay lifecycle events at trace/warn level.
 * Consumers can override by providing their own {@link RelayHooks} bean.
 */
public class DefaultRelayHooks implements RelayHooks {

    private static final Logger log = LoggerFactory.getLogger(DefaultRelayHooks.class);

    @Override
    public void beforePublish(OutboxEvent event, String destination) {
        log.trace("Before publishing outbox event {} to {}", event.getId(), destination);
    }

    @Override
    public void afterPublish(OutboxEvent event, String destination) {
        log.trace("Published outbox event {} to {}", event.getId(), destination);
    }

    @Override
    public void onPublishFailure(OutboxEvent event, String destination, Exception exception) {
        log.warn("Failed to publish outbox event {} to {}: {}",
                event.getId(), destination, exception.getMessage());
    }
}
