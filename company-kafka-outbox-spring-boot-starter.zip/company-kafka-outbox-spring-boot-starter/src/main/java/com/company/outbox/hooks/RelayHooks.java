package com.company.outbox.hooks;

import com.company.outbox.domain.OutboxEvent;

/**
 * Extension hooks for the relay publishing lifecycle.
 * Consumers can implement this interface to add cross-cutting concerns
 * such as tracing, logging, or enrichment around event publishing.
 */
public interface RelayHooks {

    /**
     * Called before the event is published to the destination.
     *
     * @param event       the outbox event about to be published
     * @param destination the target destination (e.g., Kafka topic, queue name)
     */
    void beforePublish(OutboxEvent event, String destination);

    /**
     * Called after the event has been successfully published.
     *
     * @param event       the outbox event that was published
     * @param destination the target destination
     */
    void afterPublish(OutboxEvent event, String destination);

    /**
     * Called when publishing an event fails.
     *
     * @param event       the outbox event that failed to publish
     * @param destination the target destination
     * @param exception   the exception that occurred
     */
    void onPublishFailure(OutboxEvent event, String destination, Exception exception);
}
