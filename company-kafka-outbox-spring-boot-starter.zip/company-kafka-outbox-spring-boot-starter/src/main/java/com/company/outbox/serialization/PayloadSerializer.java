package com.company.outbox.serialization;

/**
 * Strategy interface for serializing outbox event payloads.
 * Microservices can provide their own implementation to override the default.
 */
public interface PayloadSerializer {

    /**
     * Serializes the given payload object to a string representation.
     *
     * @param payload the payload to serialize
     * @return the serialized string
     */
    String serialize(Object payload);
}
