package com.company.outbox.domain;

/**
 * Lifecycle status of an outbox event.
 */
public enum OutboxEventStatus {
    /** Newly created, never attempted. */
    PENDING,
    /** Claimed by a relay instance, publish in progress. */
    PROCESSING,
    /** Publish failed, waiting for retry (backoff not yet expired). */
    RETRY,
    /** Successfully published. */
    PUBLISHED,
    /** Permanently failed after exhausting all retries. */
    FAILED
}
