package com.company.outbox.lock;

import java.time.Duration;

/**
 * Contract for distributed locking across outbox instances.
 * Implementations ensure only one instance processes relay/cleanup at a time.
 */
public interface OutboxLockProvider {

    /**
     * Attempts to acquire a named lock for the specified duration.
     *
     * @param lockName     unique name identifying the lock (e.g., "outbox-relay", "outbox-cleanup")
     * @param lockDuration maximum duration the lock should be held
     * @return true if the lock was acquired, false if another instance holds it
     */
    boolean tryAcquire(String lockName, Duration lockDuration);

    /**
     * Releases the named lock. Called after processing completes.
     * Implementations should be idempotent — releasing an unheld lock is a no-op.
     *
     * @param lockName unique name identifying the lock
     */
    void release(String lockName);
}
