package com.company.outbox.health;

import com.company.outbox.config.OutboxProperties;
import com.company.outbox.config.TableResolver;
import com.company.outbox.repository.OutboxJdbcRepository;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Spring Boot health indicator that reports the state of outbox tables.
 * Reports per-table: pending count, failed count, oldest pending age.
 * Degrades to DOWN based on configurable thresholds.
 * Uses a single SQL query per table for efficiency.
 */
public class OutboxHealthIndicator implements HealthIndicator {

    private final OutboxJdbcRepository repository;
    private final TableResolver tableResolver;
    private final OutboxProperties properties;

    public OutboxHealthIndicator(OutboxJdbcRepository repository,
                                  TableResolver tableResolver,
                                  OutboxProperties properties) {
        this.repository = repository;
        this.tableResolver = tableResolver;
        this.properties = properties;
    }

    @Override
    public Health health() {
        int pendingWarnThreshold = properties.getHealth().getPendingWarnThreshold();
        int maxPendingAgeMinutes = properties.getHealth().getMaxPendingAgeMinutes();

        Map<String, Object> details = new LinkedHashMap<>();
        boolean degraded = false;

        for (String tableName : tableResolver.getAllTableNames()) {
            Map<String, Object> tableDetails = new LinkedHashMap<>();
            try {
                Map<String, Object> stats = repository.getHealthStats(tableName);
                int pendingCount = (int) stats.get("pendingCount");
                int retryCount = (int) stats.get("retryCount");
                int failedCount = (int) stats.get("failedCount");
                long oldestPendingAgeSec = (long) stats.get("oldestPendingAgeSeconds");
                long oldestPendingAgeMin = oldestPendingAgeSec / 60;

                tableDetails.put("pendingCount", pendingCount);
                tableDetails.put("retryCount", retryCount);
                tableDetails.put("failedCount", failedCount);
                tableDetails.put("oldestPendingAgeSeconds", oldestPendingAgeSec);

                int totalUnprocessed = pendingCount + retryCount;
                if (totalUnprocessed > pendingWarnThreshold) {
                    tableDetails.put("warning", "Unprocessed count " + totalUnprocessed +
                            " (pending=" + pendingCount + ", retry=" + retryCount +
                            ") exceeds threshold " + pendingWarnThreshold);
                    degraded = true;
                }

                if (oldestPendingAgeMin > maxPendingAgeMinutes) {
                    tableDetails.put("warning", "Oldest unprocessed event is " + oldestPendingAgeMin +
                            " minutes old (threshold: " + maxPendingAgeMinutes + ")");
                    degraded = true;
                }

                List<String> attentions = new ArrayList<>();
                if (retryCount > 0) {
                    attentions.add(retryCount + " events awaiting retry");
                }
                if (failedCount > 0) {
                    attentions.add(failedCount + " failed events require investigation");
                }
                if (attentions.size() == 1) {
                    tableDetails.put("attention", attentions.get(0));
                } else if (attentions.size() > 1) {
                    tableDetails.put("attention", attentions);
                }
            } catch (Exception e) {
                tableDetails.put("error", e.getMessage());
                degraded = true;
            }

            details.put(tableName, tableDetails);
        }

        Health.Builder builder = degraded ? Health.down() : Health.up();
        return builder.withDetails(details).build();
    }
}
