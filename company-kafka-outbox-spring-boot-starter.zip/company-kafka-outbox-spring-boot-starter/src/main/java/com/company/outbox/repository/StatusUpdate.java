package com.company.outbox.repository;

import com.company.outbox.domain.OutboxEventStatus;

import java.time.Instant;
import java.util.UUID;

/**
 * Represents a deferred status update for an outbox event.
 * Used by the relay to collect publish outcomes before batch-writing them to the database.
 */
public record StatusUpdate(
        UUID eventId,
        OutboxEventStatus status,
        Instant processedAt,
        int retryCount,
        Instant nextRetryAt
) {}
