package com.company.outbox.service;

import com.company.outbox.config.TableResolver;
import com.company.outbox.domain.OutboxEvent;
import com.company.outbox.exception.OutboxException;
import com.company.outbox.hooks.OutboxHooks;
import com.company.outbox.metrics.OutboxMetrics;
import com.company.outbox.repository.OutboxJdbcRepository;
import com.company.outbox.serialization.PayloadSerializer;
import io.micrometer.core.instrument.Timer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

/**
 * Core service for storing outbox events.
 * The target table is resolved automatically from the aggregate type via {@link TableResolver}.
 * Must be called within an existing transaction (MANDATORY propagation).
 */
public class OutboxService {

    private static final Logger log = LoggerFactory.getLogger(OutboxService.class);

    private final OutboxJdbcRepository repository;
    private final PayloadSerializer serializer;
    private final OutboxHooks hooks;
    private final OutboxMetrics metrics;
    private final TableResolver tableResolver;

    public OutboxService(OutboxJdbcRepository repository,
                         PayloadSerializer serializer,
                         OutboxHooks hooks,
                         OutboxMetrics metrics,
                         TableResolver tableResolver) {
        this.repository = repository;
        this.serializer = serializer;
        this.hooks = hooks;
        this.metrics = metrics;
        this.tableResolver = tableResolver;
    }

    /**
     * Stores an outbox event without headers.
     *
     * @param aggregateType the aggregate type (e.g., "Trade", "Allocation")
     * @param aggregateId   the aggregate identifier
     * @param eventType     the event subtype (e.g., "CREATED", "UPDATED", "DELETED")
     * @param payload       the event payload (will be serialized)
     * @return the persisted {@link OutboxEvent}
     */
    @Transactional(propagation = Propagation.MANDATORY)
    public OutboxEvent storeEvent(String aggregateType,
                                  String aggregateId,
                                  String eventType,
                                  Object payload) {
        return storeEvent(aggregateType, aggregateId, eventType, payload, Map.of());
    }

    /**
     * Stores an outbox event with headers.
     * The target outbox table is resolved from the aggregate type via configuration.
     *
     * @param aggregateType the aggregate type (e.g., "Trade", "Allocation")
     * @param aggregateId   the aggregate identifier
     * @param eventType     the event subtype (e.g., "CREATED", "UPDATED", "DELETED")
     * @param payload       the event payload (will be serialized)
     * @param headers       optional headers to store alongside the event
     * @return the persisted {@link OutboxEvent}
     */
    @Transactional(propagation = Propagation.MANDATORY)
    public OutboxEvent storeEvent(String aggregateType,
                                  String aggregateId,
                                  String eventType,
                                  Object payload,
                                  Map<String, String> headers) {

        String tableName;
        try {
            tableName = tableResolver.resolve(aggregateType);
        } catch (OutboxException e) {
            metrics.recordFailed(aggregateType, eventType);
            throw e;
        }

        Timer.Sample timerSample = metrics.startTimer();

        String serializedPayload = serializer.serialize(payload);

        OutboxEvent event = OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType(aggregateType)
                .aggregateId(aggregateId)
                .eventType(eventType)
                .payload(serializedPayload)
                .headers(headers)
                .createdAt(Instant.now())
                .build();

        try {
            hooks.beforePersist(event);
            repository.save(tableName, event);
            hooks.afterPersist(event);
            metrics.recordStored(tableName, eventType);
            metrics.stopTimer(timerSample, tableName, eventType);
            log.debug("Outbox event stored: {} in table {}", event.getId(), tableName);
            return event;
        } catch (Exception e) {
            metrics.recordFailed(tableName, eventType);
            hooks.onError(event, e);
            throw new OutboxException("Failed to store outbox event in table '" + tableName + "': " + e.getMessage(), e);
        }
    }
}
