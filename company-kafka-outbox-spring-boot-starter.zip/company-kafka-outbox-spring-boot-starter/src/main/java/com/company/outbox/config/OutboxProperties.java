package com.company.outbox.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Configuration properties for the outbox starter.
 */
@ConfigurationProperties(prefix = "outbox")
public class OutboxProperties {

    private boolean enabled = true;

    private Map<String, OutboxTableProperties> tables = new LinkedHashMap<>();

    private Relay relay = new Relay();

    private Cleanup cleanup = new Cleanup();

    private Health health = new Health();

    private Compression compression = new Compression();

    private DistributedLock distributedLock = new DistributedLock();

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public Map<String, OutboxTableProperties> getTables() {
        return tables;
    }

    public void setTables(Map<String, OutboxTableProperties> tables) {
        this.tables = tables;
    }

    public Relay getRelay() {
        return relay;
    }

    public void setRelay(Relay relay) {
        this.relay = relay;
    }

    public Cleanup getCleanup() {
        return cleanup;
    }

    public void setCleanup(Cleanup cleanup) {
        this.cleanup = cleanup;
    }

    public Health getHealth() {
        return health;
    }

    public void setHealth(Health health) {
        this.health = health;
    }

    public Compression getCompression() {
        return compression;
    }

    public void setCompression(Compression compression) {
        this.compression = compression;
    }

    public DistributedLock getDistributedLock() {
        return distributedLock;
    }

    public void setDistributedLock(DistributedLock distributedLock) {
        this.distributedLock = distributedLock;
    }

    /**
     * Polling publisher (relay) configuration.
     */
    public static class Relay {

        /** Whether the polling relay is enabled. Default: false. */
        private boolean enabled = false;

        /** Poll interval in milliseconds. Default: 1000. */
        private long pollIntervalMs = 1000;

        /** Max events to fetch per poll per table. Default: 50. */
        private int batchSize = 50;

        /** Max retries before marking an event as FAILED. Default: 3. */
        private int maxRetries = 3;

        /** Base delay in milliseconds for exponential backoff. Default: 1000. */
        private long backoffBaseMs = 1000;

        /** Maximum delay in milliseconds for exponential backoff. Default: 60000. */
        private long backoffMaxMs = 60000;

        /** Whether to batch DB status updates after processing all events in a poll cycle.
         *  When false (default), each event is finalized in its own short transaction immediately after publish.
         *  When true, all outcomes are collected and written in a single JDBC batch update per table. */
        private boolean batchDbUpdates = false;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public long getPollIntervalMs() {
            return pollIntervalMs;
        }

        public void setPollIntervalMs(long pollIntervalMs) {
            this.pollIntervalMs = pollIntervalMs;
        }

        public int getBatchSize() {
            return batchSize;
        }

        public void setBatchSize(int batchSize) {
            this.batchSize = batchSize;
        }

        public int getMaxRetries() {
            return maxRetries;
        }

        public void setMaxRetries(int maxRetries) {
            this.maxRetries = maxRetries;
        }

        public long getBackoffBaseMs() {
            return backoffBaseMs;
        }

        public void setBackoffBaseMs(long backoffBaseMs) {
            this.backoffBaseMs = backoffBaseMs;
        }

        public long getBackoffMaxMs() {
            return backoffMaxMs;
        }

        public void setBackoffMaxMs(long backoffMaxMs) {
            this.backoffMaxMs = backoffMaxMs;
        }

        public boolean isBatchDbUpdates() {
            return batchDbUpdates;
        }

        public void setBatchDbUpdates(boolean batchDbUpdates) {
            this.batchDbUpdates = batchDbUpdates;
        }
    }

    /**
     * Cleanup configuration for published events.
     */
    public static class Cleanup {

        /** Whether cleanup is enabled. Default: false. */
        private boolean enabled = false;

        /** Cron expression for cleanup schedule. Default: daily at 2 AM. */
        private String cron = "0 0 2 * * *";

        /** Retention period in hours for published events. Default: 72 (3 days). */
        private long retentionHours = 72;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getCron() {
            return cron;
        }

        public void setCron(String cron) {
            this.cron = cron;
        }

        public long getRetentionHours() {
            return retentionHours;
        }

        public void setRetentionHours(long retentionHours) {
            this.retentionHours = retentionHours;
        }
    }

    /**
     * Health indicator configuration.
     */
    public static class Health {

        /** Warn threshold for pending event count per table. Default: 100. */
        private int pendingWarnThreshold = 100;

        /** Maximum age in minutes for the oldest PENDING event before health degrades. Default: 30. */
        private int maxPendingAgeMinutes = 30;

        public int getPendingWarnThreshold() {
            return pendingWarnThreshold;
        }

        public void setPendingWarnThreshold(int pendingWarnThreshold) {
            this.pendingWarnThreshold = pendingWarnThreshold;
        }

        public int getMaxPendingAgeMinutes() {
            return maxPendingAgeMinutes;
        }

        public void setMaxPendingAgeMinutes(int maxPendingAgeMinutes) {
            this.maxPendingAgeMinutes = maxPendingAgeMinutes;
        }
    }

    /**
     * Payload compression configuration.
     */
    public static class Compression {

        /** Whether payload compression is enabled. Default: false. */
        private boolean enabled = false;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
    }

    /**
     * Distributed lock configuration for single-leader relay and cleanup.
     */
    public static class DistributedLock {

        /** Whether distributed locking is enabled. Default: false. */
        private boolean enabled = false;

        /** Maximum duration in milliseconds a lock can be held. Default: 30000 (30s). */
        private long lockAtMostMs = 30000;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public long getLockAtMostMs() {
            return lockAtMostMs;
        }

        public void setLockAtMostMs(long lockAtMostMs) {
            this.lockAtMostMs = lockAtMostMs;
        }
    }
}
