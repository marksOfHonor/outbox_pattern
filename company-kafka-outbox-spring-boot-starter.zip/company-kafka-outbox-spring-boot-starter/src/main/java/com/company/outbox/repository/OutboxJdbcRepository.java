package com.company.outbox.repository;

import com.company.outbox.domain.OutboxEvent;
import com.company.outbox.domain.OutboxEventStatus;
import com.company.outbox.exception.OutboxException;
import com.company.outbox.serialization.PayloadSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * JDBC repository for persisting and querying outbox events.
 * Supports dynamic table names with SQL injection protection.
 */
public class OutboxJdbcRepository {

    private static final Pattern TABLE_NAME_PATTERN = Pattern.compile("^[a-zA-Z_][a-zA-Z0-9_]*$");

    private final JdbcTemplate jdbcTemplate;
    private final PayloadSerializer payloadSerializer;
    private final OutboxEventRowMapper rowMapper = new OutboxEventRowMapper();

    public OutboxJdbcRepository(JdbcTemplate jdbcTemplate, PayloadSerializer payloadSerializer) {
        this.jdbcTemplate = jdbcTemplate;
        this.payloadSerializer = payloadSerializer;
    }

    /**
     * Persists an outbox event to the specified table.
     */
    public void save(String tableName, OutboxEvent event) {
        validateTableName(tableName);

        String sql = "INSERT INTO " + tableName +
                " (id, aggregate_type, aggregate_id, event_type, payload, headers, created_at," +
                " status, processed_at, retry_count, next_retry_at, schema_version, compressed)" +
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        String headersJson = serializeHeaders(event);

        jdbcTemplate.update(sql,
                event.getId().toString(),
                event.getAggregateType(),
                event.getAggregateId(),
                event.getEventType(),
                event.getPayload(),
                headersJson,
                Timestamp.from(event.getCreatedAt()),
                event.getStatus().name(),
                event.getProcessedAt() != null ? Timestamp.from(event.getProcessedAt()) : null,
                event.getRetryCount(),
                event.getNextRetryAt() != null ? Timestamp.from(event.getNextRetryAt()) : null,
                event.getSchemaVersion(),
                event.isCompressed());
    }

    /**
     * Finds pending events for relay processing.
     * Also recovers stuck PROCESSING events whose claim has expired.
     *
     * @param tableName        the outbox table to query
     * @param batchSize        max number of events to fetch
     * @param useSkipLocked    whether to use SKIP LOCKED (not supported on H2)
     * @return list of pending events locked for update
     */
    public List<OutboxEvent> findPendingEvents(String tableName, int batchSize, boolean useSkipLocked) {
        validateTableName(tableName);

        String lockClause = useSkipLocked ? " FOR UPDATE SKIP LOCKED" : " FOR UPDATE";
        String sql = "SELECT * FROM " + tableName +
                " WHERE status IN ('PENDING', 'PROCESSING', 'RETRY')" +
                " AND (next_retry_at IS NULL OR next_retry_at <= CURRENT_TIMESTAMP)" +
                " ORDER BY created_at ASC" +
                " FETCH FIRST ? ROWS ONLY" +
                lockClause;

        return jdbcTemplate.query(sql, rowMapper, batchSize);
    }

    /**
     * Marks a list of events as PROCESSING with a claim expiry time.
     * This prevents other relay instances from picking up the same events.
     *
     * @param tableName    the outbox table
     * @param events       events to claim
     * @param claimExpiry  when the claim expires (events become reclaimable)
     */
    public void markAsProcessing(String tableName, List<OutboxEvent> events, Instant claimExpiry) {
        validateTableName(tableName);

        String sql = "UPDATE " + tableName +
                " SET status = ?, next_retry_at = ? WHERE id = ?";

        for (OutboxEvent event : events) {
            jdbcTemplate.update(sql,
                    OutboxEventStatus.PROCESSING.name(),
                    Timestamp.from(claimExpiry),
                    event.getId().toString());
        }
    }

    /**
     * Updates the status of an outbox event.
     */
    public void updateStatus(String tableName, UUID eventId, OutboxEventStatus status,
                             Instant processedAt, int retryCount) {
        updateStatus(tableName, eventId, status, processedAt, retryCount, null);
    }

    /**
     * Updates the status of an outbox event with next retry scheduling.
     */
    public void updateStatus(String tableName, UUID eventId, OutboxEventStatus status,
                             Instant processedAt, int retryCount, Instant nextRetryAt) {
        validateTableName(tableName);

        String sql = "UPDATE " + tableName +
                " SET status = ?, processed_at = ?, retry_count = ?, next_retry_at = ? WHERE id = ?";

        jdbcTemplate.update(sql,
                status.name(),
                processedAt != null ? Timestamp.from(processedAt) : null,
                retryCount,
                nextRetryAt != null ? Timestamp.from(nextRetryAt) : null,
                eventId.toString());
    }

    /**
     * Batch-updates the status of multiple outbox events in a single JDBC batch call.
     * More efficient than individual updates when finalizing a batch of events.
     */
    public void batchUpdateStatuses(String tableName, List<StatusUpdate> updates) {
        validateTableName(tableName);
        if (updates.isEmpty()) {
            return;
        }

        String sql = "UPDATE " + tableName +
                " SET status = ?, processed_at = ?, retry_count = ?, next_retry_at = ? WHERE id = ?";

        jdbcTemplate.batchUpdate(sql, new org.springframework.jdbc.core.BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                StatusUpdate u = updates.get(i);
                ps.setString(1, u.status().name());
                ps.setTimestamp(2, u.processedAt() != null ? Timestamp.from(u.processedAt()) : null);
                ps.setInt(3, u.retryCount());
                ps.setTimestamp(4, u.nextRetryAt() != null ? Timestamp.from(u.nextRetryAt()) : null);
                ps.setString(5, u.eventId().toString());
            }

            @Override
            public int getBatchSize() {
                return updates.size();
            }
        });
    }

    /**
     * Deletes published events older than the specified cutoff.
     *
     * @return the number of deleted rows
     */
    public int deletePublishedEventsBefore(String tableName, Instant cutoff) {
        validateTableName(tableName);

        String sql = "DELETE FROM " + tableName +
                " WHERE status = 'PUBLISHED' AND processed_at < ?";

        return jdbcTemplate.update(sql, Timestamp.from(cutoff));
    }

    /**
     * Counts events by status in the given table.
     */
    public int countByStatus(String tableName, OutboxEventStatus status) {
        validateTableName(tableName);
        String sql = "SELECT COUNT(*) FROM " + tableName + " WHERE status = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, status.name());
        return count != null ? count : 0;
    }

    /**
     * Returns the age in seconds of the oldest PENDING event, or 0 if none exist.
     */
    public long getOldestPendingAgeSeconds(String tableName) {
        validateTableName(tableName);
        String sql = "SELECT MIN(created_at) FROM " + tableName + " WHERE status = 'PENDING'";
        Timestamp oldest = jdbcTemplate.queryForObject(sql, Timestamp.class);
        if (oldest == null) {
            return 0;
        }
        return java.time.Duration.between(oldest.toInstant(), Instant.now()).getSeconds();
    }

    /**
     * Returns health statistics for the given table in a single query.
     * Returns a map with keys: pendingCount, failedCount, oldestPendingAgeSeconds.
     */
    public Map<String, Object> getHealthStats(String tableName) {
        validateTableName(tableName);

        String sql = "SELECT " +
                "COUNT(CASE WHEN status = 'PENDING' THEN 1 END) AS pending_count, " +
                "COUNT(CASE WHEN status = 'RETRY' THEN 1 END) AS retry_count, " +
                "COUNT(CASE WHEN status = 'FAILED' THEN 1 END) AS failed_count, " +
                "MIN(CASE WHEN status IN ('PENDING', 'RETRY') THEN created_at END) AS oldest_pending " +
                "FROM " + tableName +
                " WHERE status IN ('PENDING', 'RETRY', 'FAILED')";

        return jdbcTemplate.queryForObject(sql, (rs, rowNum) -> {
            int pendingCount = rs.getInt("pending_count");
            int retryCount = rs.getInt("retry_count");
            int failedCount = rs.getInt("failed_count");
            Timestamp oldestPending = rs.getTimestamp("oldest_pending");
            long oldestPendingAgeSec = 0;
            if (oldestPending != null) {
                oldestPendingAgeSec = java.time.Duration.between(
                        oldestPending.toInstant(), Instant.now()).getSeconds();
            }

            Map<String, Object> stats = new java.util.LinkedHashMap<>();
            stats.put("pendingCount", pendingCount);
            stats.put("retryCount", retryCount);
            stats.put("failedCount", failedCount);
            stats.put("oldestPendingAgeSeconds", oldestPendingAgeSec);
            return stats;
        });
    }

    private void validateTableName(String tableName) {
        if (tableName == null || tableName.isBlank()) {
            throw new OutboxException("Table name must not be null or blank");
        }
        if (!TABLE_NAME_PATTERN.matcher(tableName).matches()) {
            throw new OutboxException(
                    "Invalid table name: '" + tableName + "'. " +
                    "Table name must match pattern: " + TABLE_NAME_PATTERN.pattern());
        }
    }

    private String serializeHeaders(OutboxEvent event) {
        if (event.getHeaders() == null || event.getHeaders().isEmpty()) {
            return null;
        }
        return payloadSerializer.serialize(event.getHeaders());
    }

    private static class OutboxEventRowMapper implements RowMapper<OutboxEvent> {

        private static final ObjectMapper HEADER_MAPPER = new ObjectMapper();

        @Override
        public OutboxEvent mapRow(ResultSet rs, int rowNum) throws SQLException {
            String headersStr = rs.getString("headers");
            Map<String, String> headers = Collections.emptyMap();
            if (headersStr != null && !headersStr.isBlank()) {
                headers = parseHeaders(headersStr);
            }

            Timestamp processedAtTs = rs.getTimestamp("processed_at");
            Timestamp nextRetryAtTs = rs.getTimestamp("next_retry_at");

            return OutboxEvent.builder()
                    .id(UUID.fromString(rs.getString("id")))
                    .aggregateType(rs.getString("aggregate_type"))
                    .aggregateId(rs.getString("aggregate_id"))
                    .eventType(rs.getString("event_type"))
                    .payload(rs.getString("payload"))
                    .headers(headers)
                    .createdAt(rs.getTimestamp("created_at").toInstant())
                    .status(OutboxEventStatus.valueOf(rs.getString("status")))
                    .processedAt(processedAtTs != null ? processedAtTs.toInstant() : null)
                    .retryCount(rs.getInt("retry_count"))
                    .nextRetryAt(nextRetryAtTs != null ? nextRetryAtTs.toInstant() : null)
                    .schemaVersion(rs.getInt("schema_version"))
                    .compressed(rs.getBoolean("compressed"))
                    .build();
        }

        @SuppressWarnings("unchecked")
        private static Map<String, String> parseHeaders(String json) {
            try {
                return HEADER_MAPPER.readValue(json, Map.class);
            } catch (Exception e) {
                return Collections.emptyMap();
            }
        }
    }
}
