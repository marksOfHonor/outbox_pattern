package com.company.outbox.hooks;

import com.company.outbox.domain.OutboxEvent;

/**
 * Extension hooks for outbox event lifecycle.
 * Microservices can implement this interface to add custom behavior
 * before/after persistence or on error.
 */
public interface OutboxHooks {

    /**
     * Called before the event is persisted to the outbox table.
     *
     * @param event the outbox event about to be persisted
     */
    void beforePersist(OutboxEvent event);

    /**
     * Called after the event has been successfully persisted to the outbox table.
     *
     * @param event the outbox event that was persisted
     */
    void afterPersist(OutboxEvent event);

    /**
     * Called when an error occurs during event persistence.
     *
     * @param event     the outbox event that failed to persist
     * @param exception the exception that occurred
     */
    void onError(OutboxEvent event, Exception exception);
}
