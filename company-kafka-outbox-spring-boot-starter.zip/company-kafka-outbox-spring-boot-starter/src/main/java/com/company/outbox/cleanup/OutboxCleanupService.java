package com.company.outbox.cleanup;

import com.company.outbox.config.OutboxProperties;
import com.company.outbox.config.TableResolver;
import com.company.outbox.lock.OutboxLockProvider;
import com.company.outbox.metrics.OutboxMetrics;
import com.company.outbox.repository.OutboxJdbcRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;

import java.time.Duration;
import java.time.Instant;

/**
 * Scheduled cleanup service that deletes published outbox events
 * older than the configured retention period.
 */
public class OutboxCleanupService {

    private static final Logger log = LoggerFactory.getLogger(OutboxCleanupService.class);

    private static final String CLEANUP_LOCK_NAME = "outbox-cleanup";

    private final OutboxJdbcRepository repository;
    private final OutboxProperties properties;
    private final TableResolver tableResolver;
    private final OutboxMetrics metrics;
    private final OutboxLockProvider lockProvider;
    private final Duration lockDuration;

    public OutboxCleanupService(OutboxJdbcRepository repository,
                                OutboxProperties properties,
                                TableResolver tableResolver,
                                OutboxMetrics metrics) {
        this(repository, properties, tableResolver, metrics, null);
    }

    public OutboxCleanupService(OutboxJdbcRepository repository,
                                OutboxProperties properties,
                                TableResolver tableResolver,
                                OutboxMetrics metrics,
                                OutboxLockProvider lockProvider) {
        this.repository = repository;
        this.properties = properties;
        this.tableResolver = tableResolver;
        this.metrics = metrics;
        this.lockProvider = lockProvider;
        this.lockDuration = Duration.ofMillis(properties.getDistributedLock().getLockAtMostMs());
    }

    /**
     * Runs on the configured cron schedule. Deletes PUBLISHED events
     * older than the retention period from all configured outbox tables.
     */
    @Scheduled(cron = "${outbox.cleanup.cron:0 0 2 * * *}")
    public void cleanup() {
        if (lockProvider != null) {
            if (!lockProvider.tryAcquire(CLEANUP_LOCK_NAME, lockDuration)) {
                log.debug("Could not acquire cleanup lock, skipping cleanup cycle");
                return;
            }
            try {
                doCleanup();
            } finally {
                lockProvider.release(CLEANUP_LOCK_NAME);
            }
        } else {
            doCleanup();
        }
    }

    private void doCleanup() {
        long retentionHours = properties.getCleanup().getRetentionHours();
        Instant cutoff = Instant.now().minus(Duration.ofHours(retentionHours));

        log.info("Starting outbox cleanup. Deleting PUBLISHED events older than {} ({} hours retention)",
                cutoff, retentionHours);

        for (String tableName : tableResolver.getAllTableNames()) {
            try {
                int deleted = repository.deletePublishedEventsBefore(tableName, cutoff);
                if (deleted > 0) {
                    metrics.recordCleanupDeleted(tableName, deleted);
                    log.info("Cleaned up {} published events from {}", deleted, tableName);
                }
            } catch (Exception e) {
                log.error("Error cleaning up table {}: {}", tableName, e.getMessage(), e);
            }
        }
    }
}
