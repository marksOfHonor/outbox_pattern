package com.company.outbox.compression;

/**
 * Contract for compressing and decompressing outbox event payloads.
 * Applied transparently by the repository when compression is enabled.
 */
public interface PayloadCompressor {

    /**
     * Compresses the given payload string.
     *
     * @param payload the raw payload
     * @return the compressed payload (Base64-encoded for safe CLOB storage)
     */
    String compress(String payload);

    /**
     * Decompresses a previously compressed payload.
     *
     * @param compressed the compressed payload (Base64-encoded)
     * @return the original payload string
     */
    String decompress(String compressed);
}
