package com.company.outbox.compression;

import com.company.outbox.exception.OutboxException;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * GZIP-based payload compressor.
 * Compresses the payload and encodes it as Base64 for safe storage in CLOB columns.
 */
public class GzipPayloadCompressor implements PayloadCompressor {

    @Override
    public String compress(String payload) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            try (GZIPOutputStream gzos = new GZIPOutputStream(baos)) {
                gzos.write(payload.getBytes(StandardCharsets.UTF_8));
            }
            return Base64.getEncoder().encodeToString(baos.toByteArray());
        } catch (Exception e) {
            throw new OutboxException("Failed to compress payload", e);
        }
    }

    @Override
    public String decompress(String compressed) {
        try {
            byte[] bytes = Base64.getDecoder().decode(compressed);
            ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
            try (GZIPInputStream gzis = new GZIPInputStream(bais)) {
                return new String(gzis.readAllBytes(), StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            throw new OutboxException("Failed to decompress payload", e);
        }
    }
}
