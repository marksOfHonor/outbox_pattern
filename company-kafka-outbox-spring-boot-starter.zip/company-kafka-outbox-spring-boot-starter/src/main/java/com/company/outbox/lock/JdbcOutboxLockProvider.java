package com.company.outbox.lock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import java.time.Duration;
import java.time.Instant;

/**
 * JDBC-based distributed lock provider using an {@code outbox_lock} table.
 * Uses optimistic UPDATE with timestamp comparison — no database-specific features required.
 *
 * <p>Expected table schema:
 * <pre>
 * CREATE TABLE outbox_lock (
 *     lock_name   VARCHAR(100) PRIMARY KEY,
 *     locked_by   VARCHAR(255) NOT NULL,
 *     lock_until  TIMESTAMP    NOT NULL
 * );
 * </pre>
 *
 * <p>Lock acquisition: {@code UPDATE outbox_lock SET locked_by=?, lock_until=? WHERE lock_name=? AND lock_until < NOW()}
 * <br>If no row is updated, the lock is held by another instance.
 */
public class JdbcOutboxLockProvider implements OutboxLockProvider {

    private static final Logger log = LoggerFactory.getLogger(JdbcOutboxLockProvider.class);

    private final JdbcTemplate jdbcTemplate;
    private final String instanceId;

    public JdbcOutboxLockProvider(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
        this.instanceId = generateInstanceId();
        log.info("JdbcOutboxLockProvider initialized with instanceId: {}", instanceId);
    }

    @Override
    public boolean tryAcquire(String lockName, Duration lockDuration) {
        Instant lockUntil = Instant.now().plus(lockDuration);

        try {
            ensureLockRowExists(lockName);

            int updated = jdbcTemplate.update(
                    "UPDATE outbox_lock SET locked_by = ?, lock_until = ? " +
                    "WHERE lock_name = ? AND lock_until < ?",
                    instanceId, java.sql.Timestamp.from(lockUntil),
                    lockName, java.sql.Timestamp.from(Instant.now()));

            if (updated > 0) {
                log.debug("Lock '{}' acquired by {} until {}", lockName, instanceId, lockUntil);
                return true;
            } else {
                log.debug("Lock '{}' is held by another instance", lockName);
                return false;
            }
        } catch (Exception e) {
            log.warn("Failed to acquire lock '{}': {}", lockName, e.getMessage());
            return false;
        }
    }

    @Override
    public void release(String lockName) {
        try {
            int updated = jdbcTemplate.update(
                    "UPDATE outbox_lock SET lock_until = ? WHERE lock_name = ? AND locked_by = ?",
                    java.sql.Timestamp.from(Instant.EPOCH), lockName, instanceId);

            if (updated > 0) {
                log.debug("Lock '{}' released by {}", lockName, instanceId);
            }
        } catch (Exception e) {
            log.warn("Failed to release lock '{}': {}", lockName, e.getMessage());
        }
    }

    private void ensureLockRowExists(String lockName) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM outbox_lock WHERE lock_name = ?",
                Integer.class, lockName);

        if (count == null || count == 0) {
            try {
                jdbcTemplate.update(
                        "INSERT INTO outbox_lock (lock_name, locked_by, lock_until) VALUES (?, ?, ?)",
                        lockName, "none", java.sql.Timestamp.from(Instant.EPOCH));
            } catch (Exception e) {
                // Race condition: another instance inserted first — this is fine
                log.debug("Lock row for '{}' already exists (concurrent insert)", lockName);
            }
        }
    }

    private String generateInstanceId() {
        String hostname;
        try {
            hostname = java.net.InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            hostname = "unknown";
        }
        return hostname + "-" + ProcessHandle.current().pid();
    }
}
