package com.company.outbox.config;

import com.company.outbox.exception.OutboxException;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Resolves aggregate types to outbox table names based on configuration.
 * Validates all mappings eagerly at construction time (fail-fast at startup).
 */
public class TableResolver {

    private static final Pattern TABLE_NAME_PATTERN = Pattern.compile("^[a-zA-Z_][a-zA-Z0-9_]*$");

    private final Map<String, String> aggregateTypeToTable;

    public TableResolver(OutboxProperties properties) {
        Map<String, OutboxTableProperties> tables = properties.getTables();

        if (tables == null || tables.isEmpty()) {
            throw new IllegalStateException(
                    "outbox.enabled is true but no tables are configured under outbox.tables. " +
                    "At least one table mapping is required.");
        }

        this.aggregateTypeToTable = new HashMap<>();

        for (Map.Entry<String, OutboxTableProperties> entry : tables.entrySet()) {
            String key = entry.getKey();
            OutboxTableProperties tableProps = entry.getValue();

            if (tableProps.getTableName() == null || tableProps.getTableName().isBlank()) {
                throw new IllegalStateException(
                        "outbox.tables." + key + ".table-name must not be blank");
            }

            if (tableProps.getAggregateType() == null || tableProps.getAggregateType().isBlank()) {
                throw new IllegalStateException(
                        "outbox.tables." + key + ".aggregate-type must not be blank");
            }

            if (!TABLE_NAME_PATTERN.matcher(tableProps.getTableName()).matches()) {
                throw new IllegalStateException(
                        "outbox.tables." + key + ".table-name '" + tableProps.getTableName() +
                        "' is invalid. Must match pattern: " + TABLE_NAME_PATTERN.pattern());
            }

            String previous = aggregateTypeToTable.put(
                    tableProps.getAggregateType(), tableProps.getTableName());

            if (previous != null) {
                throw new IllegalStateException(
                        "Duplicate aggregate-type '" + tableProps.getAggregateType() +
                        "' found in outbox.tables configuration. " +
                        "Each aggregate type must map to exactly one table.");
            }
        }
    }

    /**
     * Resolves the outbox table name for the given aggregate type.
     *
     * @param aggregateType the aggregate type (e.g., "Trade")
     * @return the configured table name (e.g., "trade_outbox")
     * @throws OutboxException if no mapping exists for the aggregate type
     */
    public String resolve(String aggregateType) {
        String table = aggregateTypeToTable.get(aggregateType);
        if (table == null) {
            throw new OutboxException(
                    "No outbox table configured for aggregate type '" + aggregateType + "'. " +
                    "Known aggregate types: " + aggregateTypeToTable.keySet());
        }
        return table;
    }

    /**
     * Returns all configured table names.
     */
    public Collection<String> getAllTableNames() {
        return aggregateTypeToTable.values();
    }

    /**
     * Returns all configured aggregate types.
     */
    public Set<String> getAllAggregateTypes() {
        return aggregateTypeToTable.keySet();
    }
}
