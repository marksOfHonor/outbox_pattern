package com.company.outbox.domain;

import java.time.Instant;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/**
 * Represents an event persisted in an outbox table.
 */
public class OutboxEvent {

    private final UUID id;
    private final String aggregateType;
    private final String aggregateId;
    private final String eventType;
    private final String payload;
    private final Map<String, String> headers;
    private final Instant createdAt;
    private final OutboxEventStatus status;
    private final Instant processedAt;
    private final int retryCount;
    private final Instant nextRetryAt;
    private final int schemaVersion;
    private final boolean compressed;

    private OutboxEvent(Builder builder) {
        this.id = builder.id;
        this.aggregateType = builder.aggregateType;
        this.aggregateId = builder.aggregateId;
        this.eventType = builder.eventType;
        this.payload = builder.payload;
        this.headers = builder.headers != null ? Map.copyOf(builder.headers) : Map.of();
        this.createdAt = builder.createdAt;
        this.status = builder.status;
        this.processedAt = builder.processedAt;
        this.retryCount = builder.retryCount;
        this.nextRetryAt = builder.nextRetryAt;
        this.schemaVersion = builder.schemaVersion;
        this.compressed = builder.compressed;
    }

    public UUID getId() {
        return id;
    }

    public String getAggregateType() {
        return aggregateType;
    }

    public String getAggregateId() {
        return aggregateId;
    }

    public String getEventType() {
        return eventType;
    }

    public String getPayload() {
        return payload;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public OutboxEventStatus getStatus() {
        return status;
    }

    public Instant getProcessedAt() {
        return processedAt;
    }

    public int getRetryCount() {
        return retryCount;
    }

    public Instant getNextRetryAt() {
        return nextRetryAt;
    }

    public int getSchemaVersion() {
        return schemaVersion;
    }

    public boolean isCompressed() {
        return compressed;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OutboxEvent that = (OutboxEvent) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "OutboxEvent{" +
                "id=" + id +
                ", aggregateType='" + aggregateType + '\'' +
                ", aggregateId='" + aggregateId + '\'' +
                ", eventType='" + eventType + '\'' +
                ", status=" + status +
                ", retryCount=" + retryCount +
                ", schemaVersion=" + schemaVersion +
                ", compressed=" + compressed +
                ", createdAt=" + createdAt +
                '}';
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private UUID id;
        private String aggregateType;
        private String aggregateId;
        private String eventType;
        private String payload;
        private Map<String, String> headers;
        private Instant createdAt;
        private OutboxEventStatus status = OutboxEventStatus.PENDING;
        private Instant processedAt;
        private int retryCount = 0;
        private Instant nextRetryAt;
        private int schemaVersion = 1;
        private boolean compressed = false;

        private Builder() {}

        public Builder id(UUID id) {
            this.id = id;
            return this;
        }

        public Builder aggregateType(String aggregateType) {
            this.aggregateType = aggregateType;
            return this;
        }

        public Builder aggregateId(String aggregateId) {
            this.aggregateId = aggregateId;
            return this;
        }

        public Builder eventType(String eventType) {
            this.eventType = eventType;
            return this;
        }

        public Builder payload(String payload) {
            this.payload = payload;
            return this;
        }

        public Builder headers(Map<String, String> headers) {
            this.headers = headers;
            return this;
        }

        public Builder createdAt(Instant createdAt) {
            this.createdAt = createdAt;
            return this;
        }

        public Builder status(OutboxEventStatus status) {
            this.status = status;
            return this;
        }

        public Builder processedAt(Instant processedAt) {
            this.processedAt = processedAt;
            return this;
        }

        public Builder retryCount(int retryCount) {
            this.retryCount = retryCount;
            return this;
        }

        public Builder nextRetryAt(Instant nextRetryAt) {
            this.nextRetryAt = nextRetryAt;
            return this;
        }

        public Builder schemaVersion(int schemaVersion) {
            this.schemaVersion = schemaVersion;
            return this;
        }

        public Builder compressed(boolean compressed) {
            this.compressed = compressed;
            return this;
        }

        public OutboxEvent build() {
            Objects.requireNonNull(id, "id must not be null");
            Objects.requireNonNull(aggregateType, "aggregateType must not be null");
            Objects.requireNonNull(aggregateId, "aggregateId must not be null");
            Objects.requireNonNull(eventType, "eventType must not be null");
            Objects.requireNonNull(payload, "payload must not be null");
            Objects.requireNonNull(createdAt, "createdAt must not be null");
            Objects.requireNonNull(status, "status must not be null");
            return new OutboxEvent(this);
        }
    }
}
