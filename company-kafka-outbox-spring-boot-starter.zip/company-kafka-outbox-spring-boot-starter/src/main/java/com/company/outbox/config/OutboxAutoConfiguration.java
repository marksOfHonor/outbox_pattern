package com.company.outbox.config;

import com.company.outbox.cleanup.OutboxCleanupService;
import com.company.outbox.compression.GzipPayloadCompressor;
import com.company.outbox.compression.PayloadCompressor;
import com.company.outbox.health.OutboxHealthIndicator;
import com.company.outbox.hooks.DefaultOutboxHooks;
import com.company.outbox.hooks.DefaultRelayHooks;
import com.company.outbox.hooks.OutboxHooks;
import com.company.outbox.hooks.RelayHooks;
import com.company.outbox.lock.JdbcOutboxLockProvider;
import com.company.outbox.lock.OutboxLockProvider;
import com.company.outbox.metrics.OutboxMetrics;
import com.company.outbox.publisher.OutboxBatchPublisher;
import com.company.outbox.publisher.OutboxEventPublisher;
import com.company.outbox.relay.OutboxEventFilter;
import com.company.outbox.relay.OutboxRelay;
import com.company.outbox.repository.OutboxJdbcRepository;
import com.company.outbox.serialization.JacksonPayloadSerializer;
import com.company.outbox.serialization.PayloadSerializer;
import com.company.outbox.service.OutboxService;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.jackson.JacksonAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

/**
 * Auto-configuration for the outbox starter.
 * Activated when {@code outbox.enabled=true} (default).
 */
@AutoConfiguration(after = JacksonAutoConfiguration.class)
@ConditionalOnProperty(name = "outbox.enabled", havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties(OutboxProperties.class)
public class OutboxAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean(ObjectMapper.class)
    public ObjectMapper outboxObjectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.findAndRegisterModules();
        return mapper;
    }

    @Bean
    @ConditionalOnMissingBean
    public PayloadSerializer payloadSerializer(ObjectMapper objectMapper) {
        return new JacksonPayloadSerializer(objectMapper);
    }

    @Bean
    @ConditionalOnMissingBean
    public OutboxHooks outboxHooks() {
        return new DefaultOutboxHooks();
    }

    @Bean
    @ConditionalOnMissingBean
    public RelayHooks relayHooks() {
        return new DefaultRelayHooks();
    }

    @Bean
    @ConditionalOnMissingBean
    public OutboxMetrics outboxMetrics(ObjectProvider<MeterRegistry> meterRegistryProvider) {
        return new OutboxMetrics(meterRegistryProvider.getIfAvailable());
    }

    @Bean
    @ConditionalOnMissingBean
    public TableResolver tableResolver(OutboxProperties outboxProperties) {
        return new TableResolver(outboxProperties);
    }

    @Bean
    @ConditionalOnMissingBean
    public OutboxJdbcRepository outboxJdbcRepository(JdbcTemplate jdbcTemplate,
                                                      PayloadSerializer payloadSerializer,
                                                      ObjectProvider<PayloadCompressor> compressorProvider) {
        return new OutboxJdbcRepository(jdbcTemplate, payloadSerializer, compressorProvider.getIfAvailable());
    }

    @Bean
    @ConditionalOnMissingBean
    public OutboxService outboxService(OutboxJdbcRepository outboxJdbcRepository,
                                       PayloadSerializer payloadSerializer,
                                       OutboxHooks outboxHooks,
                                       OutboxMetrics outboxMetrics,
                                       TableResolver tableResolver,
                                       ObjectProvider<PayloadCompressor> compressorProvider) {
        return new OutboxService(outboxJdbcRepository, payloadSerializer, outboxHooks, outboxMetrics,
                tableResolver, compressorProvider.getIfAvailable());
    }

    @Bean
    @ConditionalOnMissingBean
    public OutboxEventFilter outboxEventFilter() {
        return event -> true; // accept all by default
    }

    /**
     * Compression auto-configuration.
     * Activated when compression is enabled.
     */
    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(name = "outbox.compression.enabled", havingValue = "true")
    public PayloadCompressor payloadCompressor() {
        return new GzipPayloadCompressor();
    }

    /**
     * Distributed lock auto-configuration.
     * Activated when distributed-lock is enabled.
     */
    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(name = "outbox.distributed-lock.enabled", havingValue = "true")
    public OutboxLockProvider outboxLockProvider(JdbcTemplate jdbcTemplate) {
        return new JdbcOutboxLockProvider(jdbcTemplate);
    }

    /**
     * Health indicator auto-configuration.
     * Activated when Spring Boot Actuator is on the classpath.
     */
    @Configuration
    @ConditionalOnClass(HealthIndicator.class)
    static class HealthAutoConfiguration {

        @Bean
        @ConditionalOnMissingBean(name = "outboxHealthIndicator")
        public OutboxHealthIndicator outboxHealthIndicator(OutboxJdbcRepository repository,
                                                            TableResolver tableResolver,
                                                            OutboxProperties properties) {
            return new OutboxHealthIndicator(repository, tableResolver, properties);
        }
    }

    /**
     * Conditional relay auto-configuration.
     * Only activated when relay is enabled AND an {@link OutboxEventPublisher} bean is available.
     * If an {@link OutboxBatchPublisher} is available, the relay will prefer batch publishing.
     */
    @Configuration
    @ConditionalOnProperty(name = "outbox.relay.enabled", havingValue = "true")
    @ConditionalOnBean(OutboxEventPublisher.class)
    @EnableScheduling
    static class RelayAutoConfiguration {

        @Bean
        @ConditionalOnMissingBean
        public OutboxRelay outboxRelay(OutboxJdbcRepository repository,
                                       OutboxEventPublisher publisher,
                                       ObjectProvider<OutboxBatchPublisher> batchPublisherProvider,
                                       OutboxProperties properties,
                                       OutboxMetrics metrics,
                                       RelayHooks relayHooks,
                                       OutboxEventFilter eventFilter,
                                       ObjectProvider<OutboxLockProvider> lockProviderProvider,
                                       PlatformTransactionManager transactionManager,
                                       DataSource dataSource) {
            return new OutboxRelay(repository, publisher, batchPublisherProvider.getIfAvailable(),
                    properties, metrics, relayHooks, eventFilter, lockProviderProvider.getIfAvailable(),
                    transactionManager, dataSource);
        }
    }

    /**
     * Conditional cleanup auto-configuration.
     * Only activated when cleanup is enabled.
     */
    @Configuration
    @ConditionalOnProperty(name = "outbox.cleanup.enabled", havingValue = "true")
    @EnableScheduling
    static class CleanupAutoConfiguration {

        @Bean
        @ConditionalOnMissingBean
        public OutboxCleanupService outboxCleanupService(OutboxJdbcRepository repository,
                                                          OutboxProperties properties,
                                                          TableResolver tableResolver,
                                                          OutboxMetrics metrics,
                                                          ObjectProvider<OutboxLockProvider> lockProviderProvider) {
            return new OutboxCleanupService(repository, properties, tableResolver, metrics,
                    lockProviderProvider.getIfAvailable());
        }
    }
}
