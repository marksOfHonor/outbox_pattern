package com.company.outbox.integration;

import com.company.outbox.config.OutboxAutoConfiguration;
import com.company.outbox.domain.OutboxEvent;
import com.company.outbox.publisher.OutboxEventPublisher;
import com.company.outbox.relay.OutboxRelay;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.jackson.JacksonAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
import org.springframework.boot.autoconfigure.sql.init.SqlInitializationAutoConfiguration;
import org.springframework.boot.autoconfigure.transaction.TransactionAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@SpringBootTest(
        classes = OutboxRelayIntegrationTest.TestConfig.class,
        properties = {
                "outbox.relay.enabled=true",
                "outbox.relay.batch-size=10",
                "outbox.relay.max-retries=3",
                "outbox.relay.backoff-base-ms=500",
                "outbox.relay.backoff-max-ms=5000",
                "outbox.relay.poll-interval-ms=999999999",
                "outbox.tables.trade.topic=trade-events",
                "outbox.tables.payment.topic=payment-events",
                "outbox.tables.order.topic=order-events"
        }
)
@ActiveProfiles("test")
class OutboxRelayIntegrationTest {

    @Configuration
    @ImportAutoConfiguration({
            DataSourceAutoConfiguration.class,
            DataSourceTransactionManagerAutoConfiguration.class,
            JdbcTemplateAutoConfiguration.class,
            SqlInitializationAutoConfiguration.class,
            JacksonAutoConfiguration.class,
            TransactionAutoConfiguration.class,
            OutboxAutoConfiguration.class
    })
    static class TestConfig {

        @Bean
        MeterRegistry meterRegistry() {
            return new SimpleMeterRegistry();
        }

        @Bean
        OutboxEventPublisher outboxEventPublisher() {
            return mock(OutboxEventPublisher.class);
        }
    }

    @Autowired
    private OutboxRelay outboxRelay;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private OutboxEventPublisher publisher;

    @Autowired
    private MeterRegistry meterRegistry;

    @BeforeEach
    void setUp() {
        jdbcTemplate.update("DELETE FROM trade_outbox");
        jdbcTemplate.update("DELETE FROM payment_outbox");
        jdbcTemplate.update("DELETE FROM order_outbox");
        reset(publisher);
    }

    @Test
    void shouldRelayPendingEvent() throws Exception {
        insertPendingEvent("trade_outbox", "T-001", "Trade", "CREATED", "{\"amount\":100}");

        outboxRelay.pollAndPublish();

        verify(publisher).publish(any(OutboxEvent.class), eq("trade-events"));

        Map<String, Object> row = jdbcTemplate.queryForMap("SELECT status, retry_count FROM trade_outbox WHERE aggregate_id = 'T-001'");
        assertThat(row.get("STATUS")).isEqualTo("PUBLISHED");
        assertThat(row.get("RETRY_COUNT")).isEqualTo(0);
    }

    @Test
    void shouldPassCorrectEventAndDestination() throws Exception {
        insertPendingEvent("trade_outbox", "T-002", "Trade", "UPDATED", "{\"price\":50}");

        outboxRelay.pollAndPublish();

        ArgumentCaptor<OutboxEvent> eventCaptor = ArgumentCaptor.forClass(OutboxEvent.class);
        ArgumentCaptor<String> destCaptor = ArgumentCaptor.forClass(String.class);
        verify(publisher).publish(eventCaptor.capture(), destCaptor.capture());

        assertThat(destCaptor.getValue()).isEqualTo("trade-events");
        OutboxEvent event = eventCaptor.getValue();
        assertThat(event.getAggregateId()).isEqualTo("T-002");
        assertThat(event.getEventType()).isEqualTo("UPDATED");
        assertThat(event.getPayload()).isEqualTo("{\"price\":50}");
    }

    @Test
    void shouldIncrementRetryWithBackoff() throws Exception {
        insertPendingEvent("trade_outbox", "T-003", "Trade", "CREATED", "{}");

        doThrow(new RuntimeException("Transport unavailable")).when(publisher).publish(any(), anyString());

        outboxRelay.pollAndPublish();

        Map<String, Object> row = jdbcTemplate.queryForMap(
                "SELECT status, retry_count, processed_at, next_retry_at FROM trade_outbox WHERE aggregate_id = 'T-003'");
        assertThat(row.get("STATUS")).isEqualTo("RETRY");
        assertThat(row.get("RETRY_COUNT")).isEqualTo(1);
        assertThat(row.get("PROCESSED_AT")).isNotNull(); // last attempt time recorded
        assertThat(row.get("NEXT_RETRY_AT")).isNotNull();
    }

    @Test
    void shouldNotRetryEventBeforeBackoffExpires() throws Exception {
        // Insert event with RETRY status and next_retry_at far in the future
        UUID id = UUID.randomUUID();
        Instant futureRetry = Instant.now().plusSeconds(3600);
        jdbcTemplate.update(
                "INSERT INTO trade_outbox (id, aggregate_type, aggregate_id, event_type, payload, created_at, status, retry_count, next_retry_at) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                id.toString(), "Trade", "T-BACKOFF", "CREATED", "{}",
                java.sql.Timestamp.from(Instant.now()), "RETRY", 1,
                java.sql.Timestamp.from(futureRetry));

        outboxRelay.pollAndPublish();

        // Should not be picked up because next_retry_at is in the future
        verify(publisher, never()).publish(any(), anyString());
    }

    @Test
    void shouldMarkAsFailedAfterMaxRetries() throws Exception {
        doThrow(new RuntimeException("Transport unavailable")).when(publisher).publish(any(), anyString());

        UUID id = UUID.randomUUID();
        jdbcTemplate.update(
                "INSERT INTO trade_outbox (id, aggregate_type, aggregate_id, event_type, payload, created_at, status, retry_count) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                id.toString(), "Trade", "T-004", "CREATED", "{}", java.sql.Timestamp.from(Instant.now()), "PENDING", 2);

        outboxRelay.pollAndPublish();

        Map<String, Object> row = jdbcTemplate.queryForMap("SELECT status, retry_count FROM trade_outbox WHERE aggregate_id = 'T-004'");
        assertThat(row.get("STATUS")).isEqualTo("FAILED");
        assertThat(row.get("RETRY_COUNT")).isEqualTo(3);
    }

    @Test
    void shouldRelayEventsFromMultipleTables() throws Exception {
        insertPendingEvent("trade_outbox", "T-010", "Trade", "CREATED", "{}");
        insertPendingEvent("payment_outbox", "P-010", "Payment", "PROCESSED", "{}");

        outboxRelay.pollAndPublish();

        verify(publisher, times(2)).publish(any(OutboxEvent.class), anyString());

        ArgumentCaptor<String> destCaptor = ArgumentCaptor.forClass(String.class);
        verify(publisher, times(2)).publish(any(), destCaptor.capture());

        List<String> destinations = destCaptor.getAllValues();
        assertThat(destinations).containsExactlyInAnyOrder("trade-events", "payment-events");
    }

    @Test
    void shouldSkipAlreadyPublishedEvents() throws Exception {
        UUID id = UUID.randomUUID();
        jdbcTemplate.update(
                "INSERT INTO trade_outbox (id, aggregate_type, aggregate_id, event_type, payload, created_at, status, processed_at, retry_count) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                id.toString(), "Trade", "T-020", "CREATED", "{}", java.sql.Timestamp.from(Instant.now()),
                "PUBLISHED", java.sql.Timestamp.from(Instant.now()), 0);

        outboxRelay.pollAndPublish();

        verify(publisher, never()).publish(any(), anyString());
    }

    @Test
    void shouldRecordRelayMetrics() throws Exception {
        insertPendingEvent("trade_outbox", "T-030", "Trade", "CREATED", "{}");

        outboxRelay.pollAndPublish();

        assertThat(meterRegistry.find("outbox.relay.published")
                .tag("table", "trade_outbox")
                .tag("eventType", "CREATED")
                .counter().count()).isGreaterThanOrEqualTo(1.0);
    }

    private void insertPendingEvent(String tableName, String aggregateId, String aggregateType,
                                     String eventType, String payload) {
        UUID id = UUID.randomUUID();
        jdbcTemplate.update(
                "INSERT INTO " + tableName + " (id, aggregate_type, aggregate_id, event_type, payload, created_at, status, retry_count) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                id.toString(), aggregateType, aggregateId, eventType, payload,
                java.sql.Timestamp.from(Instant.now()), "PENDING", 0);
    }
}
