package com.company.outbox.integration;

import com.company.outbox.cleanup.OutboxCleanupService;
import com.company.outbox.config.OutboxAutoConfiguration;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.jackson.JacksonAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
import org.springframework.boot.autoconfigure.sql.init.SqlInitializationAutoConfiguration;
import org.springframework.boot.autoconfigure.transaction.TransactionAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(
        classes = OutboxCleanupIntegrationTest.TestConfig.class,
        properties = {
                "outbox.cleanup.enabled=true",
                "outbox.cleanup.retention-hours=24"
        }
)
@ActiveProfiles("test")
class OutboxCleanupIntegrationTest {

    @Configuration
    @ImportAutoConfiguration({
            DataSourceAutoConfiguration.class,
            DataSourceTransactionManagerAutoConfiguration.class,
            JdbcTemplateAutoConfiguration.class,
            SqlInitializationAutoConfiguration.class,
            JacksonAutoConfiguration.class,
            TransactionAutoConfiguration.class,
            OutboxAutoConfiguration.class
    })
    static class TestConfig {

        @Bean
        MeterRegistry meterRegistry() {
            return new SimpleMeterRegistry();
        }
    }

    @Autowired
    private OutboxCleanupService cleanupService;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private MeterRegistry meterRegistry;

    @BeforeEach
    void setUp() {
        jdbcTemplate.update("DELETE FROM trade_outbox");
        jdbcTemplate.update("DELETE FROM payment_outbox");
        jdbcTemplate.update("DELETE FROM order_outbox");
    }

    @Test
    void shouldDeleteOldPublishedEvents() {
        Instant oldTime = Instant.now().minus(48, ChronoUnit.HOURS);
        insertEvent("trade_outbox", "T-OLD", "PUBLISHED", oldTime);

        Instant recentTime = Instant.now().minus(1, ChronoUnit.HOURS);
        insertEvent("trade_outbox", "T-RECENT", "PUBLISHED", recentTime);

        cleanupService.cleanup();

        Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM trade_outbox", Integer.class);
        assertThat(count).isEqualTo(1);

        String remainingId = jdbcTemplate.queryForObject(
                "SELECT aggregate_id FROM trade_outbox", String.class);
        assertThat(remainingId).isEqualTo("T-RECENT");
    }

    @Test
    void shouldNotDeletePendingEvents() {
        Instant oldTime = Instant.now().minus(48, ChronoUnit.HOURS);
        insertEvent("trade_outbox", "T-PENDING", "PENDING", oldTime);

        cleanupService.cleanup();

        Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM trade_outbox", Integer.class);
        assertThat(count).isEqualTo(1);
    }

    @Test
    void shouldNotDeleteFailedEvents() {
        Instant oldTime = Instant.now().minus(48, ChronoUnit.HOURS);
        insertEvent("trade_outbox", "T-FAILED", "FAILED", oldTime);

        cleanupService.cleanup();

        Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM trade_outbox", Integer.class);
        assertThat(count).isEqualTo(1);
    }

    @Test
    void shouldCleanupAcrossMultipleTables() {
        Instant oldTime = Instant.now().minus(48, ChronoUnit.HOURS);
        insertEvent("trade_outbox", "T-OLD", "PUBLISHED", oldTime);
        insertEvent("payment_outbox", "P-OLD", "PUBLISHED", oldTime);

        cleanupService.cleanup();

        Integer tradeCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM trade_outbox", Integer.class);
        Integer paymentCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM payment_outbox", Integer.class);

        assertThat(tradeCount).isEqualTo(0);
        assertThat(paymentCount).isEqualTo(0);
    }

    @Test
    void shouldRecordCleanupMetrics() {
        Instant oldTime = Instant.now().minus(48, ChronoUnit.HOURS);
        insertEvent("trade_outbox", "T-OLD-1", "PUBLISHED", oldTime);
        insertEvent("trade_outbox", "T-OLD-2", "PUBLISHED", oldTime);

        cleanupService.cleanup();

        assertThat(meterRegistry.find("outbox.cleanup.deleted")
                .tag("table", "trade_outbox")
                .counter().count()).isGreaterThanOrEqualTo(2.0);
    }

    private void insertEvent(String tableName, String aggregateId, String status, Instant processedAt) {
        UUID id = UUID.randomUUID();
        Instant createdAt = processedAt.minus(1, ChronoUnit.HOURS);

        jdbcTemplate.update(
                "INSERT INTO " + tableName +
                        " (id, aggregate_type, aggregate_id, event_type, payload, created_at, status, processed_at, retry_count) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                id.toString(), "Trade", aggregateId, "CREATED", "{}",
                Timestamp.from(createdAt), status,
                "PENDING".equals(status) ? null : Timestamp.from(processedAt),
                0);
    }
}
