package com.company.outbox.lock;

import com.company.outbox.TestApplication;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;

import java.time.Duration;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(classes = TestApplication.class)
@ActiveProfiles("test")
class JdbcOutboxLockProviderTest {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private JdbcOutboxLockProvider lockProvider;

    @BeforeEach
    void setUp() {
        jdbcTemplate.update("DELETE FROM outbox_lock");
        lockProvider = new JdbcOutboxLockProvider(jdbcTemplate);
    }

    @Test
    void shouldAcquireLockWhenNotHeld() {
        boolean acquired = lockProvider.tryAcquire("test-lock", Duration.ofSeconds(30));
        assertThat(acquired).isTrue();
    }

    @Test
    void shouldNotAcquireLockWhenAlreadyHeld() {
        lockProvider.tryAcquire("test-lock", Duration.ofSeconds(30));

        // Second provider simulates another instance
        JdbcOutboxLockProvider otherProvider = new JdbcOutboxLockProvider(jdbcTemplate);
        boolean acquired = otherProvider.tryAcquire("test-lock", Duration.ofSeconds(30));
        assertThat(acquired).isFalse();
    }

    @Test
    void shouldAcquireLockAfterRelease() {
        lockProvider.tryAcquire("test-lock", Duration.ofSeconds(30));
        lockProvider.release("test-lock");

        JdbcOutboxLockProvider otherProvider = new JdbcOutboxLockProvider(jdbcTemplate);
        boolean acquired = otherProvider.tryAcquire("test-lock", Duration.ofSeconds(30));
        assertThat(acquired).isTrue();
    }

    @Test
    void shouldAllowDifferentLocksIndependently() {
        boolean lock1 = lockProvider.tryAcquire("lock-a", Duration.ofSeconds(30));
        boolean lock2 = lockProvider.tryAcquire("lock-b", Duration.ofSeconds(30));

        assertThat(lock1).isTrue();
        assertThat(lock2).isTrue();
    }

    @Test
    void shouldAcquireExpiredLock() {
        // Acquire with a very short duration
        lockProvider.tryAcquire("test-lock", Duration.ofMillis(1));

        // Wait briefly for lock to expire
        try { Thread.sleep(50); } catch (InterruptedException ignored) {}

        JdbcOutboxLockProvider otherProvider = new JdbcOutboxLockProvider(jdbcTemplate);
        boolean acquired = otherProvider.tryAcquire("test-lock", Duration.ofSeconds(30));
        assertThat(acquired).isTrue();
    }

    @Test
    void shouldCreateLockRowIfNotExists() {
        Integer countBefore = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM outbox_lock WHERE lock_name = ?",
                Integer.class, "new-lock");
        assertThat(countBefore).isZero();

        lockProvider.tryAcquire("new-lock", Duration.ofSeconds(30));

        Integer countAfter = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM outbox_lock WHERE lock_name = ?",
                Integer.class, "new-lock");
        assertThat(countAfter).isEqualTo(1);
    }

    @Test
    void shouldHandleReleaseOfUnheldLock() {
        // Should not throw
        lockProvider.release("non-existent-lock");
    }
}
