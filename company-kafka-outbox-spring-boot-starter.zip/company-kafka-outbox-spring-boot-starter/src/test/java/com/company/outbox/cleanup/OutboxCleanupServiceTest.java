package com.company.outbox.cleanup;

import com.company.outbox.config.OutboxProperties;
import com.company.outbox.config.OutboxTableProperties;
import com.company.outbox.config.TableResolver;
import com.company.outbox.metrics.OutboxMetrics;
import com.company.outbox.repository.OutboxJdbcRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OutboxCleanupServiceTest {

    @Mock private OutboxJdbcRepository repository;
    @Mock private OutboxMetrics metrics;

    private OutboxProperties properties;
    private TableResolver tableResolver;
    private OutboxCleanupService cleanupService;

    @BeforeEach
    void setUp() {
        properties = buildProperties();
        tableResolver = new TableResolver(properties);
        cleanupService = new OutboxCleanupService(repository, properties, tableResolver, metrics);
    }

    @Test
    void shouldDeletePublishedEventsFromAllTables() {
        when(repository.deletePublishedEventsBefore(eq("trade_outbox"), any(Instant.class))).thenReturn(5);
        when(repository.deletePublishedEventsBefore(eq("payment_outbox"), any(Instant.class))).thenReturn(3);

        cleanupService.cleanup();

        verify(repository).deletePublishedEventsBefore(eq("trade_outbox"), any(Instant.class));
        verify(repository).deletePublishedEventsBefore(eq("payment_outbox"), any(Instant.class));
    }

    @Test
    void shouldRecordMetricsForDeletedEvents() {
        when(repository.deletePublishedEventsBefore(eq("trade_outbox"), any(Instant.class))).thenReturn(5);
        when(repository.deletePublishedEventsBefore(eq("payment_outbox"), any(Instant.class))).thenReturn(3);

        cleanupService.cleanup();

        verify(metrics).recordCleanupDeleted("trade_outbox", 5);
        verify(metrics).recordCleanupDeleted("payment_outbox", 3);
    }

    @Test
    void shouldNotRecordMetricsWhenNothingDeleted() {
        when(repository.deletePublishedEventsBefore(eq("trade_outbox"), any(Instant.class))).thenReturn(0);
        when(repository.deletePublishedEventsBefore(eq("payment_outbox"), any(Instant.class))).thenReturn(0);

        cleanupService.cleanup();

        verify(metrics, never()).recordCleanupDeleted(anyString(), anyInt());
    }

    @Test
    void shouldContinueWhenOneTableFails() {
        when(repository.deletePublishedEventsBefore(eq("trade_outbox"), any(Instant.class)))
                .thenThrow(new RuntimeException("DB error"));
        when(repository.deletePublishedEventsBefore(eq("payment_outbox"), any(Instant.class)))
                .thenReturn(2);

        cleanupService.cleanup();

        verify(repository).deletePublishedEventsBefore(eq("trade_outbox"), any(Instant.class));
        verify(repository).deletePublishedEventsBefore(eq("payment_outbox"), any(Instant.class));
        verify(metrics).recordCleanupDeleted("payment_outbox", 2);
    }

    @Test
    void shouldUseConfiguredRetentionHours() {
        when(repository.deletePublishedEventsBefore(anyString(), any(Instant.class))).thenReturn(0);

        Instant before = Instant.now().minusSeconds(72 * 3600 + 1);

        cleanupService.cleanup();

        ArgumentCaptor<Instant> cutoffCaptor = ArgumentCaptor.forClass(Instant.class);
        verify(repository, atLeastOnce()).deletePublishedEventsBefore(anyString(), cutoffCaptor.capture());

        Instant cutoff = cutoffCaptor.getValue();
        assertThat(cutoff).isAfter(before);
        assertThat(cutoff).isBefore(Instant.now());
    }

    private OutboxProperties buildProperties() {
        OutboxProperties props = new OutboxProperties();

        OutboxTableProperties tradeTable = new OutboxTableProperties();
        tradeTable.setTableName("trade_outbox");
        tradeTable.setAggregateType("Trade");

        OutboxTableProperties paymentTable = new OutboxTableProperties();
        paymentTable.setTableName("payment_outbox");
        paymentTable.setAggregateType("Payment");

        props.setTables(new LinkedHashMap<>(Map.of("trade", tradeTable, "payment", paymentTable)));

        OutboxProperties.Cleanup cleanup = new OutboxProperties.Cleanup();
        cleanup.setEnabled(true);
        cleanup.setRetentionHours(72);
        props.setCleanup(cleanup);

        return props;
    }
}
