package com.company.outbox.config;

import com.company.outbox.exception.OutboxException;
import org.junit.jupiter.api.Test;

import java.util.LinkedHashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class TableResolverTest {

    @Test
    void shouldResolveSingleAggregateType() {
        OutboxProperties props = propertiesWithTables(Map.of(
                "trade", tableProps("trade_outbox", "Trade")));

        TableResolver resolver = new TableResolver(props);

        assertThat(resolver.resolve("Trade")).isEqualTo("trade_outbox");
    }

    @Test
    void shouldResolveMultipleAggregateTypes() {
        OutboxProperties props = propertiesWithTables(Map.of(
                "trade", tableProps("trade_outbox", "Trade"),
                "allocation", tableProps("allocation_outbox", "Allocation")));

        TableResolver resolver = new TableResolver(props);

        assertThat(resolver.resolve("Trade")).isEqualTo("trade_outbox");
        assertThat(resolver.resolve("Allocation")).isEqualTo("allocation_outbox");
    }

    @Test
    void shouldThrowForUnknownAggregateType() {
        OutboxProperties props = propertiesWithTables(Map.of(
                "trade", tableProps("trade_outbox", "Trade")));

        TableResolver resolver = new TableResolver(props);

        assertThatThrownBy(() -> resolver.resolve("Unknown"))
                .isInstanceOf(OutboxException.class)
                .hasMessageContaining("No outbox table configured for aggregate type 'Unknown'")
                .hasMessageContaining("Trade");
    }

    @Test
    void shouldBeCaseSensitive() {
        OutboxProperties props = propertiesWithTables(Map.of(
                "trade", tableProps("trade_outbox", "Trade")));

        TableResolver resolver = new TableResolver(props);

        assertThatThrownBy(() -> resolver.resolve("trade"))
                .isInstanceOf(OutboxException.class);
    }

    @Test
    void shouldFailOnEmptyTablesMap() {
        OutboxProperties props = new OutboxProperties();

        assertThatThrownBy(() -> new TableResolver(props))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("no tables are configured");
    }

    @Test
    void shouldFailOnNullTablesMap() {
        OutboxProperties props = new OutboxProperties();
        props.setTables(null);

        assertThatThrownBy(() -> new TableResolver(props))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("no tables are configured");
    }

    @Test
    void shouldFailOnBlankTableName() {
        OutboxProperties props = propertiesWithTables(Map.of(
                "trade", tableProps("  ", "Trade")));

        assertThatThrownBy(() -> new TableResolver(props))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("table-name must not be blank");
    }

    @Test
    void shouldFailOnNullTableName() {
        OutboxProperties props = propertiesWithTables(Map.of(
                "trade", tableProps(null, "Trade")));

        assertThatThrownBy(() -> new TableResolver(props))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("table-name must not be blank");
    }

    @Test
    void shouldFailOnBlankAggregateType() {
        OutboxProperties props = propertiesWithTables(Map.of(
                "trade", tableProps("trade_outbox", " ")));

        assertThatThrownBy(() -> new TableResolver(props))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("aggregate-type must not be blank");
    }

    @Test
    void shouldFailOnNullAggregateType() {
        OutboxProperties props = propertiesWithTables(Map.of(
                "trade", tableProps("trade_outbox", null)));

        assertThatThrownBy(() -> new TableResolver(props))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("aggregate-type must not be blank");
    }

    @Test
    void shouldFailOnDuplicateAggregateType() {
        Map<String, OutboxTableProperties> tables = new LinkedHashMap<>();
        tables.put("trade1", tableProps("trade_outbox_1", "Trade"));
        tables.put("trade2", tableProps("trade_outbox_2", "Trade"));

        OutboxProperties props = propertiesWithTables(tables);

        assertThatThrownBy(() -> new TableResolver(props))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("Duplicate aggregate-type 'Trade'");
    }

    @Test
    void shouldFailOnInvalidTableNameFormat() {
        OutboxProperties props = propertiesWithTables(Map.of(
                "trade", tableProps("trade-outbox", "Trade")));

        assertThatThrownBy(() -> new TableResolver(props))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("is invalid");
    }

    @Test
    void shouldFailOnTableNameStartingWithNumber() {
        OutboxProperties props = propertiesWithTables(Map.of(
                "trade", tableProps("123trade", "Trade")));

        assertThatThrownBy(() -> new TableResolver(props))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("is invalid");
    }

    @Test
    void shouldReturnAllTableNames() {
        OutboxProperties props = propertiesWithTables(Map.of(
                "trade", tableProps("trade_outbox", "Trade"),
                "payment", tableProps("payment_outbox", "Payment")));

        TableResolver resolver = new TableResolver(props);

        assertThat(resolver.getAllTableNames())
                .containsExactlyInAnyOrder("trade_outbox", "payment_outbox");
    }

    @Test
    void shouldReturnAllAggregateTypes() {
        OutboxProperties props = propertiesWithTables(Map.of(
                "trade", tableProps("trade_outbox", "Trade"),
                "payment", tableProps("payment_outbox", "Payment")));

        TableResolver resolver = new TableResolver(props);

        assertThat(resolver.getAllAggregateTypes())
                .containsExactlyInAnyOrder("Trade", "Payment");
    }

    private OutboxProperties propertiesWithTables(Map<String, OutboxTableProperties> tables) {
        OutboxProperties props = new OutboxProperties();
        props.setTables(new LinkedHashMap<>(tables));
        return props;
    }

    private OutboxTableProperties tableProps(String tableName, String aggregateType) {
        OutboxTableProperties tp = new OutboxTableProperties();
        tp.setTableName(tableName);
        tp.setAggregateType(aggregateType);
        return tp;
    }
}
