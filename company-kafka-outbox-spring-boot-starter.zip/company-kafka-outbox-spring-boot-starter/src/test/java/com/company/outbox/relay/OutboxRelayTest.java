package com.company.outbox.relay;

import com.company.outbox.config.OutboxProperties;
import com.company.outbox.config.OutboxTableProperties;
import com.company.outbox.domain.OutboxEvent;
import com.company.outbox.domain.OutboxEventStatus;
import com.company.outbox.hooks.RelayHooks;
import com.company.outbox.lock.OutboxLockProvider;
import com.company.outbox.metrics.OutboxMetrics;
import com.company.outbox.publisher.OutboxBatchPublisher;
import com.company.outbox.publisher.OutboxEventPublisher;
import com.company.outbox.repository.OutboxJdbcRepository;
import com.company.outbox.repository.StatusUpdate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.time.Duration;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OutboxRelayTest {

    @Mock private OutboxJdbcRepository repository;
    @Mock private OutboxEventPublisher publisher;
    @Mock private OutboxMetrics metrics;
    @Mock private RelayHooks relayHooks;
    @Mock private PlatformTransactionManager transactionManager;
    @Mock private DataSource dataSource;
    @Mock private Connection connection;
    @Mock private DatabaseMetaData databaseMetaData;

    private OutboxProperties properties;
    private OutboxRelay relay;
    private final OutboxEventFilter acceptAll = event -> true;

    @BeforeEach
    void setUp() throws Exception {
        when(dataSource.getConnection()).thenReturn(connection);
        when(connection.getMetaData()).thenReturn(databaseMetaData);
        when(databaseMetaData.getDatabaseProductName()).thenReturn("H2");

        properties = buildProperties();
        relay = new OutboxRelay(repository, publisher, null, properties, metrics, relayHooks,
                acceptAll, transactionManager, dataSource);
    }

    // ---- Immediate mode (default) ----

    @Test
    void shouldPublishPendingEvents() throws Exception {
        OutboxEvent event = buildEvent("T-001", "CREATED");
        when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of(event));

        executeRelayInMockedTransaction();

        verify(publisher).publish(eq(event), eq("trade-events"));
        verify(repository).updateStatus(eq("trade_outbox"), eq(event.getId()),
                eq(OutboxEventStatus.PUBLISHED), any(Instant.class), eq(0), isNull());
        verify(metrics).recordRelayPublished("trade_outbox", "CREATED");
    }

    @Test
    void shouldPassCorrectEventAndDestination() throws Exception {
        OutboxEvent event = buildEvent("T-001", "CREATED");
        when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of(event));

        executeRelayInMockedTransaction();

        ArgumentCaptor<OutboxEvent> eventCaptor = ArgumentCaptor.forClass(OutboxEvent.class);
        ArgumentCaptor<String> destinationCaptor = ArgumentCaptor.forClass(String.class);
        verify(publisher).publish(eventCaptor.capture(), destinationCaptor.capture());

        assertThat(destinationCaptor.getValue()).isEqualTo("trade-events");
        assertThat(eventCaptor.getValue().getAggregateId()).isEqualTo("T-001");
    }

    @Test
    void shouldSetRetryStatusOnPublishFailure() throws Exception {
        OutboxEvent event = buildEvent("T-001", "CREATED");
        when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of(event));

        doThrow(new RuntimeException("Transport down")).when(publisher).publish(any(), anyString());

        executeRelayInMockedTransaction();

        verify(repository).updateStatus(eq("trade_outbox"), eq(event.getId()),
                eq(OutboxEventStatus.RETRY), any(Instant.class), eq(1), any(Instant.class));
        verify(metrics).recordRelayRetried("trade_outbox", "CREATED");
    }

    @Test
    void shouldMarkAsFailedAfterMaxRetries() throws Exception {
        OutboxEvent event = buildEventWithRetry("T-001", "CREATED", 2);
        when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of(event));

        doThrow(new RuntimeException("Transport down")).when(publisher).publish(any(), anyString());

        executeRelayInMockedTransaction();

        verify(repository).updateStatus(eq("trade_outbox"), eq(event.getId()),
                eq(OutboxEventStatus.FAILED), any(Instant.class), eq(3), isNull());
        verify(metrics).recordRelayFailed("trade_outbox", "CREATED");
    }

    @Test
    void shouldSkipWhenNoPendingEvents() throws Exception {
        when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of());

        executeRelayInMockedTransaction();

        verify(publisher, never()).publish(any(), anyString());
    }

    @Test
    void shouldProcessMultipleEventsInBatch() throws Exception {
        OutboxEvent event1 = buildEvent("T-001", "CREATED");
        OutboxEvent event2 = buildEvent("T-002", "UPDATED");
        when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of(event1, event2));

        executeRelayInMockedTransaction();

        verify(publisher, times(2)).publish(any(), eq("trade-events"));
    }

    @Test
    void shouldContinueProcessingWhenOneEventFails() throws Exception {
        OutboxEvent event1 = buildEvent("T-001", "CREATED");
        OutboxEvent event2 = buildEvent("T-002", "UPDATED");
        when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of(event1, event2));

        doThrow(new RuntimeException("Transport down"))
                .doNothing()
                .when(publisher).publish(any(), anyString());

        executeRelayInMockedTransaction();

        // event1 failed -> RETRY with processedAt set
        verify(repository).updateStatus(eq("trade_outbox"), eq(event1.getId()),
                eq(OutboxEventStatus.RETRY), any(Instant.class), eq(1), any(Instant.class));
        // event2 succeeded -> PUBLISHED
        verify(repository).updateStatus(eq("trade_outbox"), eq(event2.getId()),
                eq(OutboxEventStatus.PUBLISHED), any(Instant.class), eq(0), isNull());
    }

    @Test
    void shouldDetectH2AndDisableSkipLocked() throws Exception {
        when(databaseMetaData.getDatabaseProductName()).thenReturn("H2");

        OutboxRelay h2Relay = new OutboxRelay(repository, publisher, null, properties, metrics,
                relayHooks, acceptAll, transactionManager, dataSource);

        when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of());

        executeRelayInMockedTransaction(h2Relay);

        verify(repository).findPendingEvents("trade_outbox", 50, false);
    }

    @Test
    void shouldCallRelayHooksOnSuccess() throws Exception {
        OutboxEvent event = buildEvent("T-001", "CREATED");
        when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of(event));

        executeRelayInMockedTransaction();

        verify(relayHooks).beforePublish(eq(event), eq("trade-events"));
        verify(relayHooks).afterPublish(eq(event), eq("trade-events"));
        verify(relayHooks, never()).onPublishFailure(any(), anyString(), any());
    }

    @Test
    void shouldCallRelayHooksOnFailure() throws Exception {
        OutboxEvent event = buildEvent("T-001", "CREATED");
        when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of(event));

        RuntimeException ex = new RuntimeException("Transport down");
        doThrow(ex).when(publisher).publish(any(), anyString());

        executeRelayInMockedTransaction();

        verify(relayHooks).beforePublish(eq(event), eq("trade-events"));
        verify(relayHooks, never()).afterPublish(any(), anyString());
        verify(relayHooks).onPublishFailure(eq(event), eq("trade-events"), eq(ex));
    }

    @Test
    void shouldComputeExponentialBackoff() {
        Instant before = Instant.now();

        Instant retry1 = relay.computeNextRetryAt(1); // 1000ms * 2^0 = 1s
        Instant retry2 = relay.computeNextRetryAt(2); // 1000ms * 2^1 = 2s
        Instant retry3 = relay.computeNextRetryAt(3); // 1000ms * 2^2 = 4s

        assertThat(retry1).isAfter(before);
        assertThat(retry2).isAfter(retry1);
        assertThat(retry3).isAfter(retry2);
    }

    @Test
    void shouldCapBackoffAtMaxMs() {
        Instant before = Instant.now();
        Instant result = relay.computeNextRetryAt(20);

        long delayMs = result.toEpochMilli() - before.toEpochMilli();
        assertThat(delayMs).isLessThanOrEqualTo(61000);
    }

    @Test
    void shouldFilterOutEvents() throws Exception {
        OutboxEvent event1 = buildEvent("T-001", "CREATED");
        OutboxEvent event2 = buildEvent("T-002", "INTERNAL");
        when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of(event1, event2));

        // Filter that rejects INTERNAL events
        OutboxEventFilter filter = event -> !"INTERNAL".equals(event.getEventType());
        OutboxRelay filterRelay = new OutboxRelay(repository, publisher, null, properties, metrics,
                relayHooks, filter, transactionManager, dataSource);

        executeRelayInMockedTransaction(filterRelay);

        // Only event1 should be published via publisher
        verify(publisher, times(1)).publish(eq(event1), eq("trade-events"));
        // event2 should be marked as PUBLISHED (skipped)
        verify(repository).updateStatus(eq("trade_outbox"), eq(event2.getId()),
                eq(OutboxEventStatus.PUBLISHED), any(Instant.class), eq(0), isNull());
    }

    @Test
    void shouldUseBatchPublisherWhenAvailable() throws Exception {
        OutboxBatchPublisher batchPublisher = mock(OutboxBatchPublisher.class);
        OutboxRelay batchRelay = new OutboxRelay(repository, publisher, batchPublisher, properties,
                metrics, relayHooks, acceptAll, transactionManager, dataSource);

        OutboxEvent event1 = buildEvent("T-001", "CREATED");
        OutboxEvent event2 = buildEvent("T-002", "UPDATED");
        when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of(event1, event2));

        executeRelayInMockedTransaction(batchRelay);

        verify(batchPublisher).publishBatch(eq(List.of(event1, event2)), eq("trade-events"));
        verify(publisher, never()).publish(any(), anyString());
        // Batch publisher always uses batchUpdateStatuses
        verify(repository).batchUpdateStatuses(eq("trade_outbox"), anyList());
    }

    @Test
    @SuppressWarnings("unchecked")
    void shouldMarkForRetryOnBatchFailureInsteadOfResending() throws Exception {
        OutboxBatchPublisher batchPublisher = mock(OutboxBatchPublisher.class);
        OutboxRelay batchRelay = new OutboxRelay(repository, publisher, batchPublisher, properties,
                metrics, relayHooks, acceptAll, transactionManager, dataSource);

        OutboxEvent event1 = buildEvent("T-001", "CREATED");
        when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of(event1));

        doThrow(new RuntimeException("Batch failed")).when(batchPublisher).publishBatch(any(), anyString());

        executeRelayInMockedTransaction(batchRelay);

        // Should NOT fall back to individual publisher — prevents double-delivery
        verify(publisher, never()).publish(any(), anyString());
        // Should mark event for retry via batch update
        ArgumentCaptor<List<StatusUpdate>> updatesCaptor = ArgumentCaptor.forClass(List.class);
        verify(repository).batchUpdateStatuses(eq("trade_outbox"), updatesCaptor.capture());
        List<StatusUpdate> updates = updatesCaptor.getValue();
        assertThat(updates).hasSize(1);
        assertThat(updates.get(0).status()).isEqualTo(OutboxEventStatus.RETRY);
        assertThat(updates.get(0).retryCount()).isEqualTo(1);
    }

    @Test
    void shouldSkipPollWhenLockNotAcquired() throws Exception {
        OutboxLockProvider lockProvider = mock(OutboxLockProvider.class);
        when(lockProvider.tryAcquire(anyString(), any(Duration.class))).thenReturn(false);

        OutboxRelay lockedRelay = new OutboxRelay(repository, publisher, null, properties, metrics,
                relayHooks, acceptAll, lockProvider, transactionManager, dataSource);

        // Call pollAndPublish directly — no transaction template mocking needed since lock prevents execution
        lockedRelay.pollAndPublish();

        verify(repository, never()).findPendingEvents(anyString(), anyInt(), anyBoolean());
        verify(lockProvider, never()).release(anyString());
    }

    @Test
    void shouldPollAndReleaseLockWhenAcquired() throws Exception {
        OutboxLockProvider lockProvider = mock(OutboxLockProvider.class);
        when(lockProvider.tryAcquire(anyString(), any(Duration.class))).thenReturn(true);

        OutboxRelay lockedRelay = new OutboxRelay(repository, publisher, null, properties, metrics,
                relayHooks, acceptAll, lockProvider, transactionManager, dataSource);

        when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of());

        executeRelayInMockedTransaction(lockedRelay);

        verify(repository).findPendingEvents("trade_outbox", 50, false);
        verify(lockProvider).release("outbox-relay");
    }

    @Test
    void shouldReleaseLockEvenOnException() throws Exception {
        OutboxLockProvider lockProvider = mock(OutboxLockProvider.class);
        when(lockProvider.tryAcquire(anyString(), any(Duration.class))).thenReturn(true);

        OutboxRelay lockedRelay = new OutboxRelay(repository, publisher, null, properties, metrics,
                relayHooks, acceptAll, lockProvider, transactionManager, dataSource);

        when(repository.findPendingEvents(anyString(), anyInt(), anyBoolean()))
                .thenThrow(new RuntimeException("DB error"));

        executeRelayInMockedTransaction(lockedRelay);

        verify(lockProvider).release("outbox-relay");
    }

    @Test
    void shouldMarkEventsAsProcessingDuringClaim() throws Exception {
        OutboxEvent event = buildEvent("T-001", "CREATED");
        when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of(event));

        executeRelayInMockedTransaction();

        verify(repository).markAsProcessing(eq("trade_outbox"), eq(List.of(event)), any(Instant.class));
    }

    @Test
    void shouldRecordProcessedAtOnRetry() throws Exception {
        OutboxEvent event = buildEvent("T-001", "CREATED");
        when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of(event));

        doThrow(new RuntimeException("fail")).when(publisher).publish(any(), anyString());

        executeRelayInMockedTransaction();

        // RETRY should include processedAt (last attempt time) — not null
        ArgumentCaptor<Instant> processedAtCaptor = ArgumentCaptor.forClass(Instant.class);
        verify(repository).updateStatus(eq("trade_outbox"), eq(event.getId()),
                eq(OutboxEventStatus.RETRY), processedAtCaptor.capture(), eq(1), any(Instant.class));
        assertThat(processedAtCaptor.getValue()).isNotNull();
    }

    // ---- Batched DB updates mode ----

    @Nested
    class BatchedDbUpdatesMode {

        private OutboxRelay batchedRelay;

        @BeforeEach
        void setUp() {
            properties.getRelay().setBatchDbUpdates(true);
            batchedRelay = new OutboxRelay(repository, publisher, null, properties, metrics,
                    relayHooks, acceptAll, transactionManager, dataSource);
        }

        @Test
        void shouldBatchFinalizeAllOutcomesAfterPublishing() throws Exception {
            OutboxEvent event1 = buildEvent("T-001", "CREATED");
            OutboxEvent event2 = buildEvent("T-002", "UPDATED");
            when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of(event1, event2));

            executeRelayInMockedTransaction(batchedRelay);

            // Should use batchUpdateStatuses instead of individual updateStatus
            ArgumentCaptor<List<StatusUpdate>> updatesCaptor = captureStatusUpdateList();
            verify(repository).batchUpdateStatuses(eq("trade_outbox"), updatesCaptor.capture());
            verify(repository, never()).updateStatus(anyString(), any(), any(), any(), anyInt(), any());

            List<StatusUpdate> updates = updatesCaptor.getValue();
            assertThat(updates).hasSize(2);
            assertThat(updates).allMatch(u -> u.status() == OutboxEventStatus.PUBLISHED);
        }

        @Test
        void shouldBatchMixedOutcomes() throws Exception {
            OutboxEvent event1 = buildEvent("T-001", "CREATED");
            OutboxEvent event2 = buildEvent("T-002", "UPDATED");
            when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of(event1, event2));

            doThrow(new RuntimeException("fail"))
                    .doNothing()
                    .when(publisher).publish(any(), anyString());

            executeRelayInMockedTransaction(batchedRelay);

            ArgumentCaptor<List<StatusUpdate>> updatesCaptor = captureStatusUpdateList();
            verify(repository).batchUpdateStatuses(eq("trade_outbox"), updatesCaptor.capture());

            List<StatusUpdate> updates = updatesCaptor.getValue();
            assertThat(updates).hasSize(2);
            // event1 failed -> RETRY, event2 succeeded -> PUBLISHED
            assertThat(updates.get(0).status()).isEqualTo(OutboxEventStatus.RETRY);
            assertThat(updates.get(0).retryCount()).isEqualTo(1);
            assertThat(updates.get(0).processedAt()).isNotNull();
            assertThat(updates.get(1).status()).isEqualTo(OutboxEventStatus.PUBLISHED);
        }

        @Test
        void shouldBatchFinalizeFilteredEvents() throws Exception {
            OutboxEvent event1 = buildEvent("T-001", "CREATED");
            OutboxEvent event2 = buildEvent("T-002", "INTERNAL");
            when(repository.findPendingEvents("trade_outbox", 50, false)).thenReturn(List.of(event1, event2));

            OutboxEventFilter filter = event -> !"INTERNAL".equals(event.getEventType());
            OutboxRelay batchFilterRelay = new OutboxRelay(repository, publisher, null, properties, metrics,
                    relayHooks, filter, transactionManager, dataSource);

            executeRelayInMockedTransaction(batchFilterRelay);

            ArgumentCaptor<List<StatusUpdate>> updatesCaptor = captureStatusUpdateList();
            verify(repository).batchUpdateStatuses(eq("trade_outbox"), updatesCaptor.capture());

            List<StatusUpdate> updates = updatesCaptor.getValue();
            assertThat(updates).hasSize(2);
            // Both should be PUBLISHED (one via publisher, one filtered-skip)
            assertThat(updates).allMatch(u -> u.status() == OutboxEventStatus.PUBLISHED);
        }

        @SuppressWarnings("unchecked")
        private ArgumentCaptor<List<StatusUpdate>> captureStatusUpdateList() {
            return ArgumentCaptor.forClass(List.class);
        }
    }

    // ---- AttemptPublish unit tests ----

    @Test
    void shouldReturnPublishedOutcomeOnSuccess() throws Exception {
        OutboxEvent event = buildEvent("T-001", "CREATED");

        StatusUpdate outcome = relay.attemptPublish("trade_outbox", "trade-events", event);

        assertThat(outcome.status()).isEqualTo(OutboxEventStatus.PUBLISHED);
        assertThat(outcome.processedAt()).isNotNull();
        assertThat(outcome.retryCount()).isEqualTo(0);
        assertThat(outcome.nextRetryAt()).isNull();
    }

    @Test
    void shouldReturnRetryOutcomeOnFailure() throws Exception {
        OutboxEvent event = buildEvent("T-001", "CREATED");
        doThrow(new RuntimeException("fail")).when(publisher).publish(any(), anyString());

        StatusUpdate outcome = relay.attemptPublish("trade_outbox", "trade-events", event);

        assertThat(outcome.status()).isEqualTo(OutboxEventStatus.RETRY);
        assertThat(outcome.processedAt()).isNotNull();
        assertThat(outcome.retryCount()).isEqualTo(1);
        assertThat(outcome.nextRetryAt()).isNotNull();
    }

    @Test
    void shouldReturnFailedOutcomeAfterMaxRetries() throws Exception {
        OutboxEvent event = buildEventWithRetry("T-001", "CREATED", 2);
        doThrow(new RuntimeException("fail")).when(publisher).publish(any(), anyString());

        StatusUpdate outcome = relay.attemptPublish("trade_outbox", "trade-events", event);

        assertThat(outcome.status()).isEqualTo(OutboxEventStatus.FAILED);
        assertThat(outcome.processedAt()).isNotNull();
        assertThat(outcome.retryCount()).isEqualTo(3);
        assertThat(outcome.nextRetryAt()).isNull();
    }

    // --- helpers ---

    private void executeRelayInMockedTransaction() {
        executeRelayInMockedTransaction(relay);
    }

    @SuppressWarnings("unchecked")
    private void executeRelayInMockedTransaction(OutboxRelay targetRelay) {
        try {
            var field = OutboxRelay.class.getDeclaredField("transactionTemplate");
            field.setAccessible(true);
            TransactionTemplate mockTxTemplate = mock(TransactionTemplate.class);

            // Mock execute(TransactionCallback) — used by phase 1 (claim)
            doAnswer(invocation -> {
                var callback = invocation.getArgument(0, TransactionCallback.class);
                return callback.doInTransaction(null);
            }).when(mockTxTemplate).execute(any());

            // Mock executeWithoutResult(Consumer) — used by phase 3 (finalize)
            // Lenient because not all tests reach phase 3 (e.g., empty event list, lock not acquired)
            lenient().doAnswer(invocation -> {
                var callback = invocation.getArgument(0, java.util.function.Consumer.class);
                callback.accept(null);
                return null;
            }).when(mockTxTemplate).executeWithoutResult(any());

            field.set(targetRelay, mockTxTemplate);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        targetRelay.pollAndPublish();
    }

    private OutboxEvent buildEvent(String aggregateId, String eventType) {
        return buildEventWithRetry(aggregateId, eventType, 0);
    }

    private OutboxEvent buildEventWithRetry(String aggregateId, String eventType, int retryCount) {
        return OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Trade")
                .aggregateId(aggregateId)
                .eventType(eventType)
                .payload("{}")
                .createdAt(Instant.now())
                .status(OutboxEventStatus.PENDING)
                .retryCount(retryCount)
                .build();
    }

    private OutboxProperties buildProperties() {
        OutboxProperties props = new OutboxProperties();
        OutboxTableProperties tradeTable = new OutboxTableProperties();
        tradeTable.setTableName("trade_outbox");
        tradeTable.setAggregateType("Trade");
        tradeTable.setTopic("trade-events");
        props.setTables(new LinkedHashMap<>(Map.of("trade", tradeTable)));

        OutboxProperties.Relay relay = new OutboxProperties.Relay();
        relay.setEnabled(true);
        relay.setBatchSize(50);
        relay.setMaxRetries(3);
        relay.setBackoffBaseMs(1000);
        relay.setBackoffMaxMs(60000);
        props.setRelay(relay);

        return props;
    }
}
