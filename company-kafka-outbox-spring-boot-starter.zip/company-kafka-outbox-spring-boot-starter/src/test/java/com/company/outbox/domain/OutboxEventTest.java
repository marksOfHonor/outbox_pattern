package com.company.outbox.domain;

import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class OutboxEventTest {

    @Test
    void shouldBuildEventWithAllFields() {
        UUID id = UUID.randomUUID();
        Instant now = Instant.now();
        Map<String, String> headers = Map.of("correlationId", "abc-123");

        OutboxEvent event = OutboxEvent.builder()
                .id(id)
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{\"amount\":100}")
                .headers(headers)
                .createdAt(now)
                .build();

        assertThat(event.getId()).isEqualTo(id);
        assertThat(event.getAggregateType()).isEqualTo("Trade");
        assertThat(event.getAggregateId()).isEqualTo("T-001");
        assertThat(event.getEventType()).isEqualTo("CREATED");
        assertThat(event.getPayload()).isEqualTo("{\"amount\":100}");
        assertThat(event.getHeaders()).containsEntry("correlationId", "abc-123");
        assertThat(event.getCreatedAt()).isEqualTo(now);
    }

    @Test
    void shouldBuildEventWithEmptyHeaders() {
        OutboxEvent event = OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{}")
                .createdAt(Instant.now())
                .build();

        assertThat(event.getHeaders()).isEmpty();
    }

    @Test
    void shouldHaveImmutableHeaders() {
        Map<String, String> headers = Map.of("key", "value");
        OutboxEvent event = OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{}")
                .headers(headers)
                .createdAt(Instant.now())
                .build();

        assertThatThrownBy(() -> event.getHeaders().put("new", "entry"))
                .isInstanceOf(UnsupportedOperationException.class);
    }

    @Test
    void shouldFailWhenIdIsNull() {
        assertThatThrownBy(() -> OutboxEvent.builder()
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{}")
                .createdAt(Instant.now())
                .build())
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("id");
    }

    @Test
    void shouldFailWhenAggregateTypeIsNull() {
        assertThatThrownBy(() -> OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{}")
                .createdAt(Instant.now())
                .build())
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("aggregateType");
    }

    @Test
    void shouldFailWhenPayloadIsNull() {
        assertThatThrownBy(() -> OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .createdAt(Instant.now())
                .build())
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("payload");
    }

    @Test
    void shouldBeEqualByIdOnly() {
        UUID id = UUID.randomUUID();
        Instant now = Instant.now();

        OutboxEvent event1 = OutboxEvent.builder()
                .id(id)
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{}")
                .createdAt(now)
                .build();

        OutboxEvent event2 = OutboxEvent.builder()
                .id(id)
                .aggregateType("Payment")
                .aggregateId("P-999")
                .eventType("UPDATED")
                .payload("{\"different\":true}")
                .createdAt(now.plusSeconds(10))
                .build();

        assertThat(event1).isEqualTo(event2);
        assertThat(event1.hashCode()).isEqualTo(event2.hashCode());
    }

    @Test
    void shouldNotBeEqualWithDifferentIds() {
        Instant now = Instant.now();

        OutboxEvent event1 = OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{}")
                .createdAt(now)
                .build();

        OutboxEvent event2 = OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{}")
                .createdAt(now)
                .build();

        assertThat(event1).isNotEqualTo(event2);
    }

    @Test
    void toStringShouldContainKeyFields() {
        UUID id = UUID.randomUUID();
        OutboxEvent event = OutboxEvent.builder()
                .id(id)
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{}")
                .createdAt(Instant.now())
                .build();

        String str = event.toString();
        assertThat(str).contains(id.toString());
        assertThat(str).contains("Trade");
        assertThat(str).contains("T-001");
        assertThat(str).contains("CREATED");
    }

    @Test
    void shouldDefaultStatusToPending() {
        OutboxEvent event = OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{}")
                .createdAt(Instant.now())
                .build();

        assertThat(event.getStatus()).isEqualTo(OutboxEventStatus.PENDING);
    }

    @Test
    void shouldDefaultRetryCountToZero() {
        OutboxEvent event = OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{}")
                .createdAt(Instant.now())
                .build();

        assertThat(event.getRetryCount()).isEqualTo(0);
    }

    @Test
    void shouldDefaultProcessedAtToNull() {
        OutboxEvent event = OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{}")
                .createdAt(Instant.now())
                .build();

        assertThat(event.getProcessedAt()).isNull();
    }

    @Test
    void shouldBuildWithExplicitStatusAndRetryCount() {
        Instant now = Instant.now();
        OutboxEvent event = OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{}")
                .createdAt(now)
                .status(OutboxEventStatus.PUBLISHED)
                .processedAt(now)
                .retryCount(2)
                .build();

        assertThat(event.getStatus()).isEqualTo(OutboxEventStatus.PUBLISHED);
        assertThat(event.getProcessedAt()).isEqualTo(now);
        assertThat(event.getRetryCount()).isEqualTo(2);
    }

    @Test
    void shouldFailWhenStatusIsNull() {
        assertThatThrownBy(() -> OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{}")
                .createdAt(Instant.now())
                .status(null)
                .build())
                .isInstanceOf(NullPointerException.class)
                .hasMessageContaining("status");
    }

    @Test
    void toStringShouldContainStatusAndRetryCount() {
        OutboxEvent event = OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{}")
                .createdAt(Instant.now())
                .status(OutboxEventStatus.FAILED)
                .retryCount(3)
                .build();

        String str = event.toString();
        assertThat(str).contains("FAILED");
        assertThat(str).contains("retryCount=3");
    }
}
