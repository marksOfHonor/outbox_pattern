package com.company.outbox.hooks;

import com.company.outbox.domain.OutboxEvent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThatCode;

class DefaultOutboxHooksTest {

    private DefaultOutboxHooks hooks;
    private OutboxEvent event;

    @BeforeEach
    void setUp() {
        hooks = new DefaultOutboxHooks();
        event = OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{}")
                .createdAt(Instant.now())
                .build();
    }

    @Test
    void beforePersistShouldNotThrow() {
        assertThatCode(() -> hooks.beforePersist(event))
                .doesNotThrowAnyException();
    }

    @Test
    void afterPersistShouldNotThrow() {
        assertThatCode(() -> hooks.afterPersist(event))
                .doesNotThrowAnyException();
    }

    @Test
    void onErrorShouldNotThrow() {
        assertThatCode(() -> hooks.onError(event, new RuntimeException("test error")))
                .doesNotThrowAnyException();
    }
}
