package com.company.outbox.serialization;

import com.company.outbox.exception.OutboxException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class JacksonPayloadSerializerTest {

    private JacksonPayloadSerializer serializer;

    @BeforeEach
    void setUp() {
        serializer = new JacksonPayloadSerializer(new ObjectMapper());
    }

    @Test
    void shouldSerializeMapPayload() {
        Map<String, Object> payload = Map.of("amount", 100, "currency", "USD");

        String result = serializer.serialize(payload);

        assertThat(result).contains("\"amount\":100");
        assertThat(result).contains("\"currency\":\"USD\"");
    }

    @Test
    void shouldSerializePojoPayload() {
        record TestPayload(String name, int value) {}

        String result = serializer.serialize(new TestPayload("test", 42));

        assertThat(result).contains("\"name\":\"test\"");
        assertThat(result).contains("\"value\":42");
    }

    @Test
    void shouldReturnStringPayloadAsIs() {
        String payload = "{\"already\":\"serialized\"}";

        String result = serializer.serialize(payload);

        assertThat(result).isEqualTo(payload);
    }

    @Test
    void shouldThrowOnNullPayload() {
        assertThatThrownBy(() -> serializer.serialize(null))
                .isInstanceOf(OutboxException.class)
                .hasMessageContaining("Payload must not be null");
    }

    @Test
    void shouldThrowOnUnserializablePayload() {
        Object unserializable = new Object() {
            public Object getSelf() { return this; }
        };

        assertThatThrownBy(() -> serializer.serialize(unserializable))
                .isInstanceOf(OutboxException.class)
                .hasMessageContaining("Failed to serialize payload");
    }
}
