package com.company.outbox;

import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Minimal Spring Boot application for test context resolution.
 * Required by @JdbcTest and other slice tests.
 */
@SpringBootApplication
public class TestApplication {
}
