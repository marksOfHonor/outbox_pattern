package com.company.outbox.domain;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class OutboxEventStatusTest {

    @Test
    void shouldHaveFiveValues() {
        assertThat(OutboxEventStatus.values()).hasSize(5);
    }

    @Test
    void shouldContainExpectedValues() {
        assertThat(OutboxEventStatus.valueOf("PENDING")).isEqualTo(OutboxEventStatus.PENDING);
        assertThat(OutboxEventStatus.valueOf("PROCESSING")).isEqualTo(OutboxEventStatus.PROCESSING);
        assertThat(OutboxEventStatus.valueOf("RETRY")).isEqualTo(OutboxEventStatus.RETRY);
        assertThat(OutboxEventStatus.valueOf("PUBLISHED")).isEqualTo(OutboxEventStatus.PUBLISHED);
        assertThat(OutboxEventStatus.valueOf("FAILED")).isEqualTo(OutboxEventStatus.FAILED);
    }
}
