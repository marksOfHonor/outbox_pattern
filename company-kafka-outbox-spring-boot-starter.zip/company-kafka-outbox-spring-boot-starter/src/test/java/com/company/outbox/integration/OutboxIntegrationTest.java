package com.company.outbox.integration;

import com.company.outbox.config.OutboxAutoConfiguration;
import com.company.outbox.domain.OutboxEvent;
import com.company.outbox.exception.OutboxException;
import com.company.outbox.hooks.OutboxHooks;
import com.company.outbox.service.OutboxService;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.jackson.JacksonAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
import org.springframework.boot.autoconfigure.sql.init.SqlInitializationAutoConfiguration;
import org.springframework.boot.autoconfigure.transaction.TransactionAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@SpringBootTest(classes = OutboxIntegrationTest.TestConfig.class)
@ActiveProfiles("test")
class OutboxIntegrationTest {

    @Configuration
    @ImportAutoConfiguration({
            DataSourceAutoConfiguration.class,
            DataSourceTransactionManagerAutoConfiguration.class,
            JdbcTemplateAutoConfiguration.class,
            SqlInitializationAutoConfiguration.class,
            JacksonAutoConfiguration.class,
            TransactionAutoConfiguration.class,
            OutboxAutoConfiguration.class
    })
    static class TestConfig {

        @Bean
        MeterRegistry meterRegistry() {
            return new SimpleMeterRegistry();
        }

        @Bean
        OutboxHooks outboxHooks() {
            return new TestOutboxHooks();
        }
    }

    static class TestOutboxHooks implements OutboxHooks {
        final List<OutboxEvent> beforePersistEvents = new ArrayList<>();
        final List<OutboxEvent> afterPersistEvents = new ArrayList<>();
        final List<Exception> errors = new ArrayList<>();

        @Override
        public void beforePersist(OutboxEvent event) {
            beforePersistEvents.add(event);
        }

        @Override
        public void afterPersist(OutboxEvent event) {
            afterPersistEvents.add(event);
        }

        @Override
        public void onError(OutboxEvent event, Exception exception) {
            errors.add(exception);
        }

        void reset() {
            beforePersistEvents.clear();
            afterPersistEvents.clear();
            errors.clear();
        }
    }

    @Autowired
    private OutboxService outboxService;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private MeterRegistry meterRegistry;

    @Autowired
    private OutboxHooks outboxHooks;

    private TestOutboxHooks testHooks() {
        return (TestOutboxHooks) outboxHooks;
    }

    @BeforeEach
    void setUp() {
        testHooks().reset();
    }

    @Test
    @Transactional
    void shouldPersistEventEndToEnd() {
        Map<String, Object> payload = Map.of("amount", 250, "currency", "EUR");

        OutboxEvent result = outboxService.storeEvent("Trade", "T-100", "EXECUTED", payload);

        assertThat(result).isNotNull();
        assertThat(result.getId()).isNotNull();
        assertThat(result.getAggregateType()).isEqualTo("Trade");
        assertThat(result.getEventType()).isEqualTo("EXECUTED");

        Map<String, Object> row = jdbcTemplate.queryForMap(
                "SELECT * FROM trade_outbox WHERE id = ?", result.getId().toString());

        assertThat(row.get("AGGREGATE_TYPE")).isEqualTo("Trade");
        assertThat(row.get("AGGREGATE_ID")).isEqualTo("T-100");
        assertThat(row.get("EVENT_TYPE")).isEqualTo("EXECUTED");
        assertThat(row.get("PAYLOAD").toString()).contains("amount");
        assertThat(row.get("PAYLOAD").toString()).contains("250");
    }

    @Test
    @Transactional
    void shouldPersistEventWithHeaders() {
        Map<String, String> headers = Map.of("correlationId", "corr-456", "traceId", "trace-789");

        OutboxEvent result = outboxService.storeEvent(
                "Payment", "P-200", "PROCESSED",
                Map.of("status", "success"), headers);

        Map<String, Object> row = jdbcTemplate.queryForMap(
                "SELECT * FROM payment_outbox WHERE id = ?", result.getId().toString());

        assertThat(row.get("HEADERS").toString()).contains("correlationId");
        assertThat(row.get("HEADERS").toString()).contains("corr-456");
    }

    @Test
    @Transactional
    void shouldExecuteHooksInOrder() {
        outboxService.storeEvent("Trade", "T-101", "CREATED", Map.of("test", true));

        assertThat(testHooks().beforePersistEvents).hasSize(1);
        assertThat(testHooks().afterPersistEvents).hasSize(1);
        assertThat(testHooks().errors).isEmpty();

        assertThat(testHooks().beforePersistEvents.get(0).getAggregateId()).isEqualTo("T-101");
        assertThat(testHooks().afterPersistEvents.get(0).getAggregateId()).isEqualTo("T-101");
    }

    @Test
    @Transactional
    void shouldRecordMetrics() {
        outboxService.storeEvent("Trade", "T-102", "UPDATED", Map.of("price", 99.99));

        assertThat(meterRegistry.find("outbox.events.stored")
                .tag("table", "trade_outbox")
                .tag("eventType", "UPDATED")
                .counter().count()).isGreaterThanOrEqualTo(1.0);

        assertThat(meterRegistry.find("outbox.persist.latency")
                .tag("table", "trade_outbox")
                .tag("eventType", "UPDATED")
                .timer().count()).isGreaterThanOrEqualTo(1);
    }

    @Test
    @Transactional
    void shouldResolveCorrectTablePerAggregateType() {
        outboxService.storeEvent("Trade", "T-200", "CREATED", Map.of("type", "trade"));
        outboxService.storeEvent("Payment", "P-300", "INITIATED", Map.of("type", "payment"));
        outboxService.storeEvent("Order", "O-400", "PLACED", Map.of("type", "order"));

        Integer tradeCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM trade_outbox", Integer.class);
        Integer paymentCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM payment_outbox", Integer.class);
        Integer orderCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM order_outbox", Integer.class);

        assertThat(tradeCount).isGreaterThanOrEqualTo(1);
        assertThat(paymentCount).isGreaterThanOrEqualTo(1);
        assertThat(orderCount).isGreaterThanOrEqualTo(1);
    }

    @Test
    void shouldFailWithoutTransaction() {
        assertThatThrownBy(() -> outboxService.storeEvent("Trade", "T-999", "CREATED", "{}"))
                .hasMessageContaining("transaction");
    }

    @Test
    @Transactional
    void shouldFailForUnknownAggregateType() {
        assertThatThrownBy(() -> outboxService.storeEvent("Unknown", "X-999", "CREATED", "{}"))
                .isInstanceOf(OutboxException.class)
                .hasMessageContaining("No outbox table configured for aggregate type 'Unknown'");
    }

    @Test
    @Transactional
    void shouldStoreMultipleSubtypesInSameTable() {
        outboxService.storeEvent("Trade", "T-300", "CREATED", Map.of("action", "create"));
        outboxService.storeEvent("Trade", "T-300", "UPDATED", Map.of("action", "update"));
        outboxService.storeEvent("Trade", "T-300", "DELETED", Map.of("action", "delete"));

        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM trade_outbox WHERE aggregate_id = ?", Integer.class, "T-300");

        assertThat(count).isEqualTo(3);
    }
}
