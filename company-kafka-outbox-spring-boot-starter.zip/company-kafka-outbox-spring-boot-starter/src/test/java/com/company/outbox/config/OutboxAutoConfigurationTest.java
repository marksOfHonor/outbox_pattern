package com.company.outbox.config;

import com.company.outbox.hooks.DefaultOutboxHooks;
import com.company.outbox.hooks.OutboxHooks;
import com.company.outbox.lock.OutboxLockProvider;
import com.company.outbox.metrics.OutboxMetrics;
import com.company.outbox.repository.OutboxJdbcRepository;
import com.company.outbox.serialization.JacksonPayloadSerializer;
import com.company.outbox.serialization.PayloadSerializer;
import com.company.outbox.service.OutboxService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.autoconfigure.jackson.JacksonAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;

import static org.assertj.core.api.Assertions.assertThat;

class OutboxAutoConfigurationTest {

    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(
                    DataSourceAutoConfiguration.class,
                    JdbcTemplateAutoConfiguration.class,
                    JacksonAutoConfiguration.class,
                    OutboxAutoConfiguration.class))
            .withPropertyValues(
                    "spring.datasource.url=jdbc:h2:mem:autoconfig_test;DB_CLOSE_DELAY=-1",
                    "spring.datasource.driver-class-name=org.h2.Driver",
                    "outbox.tables.trade.table-name=trade_outbox",
                    "outbox.tables.trade.aggregate-type=Trade")
            .withBean(MeterRegistry.class, SimpleMeterRegistry::new);

    @Test
    void shouldRegisterAllBeans() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(OutboxService.class);
            assertThat(context).hasSingleBean(OutboxJdbcRepository.class);
            assertThat(context).hasSingleBean(PayloadSerializer.class);
            assertThat(context).hasSingleBean(OutboxHooks.class);
            assertThat(context).hasSingleBean(OutboxMetrics.class);
            assertThat(context).hasSingleBean(OutboxProperties.class);
            assertThat(context).hasSingleBean(TableResolver.class);
        });
    }

    @Test
    void shouldUseDefaultImplementations() {
        contextRunner.run(context -> {
            assertThat(context.getBean(PayloadSerializer.class))
                    .isInstanceOf(JacksonPayloadSerializer.class);
            assertThat(context.getBean(OutboxHooks.class))
                    .isInstanceOf(DefaultOutboxHooks.class);
        });
    }

    @Test
    void shouldAllowCustomPayloadSerializer() {
        PayloadSerializer customSerializer = payload -> "custom:" + payload;

        contextRunner
                .withBean(PayloadSerializer.class, () -> customSerializer)
                .run(context -> {
                    assertThat(context.getBean(PayloadSerializer.class))
                            .isSameAs(customSerializer);
                });
    }

    @Test
    void shouldAllowCustomOutboxHooks() {
        OutboxHooks customHooks = new OutboxHooks() {
            @Override public void beforePersist(com.company.outbox.domain.OutboxEvent event) {}
            @Override public void afterPersist(com.company.outbox.domain.OutboxEvent event) {}
            @Override public void onError(com.company.outbox.domain.OutboxEvent event, Exception exception) {}
        };

        contextRunner
                .withBean(OutboxHooks.class, () -> customHooks)
                .run(context -> {
                    assertThat(context.getBean(OutboxHooks.class))
                            .isSameAs(customHooks);
                });
    }

    @Test
    void shouldAllowCustomTableResolver() {
        OutboxProperties props = new OutboxProperties();
        OutboxTableProperties tp = new OutboxTableProperties();
        tp.setTableName("custom_outbox");
        tp.setAggregateType("Custom");
        props.setTables(java.util.Map.of("custom", tp));
        TableResolver customResolver = new TableResolver(props);

        contextRunner
                .withBean(TableResolver.class, () -> customResolver)
                .run(context -> {
                    assertThat(context.getBean(TableResolver.class))
                            .isSameAs(customResolver);
                });
    }

    @Test
    void shouldNotLoadWhenDisabled() {
        contextRunner
                .withPropertyValues("outbox.enabled=false")
                .run(context -> {
                    assertThat(context).doesNotHaveBean(OutboxService.class);
                    assertThat(context).doesNotHaveBean(OutboxJdbcRepository.class);
                    assertThat(context).doesNotHaveBean(TableResolver.class);
                });
    }

    @Test
    void shouldBeEnabledByDefault() {
        contextRunner.run(context -> {
            assertThat(context).hasSingleBean(OutboxService.class);
            OutboxProperties properties = context.getBean(OutboxProperties.class);
            assertThat(properties.isEnabled()).isTrue();
        });
    }

    @Test
    void shouldFailStartupWithNoTablesConfigured() {
        new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(
                        DataSourceAutoConfiguration.class,
                        JdbcTemplateAutoConfiguration.class,
                        JacksonAutoConfiguration.class,
                        OutboxAutoConfiguration.class))
                .withPropertyValues(
                        "spring.datasource.url=jdbc:h2:mem:autoconfig_notables;DB_CLOSE_DELAY=-1",
                        "spring.datasource.driver-class-name=org.h2.Driver")
                .withBean(MeterRegistry.class, SimpleMeterRegistry::new)
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure())
                            .rootCause()
                            .hasMessageContaining("no tables are configured");
                });
    }

    @Test
    void shouldBindTablePropertiesFromConfig() {
        contextRunner
                .withPropertyValues(
                        "outbox.tables.payment.table-name=payment_outbox",
                        "outbox.tables.payment.aggregate-type=Payment")
                .run(context -> {
                    OutboxProperties props = context.getBean(OutboxProperties.class);
                    assertThat(props.getTables()).containsKeys("trade", "payment");
                    assertThat(props.getTables().get("trade").getTableName()).isEqualTo("trade_outbox");
                    assertThat(props.getTables().get("trade").getAggregateType()).isEqualTo("Trade");
                    assertThat(props.getTables().get("payment").getTableName()).isEqualTo("payment_outbox");
                    assertThat(props.getTables().get("payment").getAggregateType()).isEqualTo("Payment");
                });
    }

    @Test
    void shouldNotRegisterRelayWhenRelayDisabled() {
        contextRunner.run(context -> {
            assertThat(context).doesNotHaveBean("outboxRelay");
        });
    }

    @Test
    void shouldNotRegisterCleanupWhenCleanupDisabled() {
        contextRunner.run(context -> {
            assertThat(context).doesNotHaveBean("outboxCleanupService");
        });
    }

    @Test
    void shouldBindRelayProperties() {
        // Note: relay.enabled is NOT set to true to avoid triggering RelayAutoConfiguration
        // which requires a KafkaTemplate bean. Property binding works regardless.
        contextRunner
                .withPropertyValues(
                        "outbox.relay.batch-size=100",
                        "outbox.relay.max-retries=5",
                        "outbox.relay.poll-interval-ms=2000")
                .run(context -> {
                    OutboxProperties props = context.getBean(OutboxProperties.class);
                    assertThat(props.getRelay().isEnabled()).isFalse();
                    assertThat(props.getRelay().getBatchSize()).isEqualTo(100);
                    assertThat(props.getRelay().getMaxRetries()).isEqualTo(5);
                    assertThat(props.getRelay().getPollIntervalMs()).isEqualTo(2000);
                });
    }

    @Test
    void shouldBindCleanupProperties() {
        contextRunner
                .withPropertyValues(
                        "outbox.cleanup.enabled=true",
                        "outbox.cleanup.retention-hours=48",
                        "outbox.cleanup.cron=0 0 3 * * *")
                .run(context -> {
                    OutboxProperties props = context.getBean(OutboxProperties.class);
                    assertThat(props.getCleanup().isEnabled()).isTrue();
                    assertThat(props.getCleanup().getRetentionHours()).isEqualTo(48);
                    assertThat(props.getCleanup().getCron()).isEqualTo("0 0 3 * * *");
                });
    }

    @Test
    void shouldNotRegisterLockProviderByDefault() {
        contextRunner.run(context -> {
            assertThat(context).doesNotHaveBean(OutboxLockProvider.class);
        });
    }

    @Test
    void shouldBindDistributedLockProperties() {
        contextRunner
                .withPropertyValues(
                        "outbox.distributed-lock.enabled=true",
                        "outbox.distributed-lock.lock-at-most-ms=60000")
                .run(context -> {
                    OutboxProperties props = context.getBean(OutboxProperties.class);
                    assertThat(props.getDistributedLock().isEnabled()).isTrue();
                    assertThat(props.getDistributedLock().getLockAtMostMs()).isEqualTo(60000);
                });
    }
}
