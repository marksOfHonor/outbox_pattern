package com.company.outbox.repository;

import com.company.outbox.domain.OutboxEvent;
import com.company.outbox.domain.OutboxEventStatus;
import com.company.outbox.exception.OutboxException;
import com.company.outbox.serialization.JacksonPayloadSerializer;
import com.company.outbox.serialization.PayloadSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.JdbcTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@JdbcTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
class OutboxJdbcRepositoryTest {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private OutboxJdbcRepository repository;
    private PayloadSerializer serializer;

    @BeforeEach
    void setUp() {
        serializer = new JacksonPayloadSerializer(new ObjectMapper());
        repository = new OutboxJdbcRepository(jdbcTemplate, serializer);
        // Clean up to prevent data bleeding from integration tests sharing the same H2 database
        jdbcTemplate.update("DELETE FROM trade_outbox");
        jdbcTemplate.update("DELETE FROM payment_outbox");
        jdbcTemplate.update("DELETE FROM order_outbox");
    }

    @Test
    void shouldSaveEventToTradeOutbox() {
        UUID id = UUID.randomUUID();
        Instant now = Instant.now();

        OutboxEvent event = OutboxEvent.builder()
                .id(id)
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{\"amount\":100}")
                .createdAt(now)
                .build();

        repository.save("trade_outbox", event);

        Map<String, Object> row = jdbcTemplate.queryForMap(
                "SELECT * FROM trade_outbox WHERE id = ?", id.toString());

        assertThat(row.get("AGGREGATE_TYPE")).isEqualTo("Trade");
        assertThat(row.get("AGGREGATE_ID")).isEqualTo("T-001");
        assertThat(row.get("EVENT_TYPE")).isEqualTo("CREATED");
        assertThat(row.get("PAYLOAD").toString()).isEqualTo("{\"amount\":100}");
        assertThat(row.get("HEADERS")).isNull();
    }

    @Test
    void shouldSaveEventWithHeaders() {
        UUID id = UUID.randomUUID();
        Map<String, String> headers = Map.of("correlationId", "corr-123", "source", "test");

        OutboxEvent event = OutboxEvent.builder()
                .id(id)
                .aggregateType("Payment")
                .aggregateId("P-001")
                .eventType("PROCESSED")
                .payload("{\"status\":\"ok\"}")
                .headers(headers)
                .createdAt(Instant.now())
                .build();

        repository.save("payment_outbox", event);

        Map<String, Object> row = jdbcTemplate.queryForMap(
                "SELECT * FROM payment_outbox WHERE id = ?", id.toString());

        assertThat(row.get("HEADERS").toString()).contains("correlationId");
        assertThat(row.get("HEADERS").toString()).contains("corr-123");
    }

    @Test
    void shouldSaveToMultipleTables() {
        OutboxEvent tradeEvent = OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{}")
                .createdAt(Instant.now())
                .build();

        OutboxEvent orderEvent = OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Order")
                .aggregateId("O-001")
                .eventType("PLACED")
                .payload("{}")
                .createdAt(Instant.now())
                .build();

        repository.save("trade_outbox", tradeEvent);
        repository.save("order_outbox", orderEvent);

        Integer tradeCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM trade_outbox", Integer.class);
        Integer orderCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM order_outbox", Integer.class);

        assertThat(tradeCount).isEqualTo(1);
        assertThat(orderCount).isEqualTo(1);
    }

    @Test
    void shouldRejectNullTableName() {
        OutboxEvent event = buildSimpleEvent();

        assertThatThrownBy(() -> repository.save(null, event))
                .isInstanceOf(OutboxException.class)
                .hasMessageContaining("must not be null or blank");
    }

    @Test
    void shouldRejectBlankTableName() {
        OutboxEvent event = buildSimpleEvent();

        assertThatThrownBy(() -> repository.save("  ", event))
                .isInstanceOf(OutboxException.class)
                .hasMessageContaining("must not be null or blank");
    }

    @Test
    void shouldRejectTableNameWithSqlInjection() {
        OutboxEvent event = buildSimpleEvent();

        assertThatThrownBy(() -> repository.save("trade_outbox; DROP TABLE users", event))
                .isInstanceOf(OutboxException.class)
                .hasMessageContaining("Invalid table name");
    }

    @Test
    void shouldRejectTableNameStartingWithNumber() {
        OutboxEvent event = buildSimpleEvent();

        assertThatThrownBy(() -> repository.save("123table", event))
                .isInstanceOf(OutboxException.class)
                .hasMessageContaining("Invalid table name");
    }

    @Test
    void shouldRejectTableNameWithSpecialChars() {
        OutboxEvent event = buildSimpleEvent();

        assertThatThrownBy(() -> repository.save("table-name", event))
                .isInstanceOf(OutboxException.class)
                .hasMessageContaining("Invalid table name");
    }

    @Test
    void shouldFindPendingEvents() {
        OutboxEvent event = buildSimpleEvent();
        repository.save("trade_outbox", event);

        // H2 does not support SKIP LOCKED, so pass false
        List<OutboxEvent> pending = repository.findPendingEvents("trade_outbox", 10, false);

        assertThat(pending).hasSize(1);
        assertThat(pending.get(0).getAggregateId()).isEqualTo("T-001");
        assertThat(pending.get(0).getStatus()).isEqualTo(OutboxEventStatus.PENDING);
    }

    @Test
    void shouldNotFindPublishedEvents() {
        OutboxEvent event = buildSimpleEvent();
        repository.save("trade_outbox", event);
        repository.updateStatus("trade_outbox", event.getId(), OutboxEventStatus.PUBLISHED, Instant.now(), 0);

        List<OutboxEvent> pending = repository.findPendingEvents("trade_outbox", 10, false);

        assertThat(pending).isEmpty();
    }

    @Test
    void shouldUpdateStatus() {
        OutboxEvent event = buildSimpleEvent();
        repository.save("trade_outbox", event);

        Instant processedAt = Instant.now();
        repository.updateStatus("trade_outbox", event.getId(), OutboxEventStatus.PUBLISHED, processedAt, 0);

        Map<String, Object> row = jdbcTemplate.queryForMap(
                "SELECT status, retry_count FROM trade_outbox WHERE id = ?", event.getId().toString());

        assertThat(row.get("STATUS")).isEqualTo("PUBLISHED");
        assertThat(row.get("RETRY_COUNT")).isEqualTo(0);
    }

    @Test
    void shouldIncrementRetryCountWithRetryStatus() {
        OutboxEvent event = buildSimpleEvent();
        repository.save("trade_outbox", event);

        Instant attempt1 = Instant.now();
        repository.updateStatus("trade_outbox", event.getId(), OutboxEventStatus.RETRY, attempt1, 1,
                Instant.now().plusSeconds(1));
        Instant attempt2 = Instant.now();
        repository.updateStatus("trade_outbox", event.getId(), OutboxEventStatus.RETRY, attempt2, 2,
                Instant.now().plusSeconds(2));
        repository.updateStatus("trade_outbox", event.getId(), OutboxEventStatus.FAILED, Instant.now(), 3);

        Map<String, Object> row = jdbcTemplate.queryForMap(
                "SELECT status, retry_count FROM trade_outbox WHERE id = ?", event.getId().toString());

        assertThat(row.get("STATUS")).isEqualTo("FAILED");
        assertThat(row.get("RETRY_COUNT")).isEqualTo(3);
    }

    @Test
    void shouldFindRetryEventsAlongWithPending() {
        OutboxEvent event = buildSimpleEvent();
        repository.save("trade_outbox", event);

        // Simulate retry with expired backoff
        repository.updateStatus("trade_outbox", event.getId(), OutboxEventStatus.RETRY,
                Instant.now(), 1, Instant.now().minusSeconds(10));

        List<OutboxEvent> found = repository.findPendingEvents("trade_outbox", 10, false);

        assertThat(found).hasSize(1);
        assertThat(found.get(0).getStatus()).isEqualTo(OutboxEventStatus.RETRY);
        assertThat(found.get(0).getRetryCount()).isEqualTo(1);
    }

    @Test
    void shouldDeletePublishedEventsBefore() {
        // Insert an old published event
        UUID oldId = UUID.randomUUID();
        Instant oldTime = Instant.now().minusSeconds(7200);
        jdbcTemplate.update(
                "INSERT INTO trade_outbox (id, aggregate_type, aggregate_id, event_type, payload, created_at, status, processed_at, retry_count) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                oldId.toString(), "Trade", "T-OLD", "CREATED", "{}", java.sql.Timestamp.from(oldTime),
                "PUBLISHED", java.sql.Timestamp.from(oldTime), 0);

        // Insert a recent published event
        UUID recentId = UUID.randomUUID();
        Instant recentTime = Instant.now();
        jdbcTemplate.update(
                "INSERT INTO trade_outbox (id, aggregate_type, aggregate_id, event_type, payload, created_at, status, processed_at, retry_count) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                recentId.toString(), "Trade", "T-RECENT", "CREATED", "{}", java.sql.Timestamp.from(recentTime),
                "PUBLISHED", java.sql.Timestamp.from(recentTime), 0);

        Instant cutoff = Instant.now().minusSeconds(3600);
        int deleted = repository.deletePublishedEventsBefore("trade_outbox", cutoff);

        assertThat(deleted).isEqualTo(1);

        Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM trade_outbox", Integer.class);
        assertThat(count).isEqualTo(1);
    }

    @Test
    void shouldRespectBatchSizeInFindPendingEvents() {
        for (int i = 0; i < 5; i++) {
            OutboxEvent event = OutboxEvent.builder()
                    .id(UUID.randomUUID())
                    .aggregateType("Trade")
                    .aggregateId("T-" + i)
                    .eventType("CREATED")
                    .payload("{}")
                    .createdAt(Instant.now())
                    .build();
            repository.save("trade_outbox", event);
        }

        List<OutboxEvent> pending = repository.findPendingEvents("trade_outbox", 3, false);

        assertThat(pending).hasSize(3);
    }

    @Test
    void shouldBatchUpdateStatuses() {
        OutboxEvent event1 = OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Trade").aggregateId("T-001").eventType("CREATED")
                .payload("{}").createdAt(Instant.now()).build();
        OutboxEvent event2 = OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Trade").aggregateId("T-002").eventType("UPDATED")
                .payload("{}").createdAt(Instant.now()).build();
        repository.save("trade_outbox", event1);
        repository.save("trade_outbox", event2);

        Instant now = Instant.now();
        List<StatusUpdate> updates = new ArrayList<>();
        updates.add(new StatusUpdate(event1.getId(), OutboxEventStatus.PUBLISHED, now, 0, null));
        updates.add(new StatusUpdate(event2.getId(), OutboxEventStatus.RETRY, now, 1, now.plusSeconds(5)));

        repository.batchUpdateStatuses("trade_outbox", updates);

        Map<String, Object> row1 = jdbcTemplate.queryForMap(
                "SELECT status, retry_count FROM trade_outbox WHERE id = ?", event1.getId().toString());
        assertThat(row1.get("STATUS")).isEqualTo("PUBLISHED");
        assertThat(row1.get("RETRY_COUNT")).isEqualTo(0);

        Map<String, Object> row2 = jdbcTemplate.queryForMap(
                "SELECT status, retry_count, next_retry_at FROM trade_outbox WHERE id = ?", event2.getId().toString());
        assertThat(row2.get("STATUS")).isEqualTo("RETRY");
        assertThat(row2.get("RETRY_COUNT")).isEqualTo(1);
        assertThat(row2.get("NEXT_RETRY_AT")).isNotNull();
    }

    @Test
    void shouldHandleEmptyBatchUpdate() {
        repository.batchUpdateStatuses("trade_outbox", List.of());
        // Should not throw
    }

    private OutboxEvent buildSimpleEvent() {
        return OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Test")
                .aggregateId("T-001")
                .eventType("TEST")
                .payload("{}")
                .createdAt(Instant.now())
                .build();
    }
}
