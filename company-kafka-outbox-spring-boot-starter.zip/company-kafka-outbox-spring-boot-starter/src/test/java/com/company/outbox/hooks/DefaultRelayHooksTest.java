package com.company.outbox.hooks;

import com.company.outbox.domain.OutboxEvent;
import com.company.outbox.domain.OutboxEventStatus;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThatCode;

class DefaultRelayHooksTest {

    private final DefaultRelayHooks hooks = new DefaultRelayHooks();

    @Test
    void beforePublishShouldNotThrow() {
        OutboxEvent event = buildEvent();
        assertThatCode(() -> hooks.beforePublish(event, "test-topic"))
                .doesNotThrowAnyException();
    }

    @Test
    void afterPublishShouldNotThrow() {
        OutboxEvent event = buildEvent();
        assertThatCode(() -> hooks.afterPublish(event, "test-topic"))
                .doesNotThrowAnyException();
    }

    @Test
    void onPublishFailureShouldNotThrow() {
        OutboxEvent event = buildEvent();
        assertThatCode(() -> hooks.onPublishFailure(event, "test-topic", new RuntimeException("fail")))
                .doesNotThrowAnyException();
    }

    private OutboxEvent buildEvent() {
        return OutboxEvent.builder()
                .id(UUID.randomUUID())
                .aggregateType("Trade")
                .aggregateId("T-001")
                .eventType("CREATED")
                .payload("{}")
                .createdAt(Instant.now())
                .status(OutboxEventStatus.PENDING)
                .build();
    }
}
