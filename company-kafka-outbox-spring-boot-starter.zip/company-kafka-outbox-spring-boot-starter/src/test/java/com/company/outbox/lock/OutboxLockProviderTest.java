package com.company.outbox.lock;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Duration;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class OutboxLockProviderTest {

    @Mock
    private OutboxLockProvider lockProvider;

    @Test
    void shouldDelegateTryAcquire() {
        when(lockProvider.tryAcquire("my-lock", Duration.ofSeconds(30))).thenReturn(true);

        boolean result = lockProvider.tryAcquire("my-lock", Duration.ofSeconds(30));

        assertThat(result).isTrue();
        verify(lockProvider).tryAcquire("my-lock", Duration.ofSeconds(30));
    }

    @Test
    void shouldDelegateRelease() {
        lockProvider.release("my-lock");

        verify(lockProvider).release("my-lock");
    }
}
