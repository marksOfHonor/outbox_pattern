package com.company.outbox.metrics;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Timer;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class OutboxMetricsTest {

    private SimpleMeterRegistry meterRegistry;
    private OutboxMetrics metrics;

    @BeforeEach
    void setUp() {
        meterRegistry = new SimpleMeterRegistry();
        metrics = new OutboxMetrics(meterRegistry);
    }

    @Test
    void shouldRecordStoredEvent() {
        metrics.recordStored("trade_outbox", "CREATED");

        Counter counter = meterRegistry.find("outbox.events.stored")
                .tag("table", "trade_outbox")
                .tag("eventType", "CREATED")
                .counter();

        assertThat(counter).isNotNull();
        assertThat(counter.count()).isEqualTo(1.0);
    }

    @Test
    void shouldRecordMultipleStoredEvents() {
        metrics.recordStored("trade_outbox", "CREATED");
        metrics.recordStored("trade_outbox", "CREATED");
        metrics.recordStored("trade_outbox", "UPDATED");

        Counter createdCounter = meterRegistry.find("outbox.events.stored")
                .tag("table", "trade_outbox")
                .tag("eventType", "CREATED")
                .counter();

        Counter updatedCounter = meterRegistry.find("outbox.events.stored")
                .tag("table", "trade_outbox")
                .tag("eventType", "UPDATED")
                .counter();

        assertThat(createdCounter.count()).isEqualTo(2.0);
        assertThat(updatedCounter.count()).isEqualTo(1.0);
    }

    @Test
    void shouldRecordFailedEvent() {
        metrics.recordFailed("payment_outbox", "FAILED");

        Counter counter = meterRegistry.find("outbox.events.failed")
                .tag("table", "payment_outbox")
                .tag("eventType", "FAILED")
                .counter();

        assertThat(counter).isNotNull();
        assertThat(counter.count()).isEqualTo(1.0);
    }

    @Test
    void shouldRecordLatency() {
        Timer.Sample sample = metrics.startTimer();
        metrics.stopTimer(sample, "trade_outbox", "CREATED");

        Timer timer = meterRegistry.find("outbox.persist.latency")
                .tag("table", "trade_outbox")
                .tag("eventType", "CREATED")
                .timer();

        assertThat(timer).isNotNull();
        assertThat(timer.count()).isEqualTo(1);
        assertThat(timer.totalTime(java.util.concurrent.TimeUnit.NANOSECONDS)).isGreaterThan(0);
    }

    @Test
    void shouldSeparateMetricsByTable() {
        metrics.recordStored("trade_outbox", "CREATED");
        metrics.recordStored("payment_outbox", "CREATED");

        Counter tradeCounter = meterRegistry.find("outbox.events.stored")
                .tag("table", "trade_outbox")
                .counter();

        Counter paymentCounter = meterRegistry.find("outbox.events.stored")
                .tag("table", "payment_outbox")
                .counter();

        assertThat(tradeCounter.count()).isEqualTo(1.0);
        assertThat(paymentCounter.count()).isEqualTo(1.0);
    }

    @Test
    void shouldRecordRelayPublished() {
        metrics.recordRelayPublished("trade_outbox", "CREATED");

        Counter counter = meterRegistry.find("outbox.relay.published")
                .tag("table", "trade_outbox")
                .tag("eventType", "CREATED")
                .counter();

        assertThat(counter).isNotNull();
        assertThat(counter.count()).isEqualTo(1.0);
    }

    @Test
    void shouldRecordRelayFailed() {
        metrics.recordRelayFailed("trade_outbox", "CREATED");

        Counter counter = meterRegistry.find("outbox.relay.failed")
                .tag("table", "trade_outbox")
                .tag("eventType", "CREATED")
                .counter();

        assertThat(counter).isNotNull();
        assertThat(counter.count()).isEqualTo(1.0);
    }

    @Test
    void shouldRecordRelayRetried() {
        metrics.recordRelayRetried("trade_outbox", "CREATED");

        Counter counter = meterRegistry.find("outbox.relay.retried")
                .tag("table", "trade_outbox")
                .tag("eventType", "CREATED")
                .counter();

        assertThat(counter).isNotNull();
        assertThat(counter.count()).isEqualTo(1.0);
    }

    @Test
    void shouldRecordCleanupDeleted() {
        metrics.recordCleanupDeleted("trade_outbox", 5);

        Counter counter = meterRegistry.find("outbox.cleanup.deleted")
                .tag("table", "trade_outbox")
                .counter();

        assertThat(counter).isNotNull();
        assertThat(counter.count()).isEqualTo(5.0);
    }
}
