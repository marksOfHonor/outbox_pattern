package com.company.outbox.exception;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class OutboxExceptionTest {

    @Test
    void shouldCreateWithMessage() {
        OutboxException exception = new OutboxException("Something went wrong");

        assertThat(exception.getMessage()).isEqualTo("Something went wrong");
        assertThat(exception.getCause()).isNull();
    }

    @Test
    void shouldCreateWithMessageAndCause() {
        RuntimeException cause = new RuntimeException("root cause");
        OutboxException exception = new OutboxException("Something went wrong", cause);

        assertThat(exception.getMessage()).isEqualTo("Something went wrong");
        assertThat(exception.getCause()).isEqualTo(cause);
    }

    @Test
    void shouldBeRuntimeException() {
        OutboxException exception = new OutboxException("test");

        assertThat(exception).isInstanceOf(RuntimeException.class);
    }
}
