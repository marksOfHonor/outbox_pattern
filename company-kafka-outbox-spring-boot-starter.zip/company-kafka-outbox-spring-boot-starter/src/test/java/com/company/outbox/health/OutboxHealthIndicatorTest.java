package com.company.outbox.health;

import com.company.outbox.config.OutboxProperties;
import com.company.outbox.config.OutboxTableProperties;
import com.company.outbox.config.TableResolver;
import com.company.outbox.repository.OutboxJdbcRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;

import java.util.LinkedHashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OutboxHealthIndicatorTest {

    @Mock private OutboxJdbcRepository repository;

    private OutboxProperties properties;
    private TableResolver tableResolver;
    private OutboxHealthIndicator healthIndicator;

    @BeforeEach
    void setUp() {
        properties = buildProperties();
        tableResolver = new TableResolver(properties);
        healthIndicator = new OutboxHealthIndicator(repository, tableResolver, properties);
    }

    @Test
    void shouldReportUpWhenHealthy() {
        when(repository.getHealthStats("trade_outbox")).thenReturn(healthStats(5, 0, 0, 60L));

        Health health = healthIndicator.health();

        assertThat(health.getStatus()).isEqualTo(Status.UP);
    }

    @Test
    @SuppressWarnings("unchecked")
    void shouldReportDetailsPerTable() {
        when(repository.getHealthStats("trade_outbox")).thenReturn(healthStats(5, 1, 2, 60L));

        Health health = healthIndicator.health();

        Map<String, Object> tradeDetails = (Map<String, Object>) health.getDetails().get("trade_outbox");
        assertThat(tradeDetails.get("pendingCount")).isEqualTo(5);
        assertThat(tradeDetails.get("retryCount")).isEqualTo(1);
        assertThat(tradeDetails.get("failedCount")).isEqualTo(2);
        assertThat(tradeDetails.get("oldestPendingAgeSeconds")).isEqualTo(60L);
    }

    @Test
    void shouldReportDownWhenUnprocessedExceedsThreshold() {
        // pending=80 + retry=70 = 150 > threshold of 100
        when(repository.getHealthStats("trade_outbox")).thenReturn(healthStats(80, 70, 0, 60L));

        Health health = healthIndicator.health();

        assertThat(health.getStatus()).isEqualTo(Status.DOWN);
    }

    @Test
    void shouldReportDownWhenOldestPendingExceedsThreshold() {
        when(repository.getHealthStats("trade_outbox")).thenReturn(healthStats(5, 0, 0, 3600L));

        Health health = healthIndicator.health();

        assertThat(health.getStatus()).isEqualTo(Status.DOWN);
    }

    @Test
    @SuppressWarnings("unchecked")
    void shouldIncludeAttentionForFailedEvents() {
        when(repository.getHealthStats("trade_outbox")).thenReturn(healthStats(0, 0, 3, 0L));

        Health health = healthIndicator.health();

        assertThat(health.getStatus()).isEqualTo(Status.UP);
        Map<String, Object> tradeDetails = (Map<String, Object>) health.getDetails().get("trade_outbox");
        assertThat(tradeDetails.get("attention")).isNotNull();
        assertThat(tradeDetails.get("attention").toString()).contains("3 failed events");
    }

    @Test
    @SuppressWarnings("unchecked")
    void shouldIncludeAttentionForRetryingEvents() {
        when(repository.getHealthStats("trade_outbox")).thenReturn(healthStats(0, 5, 0, 0L));

        Health health = healthIndicator.health();

        assertThat(health.getStatus()).isEqualTo(Status.UP);
        Map<String, Object> tradeDetails = (Map<String, Object>) health.getDetails().get("trade_outbox");
        assertThat(tradeDetails.get("attention")).isNotNull();
        assertThat(tradeDetails.get("attention").toString()).contains("5 events awaiting retry");
    }

    @Test
    @SuppressWarnings("unchecked")
    void shouldIncludeAttentionListWhenBothRetryAndFailed() {
        when(repository.getHealthStats("trade_outbox")).thenReturn(healthStats(0, 3, 5, 0L));

        Health health = healthIndicator.health();

        Map<String, Object> tradeDetails = (Map<String, Object>) health.getDetails().get("trade_outbox");
        Object attention = tradeDetails.get("attention");
        assertThat(attention).isInstanceOf(java.util.List.class);
        java.util.List<String> attentionList = (java.util.List<String>) attention;
        assertThat(attentionList).hasSize(2);
        assertThat(attentionList.get(0)).contains("3 events awaiting retry");
        assertThat(attentionList.get(1)).contains("5 failed events");
    }

    @Test
    void shouldHandleRepositoryErrors() {
        when(repository.getHealthStats("trade_outbox"))
                .thenThrow(new RuntimeException("DB error"));

        Health health = healthIndicator.health();

        assertThat(health.getStatus()).isEqualTo(Status.DOWN);
    }

    @Test
    void shouldRespectCustomThresholds() {
        OutboxProperties.Health healthConfig = properties.getHealth();
        healthConfig.setPendingWarnThreshold(10);
        healthConfig.setMaxPendingAgeMinutes(5);

        when(repository.getHealthStats("trade_outbox")).thenReturn(healthStats(15, 0, 0, 60L));

        Health health = healthIndicator.health();

        assertThat(health.getStatus()).isEqualTo(Status.DOWN);
    }

    private Map<String, Object> healthStats(int pendingCount, int retryCount, int failedCount, long oldestPendingAgeSec) {
        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("pendingCount", pendingCount);
        stats.put("retryCount", retryCount);
        stats.put("failedCount", failedCount);
        stats.put("oldestPendingAgeSeconds", oldestPendingAgeSec);
        return stats;
    }

    private OutboxProperties buildProperties() {
        OutboxProperties props = new OutboxProperties();
        OutboxTableProperties tradeTable = new OutboxTableProperties();
        tradeTable.setTableName("trade_outbox");
        tradeTable.setAggregateType("Trade");
        props.setTables(new LinkedHashMap<>(Map.of("trade", tradeTable)));

        OutboxProperties.Health health = new OutboxProperties.Health();
        health.setPendingWarnThreshold(100);
        health.setMaxPendingAgeMinutes(30);
        props.setHealth(health);

        return props;
    }
}
