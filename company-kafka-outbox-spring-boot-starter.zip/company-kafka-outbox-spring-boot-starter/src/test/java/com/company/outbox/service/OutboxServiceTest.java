package com.company.outbox.service;

import com.company.outbox.config.TableResolver;
import com.company.outbox.domain.OutboxEvent;
import com.company.outbox.exception.OutboxException;
import com.company.outbox.hooks.OutboxHooks;
import com.company.outbox.metrics.OutboxMetrics;
import com.company.outbox.repository.OutboxJdbcRepository;
import com.company.outbox.serialization.PayloadSerializer;
import io.micrometer.core.instrument.Timer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OutboxServiceTest {

    @Mock
    private OutboxJdbcRepository repository;

    @Mock
    private PayloadSerializer serializer;

    @Mock
    private OutboxHooks hooks;

    @Mock
    private OutboxMetrics metrics;

    @Mock
    private TableResolver tableResolver;

    private OutboxService service;

    @BeforeEach
    void setUp() {
        service = new OutboxService(repository, serializer, hooks, metrics, tableResolver);
        lenient().when(metrics.startTimer()).thenReturn(mock(Timer.Sample.class));
        lenient().when(tableResolver.resolve("Trade")).thenReturn("trade_outbox");
        lenient().when(tableResolver.resolve("Payment")).thenReturn("payment_outbox");
    }

    @Test
    void shouldStoreEventSuccessfully() {
        when(serializer.serialize(any())).thenReturn("{\"amount\":100}");

        OutboxEvent result = service.storeEvent(
                "Trade", "T-001", "CREATED", Map.of("amount", 100));

        assertThat(result).isNotNull();
        assertThat(result.getId()).isNotNull();
        assertThat(result.getAggregateType()).isEqualTo("Trade");
        assertThat(result.getAggregateId()).isEqualTo("T-001");
        assertThat(result.getEventType()).isEqualTo("CREATED");
        assertThat(result.getPayload()).isEqualTo("{\"amount\":100}");
        assertThat(result.getCreatedAt()).isNotNull();
    }

    @Test
    void shouldResolveTableFromAggregateType() {
        when(serializer.serialize(any())).thenReturn("{}");

        service.storeEvent("Trade", "T-001", "CREATED", "{}");

        verify(tableResolver).resolve("Trade");
        verify(repository).save(eq("trade_outbox"), any(OutboxEvent.class));
    }

    @Test
    void shouldCallSerializerWithPayload() {
        Map<String, Object> payload = Map.of("amount", 100);
        when(serializer.serialize(payload)).thenReturn("{\"amount\":100}");

        service.storeEvent("Trade", "T-001", "CREATED", payload);

        verify(serializer).serialize(payload);
    }

    @Test
    void shouldCallRepositorySaveWithResolvedTable() {
        when(serializer.serialize(any())).thenReturn("{}");

        service.storeEvent("Trade", "T-001", "CREATED", "{}");

        ArgumentCaptor<OutboxEvent> eventCaptor = ArgumentCaptor.forClass(OutboxEvent.class);
        verify(repository).save(eq("trade_outbox"), eventCaptor.capture());

        OutboxEvent savedEvent = eventCaptor.getValue();
        assertThat(savedEvent.getAggregateType()).isEqualTo("Trade");
        assertThat(savedEvent.getAggregateId()).isEqualTo("T-001");
    }

    @Test
    void shouldCallHooksBeforeAndAfterPersist() {
        when(serializer.serialize(any())).thenReturn("{}");

        service.storeEvent("Trade", "T-001", "CREATED", "{}");

        var inOrder = inOrder(hooks, repository);
        inOrder.verify(hooks).beforePersist(any(OutboxEvent.class));
        inOrder.verify(repository).save(anyString(), any(OutboxEvent.class));
        inOrder.verify(hooks).afterPersist(any(OutboxEvent.class));
    }

    @Test
    void shouldRecordStoredMetricWithResolvedTable() {
        when(serializer.serialize(any())).thenReturn("{}");

        service.storeEvent("Trade", "T-001", "CREATED", "{}");

        verify(metrics).recordStored("trade_outbox", "CREATED");
        verify(metrics).startTimer();
        verify(metrics).stopTimer(any(), eq("trade_outbox"), eq("CREATED"));
    }

    @Test
    void shouldRecordFailedMetricOnPersistError() {
        when(serializer.serialize(any())).thenReturn("{}");
        doThrow(new RuntimeException("DB error"))
                .when(repository).save(anyString(), any(OutboxEvent.class));

        assertThatThrownBy(() -> service.storeEvent("Trade", "T-001", "CREATED", "{}"))
                .isInstanceOf(OutboxException.class);

        verify(metrics).recordFailed("trade_outbox", "CREATED");
    }

    @Test
    void shouldCallOnErrorHookOnFailure() {
        when(serializer.serialize(any())).thenReturn("{}");
        RuntimeException dbError = new RuntimeException("DB error");
        doThrow(dbError).when(repository).save(anyString(), any(OutboxEvent.class));

        assertThatThrownBy(() -> service.storeEvent("Trade", "T-001", "CREATED", "{}"))
                .isInstanceOf(OutboxException.class);

        verify(hooks).onError(any(OutboxEvent.class), eq(dbError));
        verify(hooks, never()).afterPersist(any());
    }

    @Test
    void shouldStoreEventWithHeaders() {
        when(serializer.serialize(any())).thenReturn("{}");
        Map<String, String> headers = Map.of("correlationId", "abc");

        OutboxEvent result = service.storeEvent(
                "Trade", "T-001", "CREATED", "{}", headers);

        assertThat(result.getHeaders()).containsEntry("correlationId", "abc");
    }

    @Test
    void shouldStoreEventWithEmptyHeadersByDefault() {
        when(serializer.serialize(any())).thenReturn("{}");

        OutboxEvent result = service.storeEvent("Trade", "T-001", "CREATED", "{}");

        assertThat(result.getHeaders()).isEmpty();
    }

    @Test
    void shouldWrapPersistExceptionInOutboxException() {
        when(serializer.serialize(any())).thenReturn("{}");
        doThrow(new RuntimeException("connection refused"))
                .when(repository).save(anyString(), any(OutboxEvent.class));

        assertThatThrownBy(() -> service.storeEvent("Trade", "T-001", "CREATED", "{}"))
                .isInstanceOf(OutboxException.class)
                .hasMessageContaining("trade_outbox")
                .hasMessageContaining("connection refused")
                .hasCauseInstanceOf(RuntimeException.class);
    }

    @Test
    void shouldThrowWhenAggregateTypeNotConfigured() {
        when(tableResolver.resolve("Unknown"))
                .thenThrow(new OutboxException("No outbox table configured for aggregate type 'Unknown'"));

        assertThatThrownBy(() -> service.storeEvent("Unknown", "X-001", "CREATED", "{}"))
                .isInstanceOf(OutboxException.class)
                .hasMessageContaining("Unknown");

        verify(metrics).recordFailed("Unknown", "CREATED");
        verify(repository, never()).save(anyString(), any());
    }

    @Test
    void shouldResolveDifferentTablesForDifferentAggregateTypes() {
        when(serializer.serialize(any())).thenReturn("{}");

        service.storeEvent("Trade", "T-001", "CREATED", "{}");
        service.storeEvent("Payment", "P-001", "PROCESSED", "{}");

        verify(repository).save(eq("trade_outbox"), any(OutboxEvent.class));
        verify(repository).save(eq("payment_outbox"), any(OutboxEvent.class));
    }
}
