package com.company.outbox.compression;

import com.company.outbox.exception.OutboxException;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class GzipPayloadCompressorTest {

    private final GzipPayloadCompressor compressor = new GzipPayloadCompressor();

    @Test
    void shouldCompressAndDecompress() {
        String payload = "{\"amount\":100,\"currency\":\"EUR\"}";

        String compressed = compressor.compress(payload);
        String decompressed = compressor.decompress(compressed);

        assertThat(decompressed).isEqualTo(payload);
    }

    @Test
    void shouldProduceDifferentOutputThanInput() {
        String payload = "{\"amount\":100}";

        String compressed = compressor.compress(payload);

        assertThat(compressed).isNotEqualTo(payload);
    }

    @Test
    void shouldCompressLargePayloads() {
        String payload = "x".repeat(10_000);

        String compressed = compressor.compress(payload);
        String decompressed = compressor.decompress(compressed);

        assertThat(decompressed).isEqualTo(payload);
        // Compressed should be smaller than original for repetitive data
        assertThat(compressed.length()).isLessThan(payload.length());
    }

    @Test
    void shouldHandleEmptyString() {
        String compressed = compressor.compress("");
        String decompressed = compressor.decompress(compressed);

        assertThat(decompressed).isEmpty();
    }

    @Test
    void shouldHandleUnicodePayloads() {
        String payload = "{\"name\":\"日本語テスト\",\"emoji\":\"🎉\"}";

        String compressed = compressor.compress(payload);
        String decompressed = compressor.decompress(compressed);

        assertThat(decompressed).isEqualTo(payload);
    }

    @Test
    void shouldThrowOnInvalidCompressedData() {
        assertThatThrownBy(() -> compressor.decompress("not-valid-base64-gzip"))
                .isInstanceOf(OutboxException.class)
                .hasMessageContaining("Failed to decompress");
    }
}
