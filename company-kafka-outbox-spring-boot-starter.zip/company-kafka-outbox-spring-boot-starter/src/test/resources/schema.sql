CREATE TABLE IF NOT EXISTS trade_outbox (
    id              VARCHAR(36)  PRIMARY KEY,
    aggregate_type  VARCHAR(255) NOT NULL,
    aggregate_id    VARCHAR(255) NOT NULL,
    event_type      VARCHAR(255) NOT NULL,
    payload         CLOB         NOT NULL,
    headers         CLOB,
    created_at      TIMESTAMP    NOT NULL,
    status          VARCHAR(20)  NOT NULL DEFAULT 'PENDING',
    processed_at    TIMESTAMP,
    retry_count     INT          NOT NULL DEFAULT 0,
    next_retry_at   TIMESTAMP,
    schema_version  INT          NOT NULL DEFAULT 1,
    compressed      BOOLEAN      NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS payment_outbox (
    id              VARCHAR(36)  PRIMARY KEY,
    aggregate_type  VARCHAR(255) NOT NULL,
    aggregate_id    VARCHAR(255) NOT NULL,
    event_type      VARCHAR(255) NOT NULL,
    payload         CLOB         NOT NULL,
    headers         CLOB,
    created_at      TIMESTAMP    NOT NULL,
    status          VARCHAR(20)  NOT NULL DEFAULT 'PENDING',
    processed_at    TIMESTAMP,
    retry_count     INT          NOT NULL DEFAULT 0,
    next_retry_at   TIMESTAMP,
    schema_version  INT          NOT NULL DEFAULT 1,
    compressed      BOOLEAN      NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS order_outbox (
    id              VARCHAR(36)  PRIMARY KEY,
    aggregate_type  VARCHAR(255) NOT NULL,
    aggregate_id    VARCHAR(255) NOT NULL,
    event_type      VARCHAR(255) NOT NULL,
    payload         CLOB         NOT NULL,
    headers         CLOB,
    created_at      TIMESTAMP    NOT NULL,
    status          VARCHAR(20)  NOT NULL DEFAULT 'PENDING',
    processed_at    TIMESTAMP,
    retry_count     INT          NOT NULL DEFAULT 0,
    next_retry_at   TIMESTAMP,
    schema_version  INT          NOT NULL DEFAULT 1,
    compressed      BOOLEAN      NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS outbox_lock (
    lock_name   VARCHAR(100) PRIMARY KEY,
    locked_by   VARCHAR(255) NOT NULL,
    lock_until  TIMESTAMP    NOT NULL
);
